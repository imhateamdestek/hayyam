const CACHE_NAME = 'hayyam-v1';
const STATIC_ASSETS = [
  '/',
  '/index.html',
  '/static/js/main.chunk.js',
  '/static/js/bundle.js',
  '/static/css/main.chunk.css'
];

const MESH_DB_NAME = 'hayyam-mesh';
const MESH_DB_VERSION = 1;

// Install - Statik dosyaları cache'le
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(STATIC_ASSETS);
    })
  );
  self.skipWaiting();
});

// Activate - Eski cache'leri temizle
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames
          .filter((name) => name !== CACHE_NAME)
          .map((name) => caches.delete(name))
      );
    })
  );
  self.clients.claim();
});

// Fetch - Offline-first stratejisi
self.addEventListener('fetch', (event) => {
  const { request } = event;

  // API istekleri için network-first
  if (request.url.includes('/api/')) {
    event.respondWith(
      fetch(request)
        .then((response) => {
          // Başarılı yanıtı cache'le
          const clone = response.clone();
          caches.open(CACHE_NAME).then((cache) => {
            cache.put(request, clone);
          });
          return response;
        })
        .catch(() => {
          // Offline ise cache'den ver
          return caches.match(request);
        })
    );
    return;
  }

  // Statik dosyalar için cache-first
  event.respondWith(
    caches.match(request).then((cached) => {
      return cached || fetch(request).then((response) => {
        const clone = response.clone();
        caches.open(CACHE_NAME).then((cache) => {
          cache.put(request, clone);
        });
        return response;
      });
    })
  );
});

// Background Sync - Offline mesajları senkronize et
self.addEventListener('sync', (event) => {
  if (event.tag === 'sync-messages') {
    event.waitUntil(syncPendingMessages());
  }

  if (event.tag === 'sync-mesh') {
    event.waitUntil(syncMeshMessages());
  }
});

// Push Notifications
self.addEventListener('push', (event) => {
  const data = event.data.json();

  const options = {
    body: data.body || 'Yeni mesaj',
    icon: '/icon-192x192.png',
    badge: '/icon-72x72.png',
    tag: data.conversation_id || 'default',
    requireInteraction: true,
    actions: [
      {
        action: 'reply',
        title: 'Yanıtla'
      },
      {
        action: 'dismiss',
        title: 'Kapat'
      }
    ],
    data: {
      conversation_id: data.conversation_id,
      sender_id: data.sender_id
    }
  };

  event.waitUntil(
    self.registration.showNotification(data.title || 'Hayyam', options)
  );
});

// Notification click
self.addEventListener('notificationclick', (event) => {
  event.notification.close();

  const { conversation_id } = event.notification.data;

  event.waitUntil(
    clients.openWindow(`/messages/${conversation_id}`)
  );
});

// Bluetooth ve WiFi Direct mesaj dinleyici (Web Bluetooth API ile)
self.addEventListener('message', (event) => {
  if (event.data.type === 'MESH_MESSAGE') {
    handleMeshMessage(event.data.payload);
  }

  if (event.data.type === 'BLUETOOTH_MESSAGE') {
    handleBluetoothMessage(event.data.payload);
  }

  if (event.data.type === 'WIFI_DIRECT_MESSAGE') {
    handleWiFiDirectMessage(event.data.payload);
  }
});

// Yardımcı fonksiyonlar
async function syncPendingMessages() {
  const db = await openMeshDB();
  const tx = db.transaction('pending_messages', 'readonly');
  const store = tx.objectStore('pending_messages');
  const messages = await store.getAll();

  for (const msg of messages) {
    try {
      const response = await fetch('/api/messages/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(msg)
      });

      if (response.ok) {
        const deleteTx = db.transaction('pending_messages', 'readwrite');
        await deleteTx.objectStore('pending_messages').delete(msg.id);
      }
    } catch (error) {
      console.error('Sync failed for message:', msg.id);
    }
  }
}

async function syncMeshMessages() {
  // Mesh ağındaki mesajları senkronize et
  const db = await openMeshDB();
  const tx = db.transaction('mesh_messages', 'readonly');
  const store = tx.objectStore('mesh_messages');
  const messages = await store.getAll();

  // Burada Bluetooth/WiFi Direct üzerinden broadcast yapılacak
  console.log('Syncing mesh messages:', messages.length);
}

async function handleMeshMessage(payload) {
  // Mesh mesajını işle ve IndexedDB'ye kaydet
  const db = await openMeshDB();
  const tx = db.transaction('mesh_messages', 'readwrite');
  await tx.objectStore('mesh_messages').add({
    ...payload,
    received_at: Date.now()
  });
}

async function handleBluetoothMessage(payload) {
  console.log('Bluetooth message received:', payload);
  // Bluetooth mesaj işleme mantığı
}

async function handleWiFiDirectMessage(payload) {
  console.log('WiFi Direct message received:', payload);
  // WiFi Direct mesaj işleme mantığı
}

function openMeshDB() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(MESH_DB_NAME, MESH_DB_VERSION);

    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve(request.result);

    request.onupgradeneeded = (event) => {
      const db = event.target.result;

      if (!db.objectStoreNames.contains('pending_messages')) {
        db.createObjectStore('pending_messages', { keyPath: 'id', autoIncrement: true });
      }

      if (!db.objectStoreNames.contains('mesh_messages')) {
        const store = db.createObjectStore('mesh_messages', { keyPath: 'uuid' });
        store.createIndex('recipient_id', 'recipient_id', { unique: false });
        store.createIndex('status', 'status', { unique: false });
      }

      if (!db.objectStoreNames.contains('offline_users')) {
        db.createObjectStore('offline_users', { keyPath: 'id' });
      }
    };
  });
}
