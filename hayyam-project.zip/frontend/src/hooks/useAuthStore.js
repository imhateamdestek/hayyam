import { create } from 'zustand';
import axios from 'axios';

const API_URL = process.env.REACT_APP_API_URL || 'https://api.hayyam.app';

const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json'
  }
});

// Request interceptor - Token ekle
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('hayyam_token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Response interceptor - Token yenileme
api.interceptors.response.use(
  (response) => response,
  async (error) => {
    const originalRequest = error.config;

    if (error.response?.status === 401 && !originalRequest._retry) {
      originalRequest._retry = true;

      try {
        const refreshToken = localStorage.getItem('hayyam_refresh_token');
        const response = await axios.post(`${API_URL}/api/auth/refresh`, {
          refresh_token: refreshToken
        });

        const { token } = response.data.data;
        localStorage.setItem('hayyam_token', token);

        originalRequest.headers.Authorization = `Bearer ${token}`;
        return api(originalRequest);
      } catch (refreshError) {
        localStorage.removeItem('hayyam_token');
        localStorage.removeItem('hayyam_refresh_token');
        window.location.href = '/login';
        return Promise.reject(refreshError);
      }
    }

    return Promise.reject(error);
  }
);

export const useAuthStore = create((set, get) => ({
  user: null,
  isLoading: false,
  error: null,
  isAuthenticated: false,

  checkAuth: async () => {
    const token = localStorage.getItem('hayyam_token');
    if (!token) {
      set({ isAuthenticated: false, user: null });
      return;
    }

    try {
      const response = await api.get('/api/auth/me');
      set({ 
        user: response.data.data, 
        isAuthenticated: true,
        error: null 
      });
    } catch (error) {
      localStorage.removeItem('hayyam_token');
      set({ 
        user: null, 
        isAuthenticated: false,
        error: error.response?.data?.message 
      });
    }
  },

  login: async (username, password, deviceInfo) => {
    set({ isLoading: true, error: null });

    try {
      const response = await api.post('/api/auth/login', {
        username,
        password,
        device_info: deviceInfo || navigator.userAgent
      });

      const { token, refresh_token, user } = response.data.data;

      localStorage.setItem('hayyam_token', token);
      localStorage.setItem('hayyam_refresh_token', refresh_token);

      set({ 
        user, 
        isAuthenticated: true, 
        isLoading: false,
        error: null 
      });

      return true;
    } catch (error) {
      set({ 
        isLoading: false, 
        error: error.response?.data?.message || 'Login failed',
        isAuthenticated: false 
      });
      return false;
    }
  },

  register: async (userData) => {
    set({ isLoading: true, error: null });

    try {
      const response = await api.post('/api/auth/register', userData);
      set({ isLoading: false, error: null });
      return response.data.data;
    } catch (error) {
      set({ 
        isLoading: false, 
        error: error.response?.data?.message || 'Registration failed' 
      });
      return null;
    }
  },

  logout: async () => {
    try {
      await api.post('/api/auth/logout');
    } catch (error) {
      console.error('Logout error:', error);
    }

    localStorage.removeItem('hayyam_token');
    localStorage.removeItem('hayyam_refresh_token');
    set({ user: null, isAuthenticated: false, error: null });
  },

  updateProfile: async (updates) => {
    try {
      const response = await api.put('/api/users/profile', updates);
      set({ user: { ...get().user, ...response.data.data } });
      return true;
    } catch (error) {
      set({ error: error.response?.data?.message });
      return false;
    }
  },

  clearError: () => set({ error: null })
}));

export { api };
