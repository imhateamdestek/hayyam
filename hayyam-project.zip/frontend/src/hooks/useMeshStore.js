import { create } from 'zustand';
import { api } from './useAuthStore';

export const useMeshStore = create((set, get) => ({
  isMeshEnabled: false,
  isBluetoothEnabled: false,
  isWiFiDirectEnabled: false,
  nearbyDevices: [],
  pendingMessages: [],
  isDisasterMode: false,
  deviceId: null,
  signalStrength: null,

  initMesh: () => {
    // Cihaz ID'si oluştur veya al
    let deviceId = localStorage.getItem('hayyam_device_id');
    if (!deviceId) {
      deviceId = 'device_' + Math.random().toString(36).substr(2, 9);
      localStorage.setItem('hayyam_device_id', deviceId);
    }

    set({ deviceId });

    // Bluetooth ve WiFi Direct desteğini kontrol et
    const checkCapabilities = async () => {
      const capabilities = {
        bluetooth: 'bluetooth' in navigator,
        wifi_direct: false, // Web API henüz yok, Capacitor plugin kullanılacak
        web_bluetooth: 'bluetooth' in navigator,
        web_share: 'share' in navigator,
        web_push: 'PushManager' in window
      };

      set({
        isBluetoothEnabled: capabilities.bluetooth,
        capabilities
      });
    };

    checkCapabilities();
    get().startDiscovery();
  },

  startDiscovery: () => {
    const interval = setInterval(async () => {
      const { deviceId, isDisasterMode } = get();

      if (!deviceId) return;

      try {
        // Web Bluetooth API ile tarama (sadece disaster modda)
        if (isDisasterMode && 'bluetooth' in navigator) {
          try {
            const device = await navigator.bluetooth.requestDevice({
              acceptAllDevices: true
            });

            if (device) {
              get().addNearbyDevice({
                device_id: device.id,
                name: device.name || 'Unknown Device',
                type: 'bluetooth',
                signal_strength: -65
              });
            }
          } catch (e) {
            // Kullanıcı izin vermedi veya tarama yapılamadı
          }
        }

        // API üzerinden yakındaki cihazları keşfet
        const response = await api.post('/api/mesh/discover', {
          device_id: deviceId,
          signal_strength: get().signalStrength,
          capabilities: get().capabilities
        });

        if (response.data.data?.nearby_devices) {
          set({ nearbyDevices: response.data.data.nearby_devices });
        }
      } catch (error) {
        console.error('Discovery error:', error);
      }
    }, 30000); // Her 30 saniyede bir

    // Cleanup
    return () => clearInterval(interval);
  },

  addNearbyDevice: (device) => {
    set((state) => ({
      nearbyDevices: [...state.nearbyDevices.filter(d => d.device_id !== device.device_id), device]
    }));
  },

  sendMeshMessage: async (recipientUsername, content, deliveryMethod = 'pending') => {
    try {
      const response = await api.post('/api/messages/mesh-send', {
        recipient_username: recipientUsername,
        content,
        delivery_method: deliveryMethod,
        device_fingerprint: get().deviceId
      });

      // IndexedDB'ye kaydet (offline için)
      await get().saveToIndexedDB('pending_messages', {
        ...response.data.data,
        content,
        created_at: Date.now()
      });

      set((state) => ({
        pendingMessages: [...state.pendingMessages, response.data.data]
      }));

      return response.data.data;
    } catch (error) {
      console.error('Mesh send error:', error);
      throw error;
    }
  },

  syncMeshMessages: async () => {
    try {
      const response = await api.get('/api/messages/mesh-pending', {
        params: { device_fingerprint: get().deviceId }
      });

      const messages = response.data.data?.messages || [];

      // IndexedDB'ye kaydet
      for (const msg of messages) {
        await get().saveToIndexedDB('mesh_messages', msg);
      }

      return messages;
    } catch (error) {
      console.error('Mesh sync error:', error);
      return [];
    }
  },

  activateDisasterMode: async (location) => {
    try {
      const response = await api.post('/api/disaster/activate', {
        latitude: location?.latitude,
        longitude: location?.longitude,
        accuracy: location?.accuracy,
        device_info: navigator.userAgent,
        battery_level: await get().getBatteryLevel(),
        network_type: navigator.connection?.effectiveType || 'unknown'
      });

      set({ 
        isDisasterMode: true,
        isMeshEnabled: true,
        isBluetoothEnabled: true,
        isWiFiDirectEnabled: true
      });

      // Background sync kaydet
      if ('serviceWorker' in navigator && 'sync' in ServiceWorkerRegistration.prototype) {
        const registration = await navigator.serviceWorker.ready;
        await registration.sync.register('sync-mesh');
      }

      return response.data.data;
    } catch (error) {
      console.error('Disaster mode activation error:', error);
      throw error;
    }
  },

  deactivateDisasterMode: async () => {
    try {
      await api.post('/api/disaster/deactivate');
      set({ isDisasterMode: false });
    } catch (error) {
      console.error('Disaster mode deactivation error:', error);
    }
  },

  getBatteryLevel: async () => {
    if ('getBattery' in navigator) {
      const battery = await navigator.getBattery();
      return Math.round(battery.level * 100);
    }
    return null;
  },

  saveToIndexedDB: async (storeName, data) => {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open('hayyam-mesh', 1);

      request.onerror = () => reject(request.error);
      request.onsuccess = () => {
        const db = request.result;
        const tx = db.transaction(storeName, 'readwrite');
        const store = tx.objectStore(storeName);
        const putRequest = store.put(data);
        putRequest.onsuccess = () => resolve();
        putRequest.onerror = () => reject(putRequest.error);
      };
    });
  },

  // Web Share API ile mesaj paylaş (cihazdan cihaza)
  shareViaNative: async (data) => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Hayyam Mesaj',
          text: data.text,
          files: data.files
        });
        return true;
      } catch (error) {
        console.error('Share error:', error);
        return false;
      }
    }
    return false;
  }
}));
