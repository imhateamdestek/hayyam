import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../../hooks/useAuthStore';
import { useWebSocket } from '../../hooks/useWebSocket';
import { useMeshStore } from '../../hooks/useMeshStore';
import {
  Search,
  Plus,
  MessageSquare,
  Users,
  Radio,
  ChevronRight,
  Clock,
  Check,
  CheckCheck
} from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { tr } from 'date-fns/locale';

const ChatList = () => {
  const [conversations, setConversations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [showNewChat, setShowNewChat] = useState(false);
  const navigate = useNavigate();
  const { isDisasterMode } = useMeshStore();

  useEffect(() => {
    fetchConversations();
  }, []);

  const fetchConversations = async () => {
    try {
      const response = await api.get('/api/conversations/list');
      setConversations(response.data.data?.conversations || []);
    } catch (error) {
      console.error('Failed to fetch conversations:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleMessage = (data) => {
    if (data.type === 'new_message') {
      fetchConversations();
    }
  };

  useWebSocket(handleMessage);

  const filteredConversations = conversations.filter(conv =>
    conv.title?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    conv.username?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="p-4 border-b border-slate-700">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold">Mesajlar</h2>
          <button 
            onClick={() => setShowNewChat(true)}
            className="p-2 bg-indigo-600 hover:bg-indigo-700 rounded-lg transition-colors"
          >
            <Plus className="w-5 h-5" />
          </button>
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            placeholder="Konuşma ara..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="input pl-10"
          />
        </div>
      </div>

      {/* Disaster Mode Banner */}
      {isDisasterMode && (
        <div className="mx-4 mt-4 p-3 bg-red-500/10 border border-red-500/30 rounded-xl">
          <div className="flex items-center gap-2 text-red-400">
            <Radio className="w-4 h-4 animate-pulse" />
            <span className="text-sm font-medium">Afet Modu Aktif - Mesh Ağı Çalışıyor</span>
          </div>
        </div>
      )}

      {/* Conversations List */}
      <div className="flex-1 overflow-y-auto p-2">
        {loading ? (
          <div className="flex items-center justify-center h-32">
            <div className="w-8 h-8 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin" />
          </div>
        ) : filteredConversations.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-64 text-slate-400">
            <MessageSquare className="w-12 h-12 mb-4 opacity-50" />
            <p>Henüz konuşma yok</p>
            <button 
              onClick={() => setShowNewChat(true)}
              className="mt-4 text-indigo-400 hover:text-indigo-300"
            >
              Yeni konuşma başlat
            </button>
          </div>
        ) : (
          <div className="space-y-1">
            {filteredConversations.map((conv) => (
              <button
                key={conv.id}
                onClick={() => navigate(`/messages/${conv.conversation_id}`)}
                className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-slate-800 
                         transition-colors text-left group"
              >
                <div className="relative">
                  <img
                    src={conv.avatar_url || `https://api.dicebear.com/7.x/avataaars/svg?seed=${conv.username}`}
                    alt={conv.title}
                    className="w-12 h-12 rounded-full bg-slate-700"
                  />
                  {conv.status === 'online' && (
                    <span className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-500 
                                   border-2 border-slate-900 rounded-full" />
                  )}
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <h3 className="font-medium truncate">{conv.title}</h3>
                    {conv.last_message_at && (
                      <span className="text-xs text-slate-500">
                        {formatDistanceToNow(new Date(conv.last_message_at), { 
                          addSuffix: true,
                          locale: tr 
                        })}
                      </span>
                    )}
                  </div>
                  <p className="text-sm text-slate-400 truncate">
                    {conv.last_message || 'Henüz mesaj yok'}
                  </p>
                </div>

                {conv.unread_count > 0 && (
                  <span className="w-5 h-5 bg-indigo-600 rounded-full flex items-center 
                                 justify-center text-xs font-medium">
                    {conv.unread_count}
                  </span>
                )}

                <ChevronRight className="w-4 h-4 text-slate-600 group-hover:text-slate-400" />
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default ChatList;
