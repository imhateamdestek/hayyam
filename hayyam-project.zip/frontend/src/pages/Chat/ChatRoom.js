import React, { useEffect, useState, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { api } from '../../hooks/useAuthStore';
import { useWebSocket } from '../../hooks/useWebSocket';
import { useMeshStore } from '../../hooks/useMeshStore';
import {
  ArrowLeft,
  Send,
  Paperclip,
  Mic,
  Image,
  MoreVertical,
  Phone,
  Video,
  Wifi,
  WifiOff,
  Bluetooth
} from 'lucide-react';
import { format } from 'date-fns';
import { tr } from 'date-fns/locale';

const ChatRoom = () => {
  const { conversationId } = useParams();
  const navigate = useNavigate();
  const [messages, setMessages] = useState([]);
  const [conversation, setConversation] = useState(null);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(true);
  const [isTyping, setIsTyping] = useState(false);
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const messagesEndRef = useRef(null);
  const { isDisasterMode, sendMeshMessage } = useMeshStore();

  useEffect(() => {
    fetchMessages();
    fetchConversationInfo();

    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [conversationId]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const fetchMessages = async () => {
    try {
      const response = await api.get(`/api/messages/history?conversation_id=${conversationId}`);
      setMessages(response.data.data?.items || []);
    } catch (error) {
      console.error('Failed to fetch messages:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchConversationInfo = async () => {
    try {
      const response = await api.get(`/api/conversations/info?id=${conversationId}`);
      setConversation(response.data.data);
    } catch (error) {
      console.error('Failed to fetch conversation info:', error);
    }
  };

  const handleMessage = (data) => {
    if (data.type === 'new_message' && data.conversation_id === conversationId) {
      setMessages(prev => [...prev, {
        id: Date.now(),
        sender_id: data.sender_id,
        content: data.content,
        created_at: new Date().toISOString(),
        is_mine: false
      }]);
    }

    if (data.type === 'typing' && data.conversation_id === conversationId) {
      setIsTyping(data.typing);
      setTimeout(() => setIsTyping(false), 3000);
    }
  };

  const { send } = useWebSocket(handleMessage);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleSend = async () => {
    if (!newMessage.trim()) return;

    const messageContent = newMessage.trim();
    setNewMessage('');

    // Optimistic update
    const tempId = Date.now();
    setMessages(prev => [...prev, {
      id: tempId,
      content: messageContent,
      created_at: new Date().toISOString(),
      is_mine: true,
      pending: true
    }]);

    try {
      if (isOnline) {
        // Normal internet üzerinden gönder
        await api.post('/api/messages/send', {
          conversation_id: conversationId,
          content: messageContent,
          type: 'text'
        });

        send({
          type: 'message',
          conversation_id: conversationId,
          content: messageContent
        });
      } else if (isDisasterMode) {
        // Mesh ağı üzerinden gönder
        await sendMeshMessage(conversation?.username, messageContent, 'mesh');
      }

      // Pending durumunu kaldır
      setMessages(prev => prev.map(msg => 
        msg.id === tempId ? { ...msg, pending: false } : msg
      ));
    } catch (error) {
      console.error('Send failed:', error);
      // Hata durumunda pending'i kaldır
      setMessages(prev => prev.map(msg => 
        msg.id === tempId ? { ...msg, pending: false, failed: true } : msg
      ));
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleTyping = () => {
    send({
      type: 'typing',
      conversation_id: conversationId,
      typing: true
    });
  };

  return (
    <div className="h-full flex flex-col bg-slate-900">
      {/* Header */}
      <div className="flex items-center gap-3 p-4 border-b border-slate-700 bg-slate-800/50 backdrop-blur-xl">
        <button 
          onClick={() => navigate('/messages')}
          className="p-2 hover:bg-slate-700 rounded-lg transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>

        <img
          src={conversation?.avatar_url || `https://api.dicebear.com/7.x/avataaars/svg?seed=${conversation?.username}`}
          alt={conversation?.title}
          className="w-10 h-10 rounded-full bg-slate-700"
        />

        <div className="flex-1 min-w-0">
          <h3 className="font-medium truncate">{conversation?.title || 'Yükleniyor...'}</h3>
          <div className="flex items-center gap-2 text-xs text-slate-400">
            {isTyping ? (
              <span className="text-indigo-400">yazıyor...</span>
            ) : (
              <>
                {conversation?.status === 'online' ? (
                  <span className="text-emerald-400">çevrimiçi</span>
                ) : (
                  <span>son görülme: {conversation?.last_seen}</span>
                )}
              </>
            )}
          </div>
        </div>

        <div className="flex items-center gap-1">
          {!isOnline && (
            <div className="flex items-center gap-1 px-2 py-1 bg-amber-500/10 rounded-lg">
              <WifiOff className="w-3 h-3 text-amber-400" />
              <span className="text-xs text-amber-400">Offline</span>
            </div>
          )}
          {isDisasterMode && (
            <Bluetooth className="w-4 h-4 text-emerald-400" />
          )}
          <button className="p-2 hover:bg-slate-700 rounded-lg transition-colors">
            <Phone className="w-5 h-5" />
          </button>
          <button className="p-2 hover:bg-slate-700 rounded-lg transition-colors">
            <Video className="w-5 h-5" />
          </button>
          <button className="p-2 hover:bg-slate-700 rounded-lg transition-colors">
            <MoreVertical className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {loading ? (
          <div className="flex items-center justify-center h-32">
            <div className="w-8 h-8 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin" />
          </div>
        ) : messages.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-64 text-slate-400">
            <p>Henüz mesaj yok</p>
            <p className="text-sm mt-2">İlk mesajı sen gönder!</p>
          </div>
        ) : (
          messages.map((msg, index) => (
            <div
              key={msg.id}
              className={`flex ${msg.is_mine ? 'justify-end' : 'justify-start'}`}
            >
              <div className={`max-w-[75%] ${msg.is_mine ? 'message-mine' : 'message-other'}`}>
                <p className="text-sm">{msg.content}</p>
                <div className="flex items-center justify-end gap-1 mt-1">
                  <span className="text-[10px] opacity-70">
                    {format(new Date(msg.created_at), 'HH:mm', { locale: tr })}
                  </span>
                  {msg.is_mine && (
                    <span className="text-[10px]">
                      {msg.pending ? (
                        <Clock className="w-3 h-3" />
                      ) : msg.failed ? (
                        <span className="text-red-400">!</span>
                      ) : (
                        <CheckCheck className="w-3 h-3 text-blue-400" />
                      )}
                    </span>
                  )}
                </div>
              </div>
            </div>
          ))
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="p-4 border-t border-slate-700 bg-slate-800/50 backdrop-blur-xl">
        <div className="flex items-end gap-2">
          <button className="p-2 hover:bg-slate-700 rounded-lg transition-colors">
            <Paperclip className="w-5 h-5 text-slate-400" />
          </button>

          <div className="flex-1 relative">
            <textarea
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              onKeyPress={handleKeyPress}
              onInput={handleTyping}
              placeholder={isOnline ? "Mesaj yaz..." : "Mesh ağı üzerinden gönderilecek..."}
              rows={1}
              className="input resize-none max-h-32 py-3 pr-10"
              style={{ minHeight: '44px' }}
            />
          </div>

          <button className="p-2 hover:bg-slate-700 rounded-lg transition-colors">
            <Mic className="w-5 h-5 text-slate-400" />
          </button>

          <button
            onClick={handleSend}
            disabled={!newMessage.trim()}
            className="p-3 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 
                     disabled:cursor-not-allowed rounded-xl transition-all active:scale-95"
          >
            <Send className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default ChatRoom;
