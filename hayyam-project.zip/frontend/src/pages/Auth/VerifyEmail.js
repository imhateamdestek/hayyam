import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Mail, CheckCircle, ArrowRight } from 'lucide-react';
import toast from 'react-hot-toast';

const VerifyEmail = () => {
  const [token, setToken] = useState('');
  const [verified, setVerified] = useState(false);

  const handleVerify = async () => {
    if (!token) {
      toast.error('Doğrulama kodunu girin');
      return;
    }

    // API çağrısı burada yapılacak
    toast.success('Email doğrulandı!');
    setVerified(true);
  };

  if (verified) {
    return (
      <div className="text-center">
        <CheckCircle className="w-16 h-16 mx-auto text-emerald-400 mb-4" />
        <h2 className="text-2xl font-bold mb-2">Email Doğrulandı!</h2>
        <p className="text-slate-400 mb-6">
          Hesabınız başarıyla doğrulandı. Şimdi giriş yapabilirsiniz.
        </p>
        <Link to="/login" className="btn-primary inline-flex items-center gap-2">
          Giriş Yap
          <ArrowRight className="w-4 h-4" />
        </Link>
      </div>
    );
  }

  return (
    <div>
      <div className="text-center mb-6">
        <Mail className="w-12 h-12 mx-auto text-indigo-400 mb-4" />
        <h2 className="text-2xl font-bold">Email Doğrulama</h2>
        <p className="text-slate-400 mt-2">
          Email adresinize gönderilen doğrulama kodunu girin
        </p>
      </div>

      <div className="space-y-4">
        <input
          type="text"
          value={token}
          onChange={(e) => setToken(e.target.value)}
          placeholder="Doğrulama kodu"
          className="input text-center text-lg tracking-widest"
        />

        <button
          onClick={handleVerify}
          className="w-full btn-primary"
        >
          Doğrula
        </button>
      </div>

      <div className="mt-6 text-center">
        <p className="text-sm text-slate-400">
          Kod gelmedi mi?{' '}
          <button className="text-indigo-400 hover:text-indigo-300">
            Tekrar gönder
          </button>
        </p>
      </div>
    </div>
  );
};

export default VerifyEmail;
