import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuthStore } from '../../hooks/useAuthStore';
import { User, Mail, Lock, Eye, EyeOff, UserPlus, Check } from 'lucide-react';
import toast from 'react-hot-toast';

const Register = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    username: '',
    email: '',
    password: '',
    confirmPassword: '',
    display_name: ''
  });
  const [showPassword, setShowPassword] = useState(false);
  const [agreed, setAgreed] = useState(false);
  const { register, isLoading, error } = useAuthStore();

  const validateForm = () => {
    if (!formData.username || !formData.email || !formData.password || !formData.display_name) {
      toast.error('Tüm alanları doldurun');
      return false;
    }

    if (formData.password !== formData.confirmPassword) {
      toast.error('Şifreler eşleşmiyor');
      return false;
    }

    if (formData.password.length < 8) {
      toast.error('Şifre en az 8 karakter olmalı');
      return false;
    }

    if (!agreed) {
      toast.error('Kullanım koşullarını kabul etmelisiniz');
      return false;
    }

    return true;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!validateForm()) return;

    const result = await register({
      username: formData.username,
      email: formData.email,
      password: formData.password,
      display_name: formData.display_name
    });

    if (result) {
      toast.success('Kayıt başarılı! Email doğrulama bağlantısı gönderildi.');
      navigate('/verify-email');
    }
  };

  return (
    <div>
      <h2 className="text-2xl font-bold text-center mb-6">Kayıt Ol</h2>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-medium mb-2 text-slate-300">
            Görünen Ad
          </label>
          <div className="relative">
            <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
            <input
              type="text"
              value={formData.display_name}
              onChange={(e) => setFormData({...formData, display_name: e.target.value})}
              placeholder="Ad Soyad"
              className="input pl-10"
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium mb-2 text-slate-300">
            Kullanıcı Adı
          </label>
          <div className="relative">
            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500">@</span>
            <input
              type="text"
              value={formData.username}
              onChange={(e) => setFormData({...formData, username: e.target.value})}
              placeholder="kullaniciadi"
              className="input pl-8"
              autoComplete="username"
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium mb-2 text-slate-300">Email</label>
          <div className="relative">
            <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
            <input
              type="email"
              value={formData.email}
              onChange={(e) => setFormData({...formData, email: e.target.value})}
              placeholder="ornek@email.com"
              className="input pl-10"
              autoComplete="email"
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium mb-2 text-slate-300">Şifre</label>
          <div className="relative">
            <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
            <input
              type={showPassword ? 'text' : 'password'}
              value={formData.password}
              onChange={(e) => setFormData({...formData, password: e.target.value})}
              placeholder="••••••••"
              className="input pl-10 pr-10"
              autoComplete="new-password"
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-white"
            >
              {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium mb-2 text-slate-300">Şifre Tekrar</label>
          <div className="relative">
            <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
            <input
              type={showPassword ? 'text' : 'password'}
              value={formData.confirmPassword}
              onChange={(e) => setFormData({...formData, confirmPassword: e.target.value})}
              placeholder="••••••••"
              className="input pl-10"
              autoComplete="new-password"
            />
          </div>
        </div>

        <div className="flex items-start gap-2">
          <button
            type="button"
            onClick={() => setAgreed(!agreed)}
            className={`
              mt-1 w-5 h-5 rounded border flex items-center justify-center transition-colors
              ${agreed ? 'bg-indigo-600 border-indigo-600' : 'border-slate-600'}
            `}
          >
            {agreed && <Check className="w-3 h-3 text-white" />}
          </button>
          <span className="text-sm text-slate-400">
            <Link to="/terms" className="text-indigo-400 hover:text-indigo-300">Kullanım Koşulları</Link>'nı ve{' '}
            <Link to="/privacy" className="text-indigo-400 hover:text-indigo-300">Gizlilik Politikası</Link>'nı kabul ediyorum
          </span>
        </div>

        {error && (
          <div className="p-3 bg-red-500/10 border border-red-500/30 rounded-lg text-sm text-red-400">
            {error}
          </div>
        )}

        <button
          type="submit"
          disabled={isLoading}
          className="w-full btn-primary flex items-center justify-center gap-2"
        >
          <UserPlus className="w-4 h-4" />
          {isLoading ? 'Kaydediliyor...' : 'Kayıt Ol'}
        </button>
      </form>

      <p className="mt-6 text-center text-sm text-slate-400">
        Zaten hesabın var mı?{' '}
        <Link to="/login" className="text-indigo-400 hover:text-indigo-300 font-medium">
          Giriş yap
        </Link>
      </p>
    </div>
  );
};

export default Register;
