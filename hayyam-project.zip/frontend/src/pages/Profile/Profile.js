import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { api } from '../../hooks/useAuthStore';
import {
  ArrowLeft,
  MapPin,
  Calendar,
  Link as LinkIcon,
  MessageCircle,
  UserPlus,
  UserCheck,
  Settings,
  Grid,
  Heart
} from 'lucide-react';
import { format } from 'date-fns';
import { tr } from 'date-fns/locale';

const Profile = () => {
  const { username } = useParams();
  const navigate = useNavigate();
  const [profile, setProfile] = useState(null);
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isFriend, setIsFriend] = useState(false);
  const [activeTab, setActiveTab] = useState('posts');

  useEffect(() => {
    fetchProfile();
  }, [username]);

  const fetchProfile = async () => {
    try {
      const response = await api.get(`/api/walls/user?username=${username || 'me'}`);
      setProfile(response.data.data?.profile);
      setPosts(response.data.data?.posts || []);
    } catch (error) {
      console.error('Failed to fetch profile:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleFriendRequest = async () => {
    try {
      if (isFriend) {
        // Arkadaşlıktan çıkar
      } else {
        await api.post('/api/friends/request', { username });
        setIsFriend(true);
      }
    } catch (error) {
      console.error('Friend request failed:', error);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="w-8 h-8 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-slate-400">
        <p>Kullanıcı bulunamadı</p>
      </div>
    );
  }

  return (
    <div className="h-full overflow-y-auto">
      {/* Cover */}
      <div className="h-48 bg-gradient-to-br from-indigo-600 to-purple-700 relative">
        <button 
          onClick={() => navigate(-1)}
          className="absolute top-4 left-4 p-2 bg-black/20 backdrop-blur-sm rounded-lg text-white"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
      </div>

      {/* Profile Info */}
      <div className="px-4 pb-4">
        <div className="relative -mt-16 mb-4">
          <img
            src={profile.avatar_url || `https://api.dicebear.com/7.x/avataaars/svg?seed=${profile.username}`}
            alt={profile.display_name}
            className="w-32 h-32 rounded-full border-4 border-slate-900 bg-slate-800"
          />
        </div>

        <div className="mb-6">
          <h1 className="text-2xl font-bold">{profile.display_name}</h1>
          <p className="text-slate-400">@{profile.username}</p>

          {profile.bio && (
            <p className="mt-3 text-slate-300">{profile.bio}</p>
          )}

          <div className="flex flex-wrap items-center gap-4 mt-4 text-sm text-slate-400">
            {profile.location && (
              <span className="flex items-center gap-1">
                <MapPin className="w-4 h-4" />
                {profile.location}
              </span>
            )}
            <span className="flex items-center gap-1">
              <Calendar className="w-4 h-4" />
              {format(new Date(profile.created_at), 'MMMM yyyy', { locale: tr })}
            </span>
          </div>
        </div>

        {/* Actions */}
        <div className="flex gap-3 mb-6">
          <button 
            onClick={() => navigate(`/messages/new?user=${profile.username}`)}
            className="flex-1 btn-primary flex items-center justify-center gap-2"
          >
            <MessageCircle className="w-4 h-4" />
            Mesaj Gönder
          </button>
          <button 
            onClick={handleFriendRequest}
            className={`flex-1 btn flex items-center justify-center gap-2
              ${isFriend ? 'bg-emerald-600 text-white' : 'bg-slate-700 text-white'}`}
          >
            {isFriend ? <UserCheck className="w-4 h-4" /> : <UserPlus className="w-4 h-4" />}
            {isFriend ? 'Arkadaşsınız' : 'Arkadaş Ekle'}
          </button>
          <button 
            onClick={() => navigate('/settings')}
            className="p-3 bg-slate-700 rounded-lg hover:bg-slate-600 transition-colors"
          >
            <Settings className="w-5 h-5" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-slate-700 mb-4">
          <button
            onClick={() => setActiveTab('posts')}
            className={`flex-1 py-3 text-sm font-medium transition-colors relative
              ${activeTab === 'posts' ? 'text-white' : 'text-slate-400 hover:text-white'}`}
          >
            <Grid className="w-4 h-4 mx-auto mb-1" />
            Paylaşımlar
            {activeTab === 'posts' && (
              <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-indigo-500" />
            )}
          </button>
          <button
            onClick={() => setActiveTab('likes')}
            className={`flex-1 py-3 text-sm font-medium transition-colors relative
              ${activeTab === 'likes' ? 'text-white' : 'text-slate-400 hover:text-white'}`}
          >
            <Heart className="w-4 h-4 mx-auto mb-1" />
            Beğeniler
            {activeTab === 'likes' && (
              <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-indigo-500" />
            )}
          </button>
        </div>

        {/* Content */}
        {activeTab === 'posts' && (
          <div className="space-y-4">
            {posts.length === 0 ? (
              <div className="text-center py-12 text-slate-400">
                <p>Henüz paylaşım yok</p>
              </div>
            ) : (
              posts.map((post) => (
                <div key={post.id} className="card">
                  <p className="text-slate-300">{post.content}</p>
                  {post.media_urls && post.media_urls.length > 0 && (
                    <div className="mt-3 grid grid-cols-2 gap-2">
                      {post.media_urls.map((url, idx) => (
                        <img 
                          key={idx}
                          src={url}
                          alt=""
                          className="rounded-lg w-full h-48 object-cover"
                        />
                      ))}
                    </div>
                  )}
                  <div className="flex items-center gap-4 mt-3 pt-3 border-t border-slate-700/50 text-sm text-slate-400">
                    <span className="flex items-center gap-1">
                      <Heart className="w-4 h-4" />
                      {post.likes}
                    </span>
                    <span className="flex items-center gap-1">
                      <MessageCircle className="w-4 h-4" />
                      {post.comments}
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default Profile;
