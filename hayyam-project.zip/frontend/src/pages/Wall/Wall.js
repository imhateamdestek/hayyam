import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../../hooks/useAuthStore';
import {
  Heart,
  MessageCircle,
  Share2,
  Image,
  Video,
  Type,
  Quote,
  Plus,
  TrendingUp,
  Clock
} from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { tr } from 'date-fns/locale';

const Wall = () => {
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    fetchFeed();
  }, []);

  const fetchFeed = async () => {
    try {
      const response = await api.get('/api/walls/feed');
      setPosts(response.data.data?.posts || []);
    } catch (error) {
      console.error('Failed to fetch feed:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleLike = async (postId) => {
    try {
      await api.post('/api/walls/like', { wall_id: postId });
      fetchFeed();
    } catch (error) {
      console.error('Like failed:', error);
    }
  };

  const getTypeIcon = (type) => {
    switch (type) {
      case 'image': return <Image className="w-4 h-4" />;
      case 'video': return <Video className="w-4 h-4" />;
      case 'quote': return <Quote className="w-4 h-4" />;
      default: return <Type className="w-4 h-4" />;
    }
  };

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="p-4 border-b border-slate-700">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-bold">Duvar</h2>
          <button 
            onClick={() => setShowCreateModal(true)}
            className="btn-primary flex items-center gap-2"
          >
            <Plus className="w-4 h-4" />
            <span className="hidden sm:inline">Paylaşım Yap</span>
          </button>
        </div>
      </div>

      {/* Feed */}
      <div className="flex-1 overflow-y-auto p-4">
        {loading ? (
          <div className="flex items-center justify-center h-32">
            <div className="w-8 h-8 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin" />
          </div>
        ) : posts.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-64 text-slate-400">
            <TrendingUp className="w-12 h-12 mb-4 opacity-50" />
            <p>Henüz paylaşım yok</p>
            <button 
              onClick={() => setShowCreateModal(true)}
              className="mt-4 text-indigo-400 hover:text-indigo-300"
            >
              İlk paylaşımı sen yap
            </button>
          </div>
        ) : (
          <div className="space-y-4 max-w-2xl mx-auto">
            {posts.map((post) => (
              <div key={post.id} className="card animate-fade-in">
                {/* Author */}
                <div 
                  className="flex items-center gap-3 mb-4 cursor-pointer"
                  onClick={() => navigate(`/profile/${post.username}`)}
                >
                  <img
                    src={post.avatar_url || `https://api.dicebear.com/7.x/avataaars/svg?seed=${post.username}`}
                    alt={post.display_name}
                    className="w-10 h-10 rounded-full bg-slate-700"
                  />
                  <div>
                    <h4 className="font-medium">{post.display_name}</h4>
                    <p className="text-xs text-slate-400">@{post.username}</p>
                  </div>
                  <span className="ml-auto text-xs text-slate-500 flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {formatDistanceToNow(new Date(post.created_at), { addSuffix: true, locale: tr })}
                  </span>
                </div>

                {/* Content */}
                <div 
                  className="mb-4 rounded-xl p-4"
                  style={{
                    backgroundColor: post.background_color || 'transparent',
                    color: post.text_color || 'inherit'
                  }}
                >
                  <div className="flex items-center gap-2 mb-2 text-xs opacity-70">
                    {getTypeIcon(post.type)}
                    <span className="capitalize">{post.type}</span>
                  </div>
                  <p className="whitespace-pre-wrap">{post.content}</p>

                  {post.media_urls && post.media_urls.length > 0 && (
                    <div className="mt-3 grid grid-cols-2 gap-2">
                      {post.media_urls.map((url, idx) => (
                        <img 
                          key={idx}
                          src={url}
                          alt="Media"
                          className="rounded-lg w-full h-48 object-cover"
                        />
                      ))}
                    </div>
                  )}
                </div>

                {/* Actions */}
                <div className="flex items-center gap-4 pt-3 border-t border-slate-700/50">
                  <button 
                    onClick={() => handleLike(post.id)}
                    className={`flex items-center gap-2 text-sm transition-colors
                      ${post.is_liked ? 'text-red-400' : 'text-slate-400 hover:text-red-400'}`}
                  >
                    <Heart className={`w-4 h-4 ${post.is_liked ? 'fill-current' : ''}`} />
                    <span>{post.likes || 0}</span>
                  </button>

                  <button className="flex items-center gap-2 text-sm text-slate-400 hover:text-indigo-400 transition-colors">
                    <MessageCircle className="w-4 h-4" />
                    <span>{post.comments || 0}</span>
                  </button>

                  <button className="flex items-center gap-2 text-sm text-slate-400 hover:text-indigo-400 transition-colors ml-auto">
                    <Share2 className="w-4 h-4" />
                    <span>{post.share_count || 0}</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default Wall;
