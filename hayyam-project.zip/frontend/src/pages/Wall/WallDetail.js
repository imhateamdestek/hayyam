import React from 'react';
import { useParams } from 'react-router-dom';

const WallDetail = () => {
  const { username } = useParams();

  return (
    <div className="h-full flex items-center justify-center">
      <p className="text-slate-400">@{username} duvarı yükleniyor...</p>
    </div>
  );
};

export default WallDetail;
