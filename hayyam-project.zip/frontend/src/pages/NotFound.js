import React from 'react';
import { Link } from 'react-router-dom';
import { Home, AlertTriangle } from 'lucide-react';

const NotFound = () => {
  return (
    <div className="min-h-screen bg-slate-900 flex items-center justify-center p-4">
      <div className="text-center">
        <AlertTriangle className="w-16 h-16 mx-auto text-amber-400 mb-4" />
        <h1 className="text-6xl font-bold text-gradient mb-4">404</h1>
        <p className="text-xl text-slate-400 mb-8">Sayfa bulunamadı</p>
        <Link to="/" className="btn-primary inline-flex items-center gap-2">
          <Home className="w-4 h-4" />
          Ana Sayfaya Dön
        </Link>
      </div>
    </div>
  );
};

export default NotFound;
