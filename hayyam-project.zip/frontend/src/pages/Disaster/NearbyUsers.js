import React from 'react';

const NearbyUsers = () => {
  return (
    <div className="h-full flex items-center justify-center">
      <p className="text-slate-400">Yakındaki kullanıcılar yükleniyor...</p>
    </div>
  );
};

export default NearbyUsers;
