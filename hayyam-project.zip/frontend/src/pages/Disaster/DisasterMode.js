import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useMeshStore } from '../../hooks/useMeshStore';
import { api } from '../../hooks/useAuthStore';
import {
  ShieldAlert,
  Radio,
  Bluetooth,
  Wifi,
  MapPin,
  Battery,
  Users,
  Send,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Signal
} from 'lucide-react';
import toast from 'react-hot-toast';

const DisasterMode = () => {
  const { 
    isDisasterMode, 
    activateDisasterMode, 
    deactivateDisasterMode,
    nearbyDevices,
    deviceId
  } = useMeshStore();

  const [location, setLocation] = useState(null);
  const [batteryLevel, setBatteryLevel] = useState(null);
  const [sosMessage, setSosMessage] = useState('');
  const [isActivating, setIsActivating] = useState(false);
  const [networkStatus, setNetworkStatus] = useState({
    internet: navigator.onLine,
    wifi: false,
    bluetooth: false,
    mesh: false
  });
  const navigate = useNavigate();

  useEffect(() => {
    // Konum al
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          setLocation({
            latitude: pos.coords.latitude,
            longitude: pos.coords.longitude,
            accuracy: pos.coords.accuracy
          });
        },
        (error) => {
          console.error('Location error:', error);
          toast.error('Konum alınamadı. Manuel olarak etkinleştirebilirsiniz.');
        },
        { enableHighAccuracy: true, timeout: 10000 }
      );
    }

    // Batarya seviyesi
    if ('getBattery' in navigator) {
      navigator.getBattery().then((battery) => {
        setBatteryLevel(Math.round(battery.level * 100));
        battery.addEventListener('levelchange', () => {
          setBatteryLevel(Math.round(battery.level * 100));
        });
      });
    }

    // Network durumunu izle
    const updateNetworkStatus = () => {
      setNetworkStatus(prev => ({
        ...prev,
        internet: navigator.onLine
      }));
    };

    window.addEventListener('online', updateNetworkStatus);
    window.addEventListener('offline', updateNetworkStatus);

    return () => {
      window.removeEventListener('online', updateNetworkStatus);
      window.removeEventListener('offline', updateNetworkStatus);
    };
  }, []);

  const handleActivate = async () => {
    setIsActivating(true);

    try {
      const result = await activateDisasterMode(location);

      toast.success('Afet modu aktifleştirildi!', {
        icon: '🚨',
        duration: 5000
      });

      // Bildirim izni iste
      if ('Notification' in window && Notification.permission === 'default') {
        Notification.requestPermission();
      }
    } catch (error) {
      toast.error('Aktifleştirme başarısız: ' + error.message);
    } finally {
      setIsActivating(false);
    }
  };

  const handleDeactivate = async () => {
    try {
      await deactivateDisasterMode();
      toast.success('Afet modu kapatıldı');
    } catch (error) {
      toast.error('Kapatma başarısız');
    }
  };

  const sendSOS = async () => {
    if (!sosMessage.trim()) {
      toast.error('Lütfen bir mesaj yazın');
      return;
    }

    try {
      await api.post('/api/disaster/sos', {
        latitude: location?.latitude,
        longitude: location?.longitude,
        message: sosMessage,
        injury_status: 'unknown',
        people_count: 1
      });

      toast.success('SOS sinyali gönderildi! Yakındaki cihazlara iletildi.', {
        icon: '🆘',
        duration: 5000
      });

      setSosMessage('');
    } catch (error) {
      toast.error('SOS gönderilemedi');
    }
  };

  if (!isDisasterMode) {
    return (
      <div className="h-full flex flex-col items-center justify-center p-6">
        <div className="max-w-md w-full text-center">
          <div className="w-24 h-24 mx-auto mb-6 rounded-full bg-red-500/10 
                        flex items-center justify-center">
            <ShieldAlert className="w-12 h-12 text-red-500" />
          </div>

          <h2 className="text-2xl font-bold mb-2">Afet Modu</h2>
          <p className="text-slate-400 mb-8">
            Deprem veya diğer afet durumlarında internet olmadan mesajlaşmak için 
            afet modunu aktifleştirin. Mesajlarınız Bluetooth ve WiFi Direct ile 
            yakındaki cihazlara iletilecek.
          </p>

          <div className="space-y-4 mb-8">
            <div className="flex items-center gap-3 p-3 bg-slate-800 rounded-lg">
              <Bluetooth className="w-5 h-5 text-blue-400" />
              <span className="text-sm">Bluetooth ile cihaz keşfi</span>
            </div>
            <div className="flex items-center gap-3 p-3 bg-slate-800 rounded-lg">
              <Wifi className="w-5 h-5 text-emerald-400" />
              <span className="text-sm">WiFi Direct ile hızlı iletim</span>
            </div>
            <div className="flex items-center gap-3 p-3 bg-slate-800 rounded-lg">
              <Radio className="w-5 h-5 text-purple-400" />
              <span className="text-sm">Mesh ağı ile çoklu atlama</span>
            </div>
          </div>

          <button
            onClick={handleActivate}
            disabled={isActivating}
            className="w-full btn-danger py-4 text-lg font-bold animate-pulse-slow"
          >
            {isActivating ? 'Aktifleştiriliyor...' : '🚨 AFET MODUNU AKTİFLEŞTİR'}
          </button>

          <p className="text-xs text-slate-500 mt-4">
            Bu mod pil tüketimini artırabilir. Acil durumlar için kullanın.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col bg-red-950/20">
      {/* Status Bar */}
      <div className="p-4 bg-red-500/10 border-b border-red-500/30">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-red-500 animate-pulse" />
            <span className="font-bold text-red-400">AFET MODU AKTİF</span>
          </div>
          <button 
            onClick={handleDeactivate}
            className="text-xs text-slate-400 hover:text-white"
          >
            Kapat
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-4">
        <div className="max-w-2xl mx-auto space-y-4">
          {/* Device Status */}
          <div className="card border-red-500/30">
            <h3 className="font-medium mb-3 flex items-center gap-2">
              <Signal className="w-4 h-4 text-red-400" />
              Cihaz Durumu
            </h3>
            <div className="grid grid-cols-2 gap-3">
              <div className="flex items-center gap-2 p-2 bg-slate-800 rounded-lg">
                <Battery className="w-4 h-4 text-emerald-400" />
                <span className="text-sm">%{batteryLevel || '?'}</span>
              </div>
              <div className="flex items-center gap-2 p-2 bg-slate-800 rounded-lg">
                <MapPin className="w-4 h-4 text-blue-400" />
                <span className="text-sm text-xs truncate">
                  {location ? `${location.latitude.toFixed(4)}, ${location.longitude.toFixed(4)}` : 'Konum yok'}
                </span>
              </div>
              <div className="flex items-center gap-2 p-2 bg-slate-800 rounded-lg">
                <Wifi className={`w-4 h-4 ${networkStatus.internet ? 'text-emerald-400' : 'text-red-400'}`} />
                <span className="text-sm">{networkStatus.internet ? 'İnternet Var' : 'Offline'}</span>
              </div>
              <div className="flex items-center gap-2 p-2 bg-slate-800 rounded-lg">
                <Bluetooth className="w-4 h-4 text-blue-400" />
                <span className="text-sm">{nearbyDevices.length} Cihaz</span>
              </div>
            </div>
          </div>

          {/* SOS Section */}
          <div className="card border-red-500/30">
            <h3 className="font-medium mb-3 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-red-400" />
              SOS Sinyali
            </h3>
            <textarea
              value={sosMessage}
              onChange={(e) => setSosMessage(e.target.value)}
              placeholder="Acil durum mesajınız... (Konum otomatik eklenecek)"
              rows={3}
              className="input mb-3"
            />
            <button
              onClick={sendSOS}
              className="w-full btn-danger py-3 flex items-center justify-center gap-2"
            >
              <Send className="w-4 h-4" />
              SOS Sinyali Gönder
            </button>
          </div>

          {/* Nearby Users */}
          <div className="card">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-medium flex items-center gap-2">
                <Users className="w-4 h-4 text-emerald-400" />
                Yakındaki Kullanıcılar
              </h3>
              <button 
                onClick={() => navigate('/disaster/nearby')}
                className="text-xs text-indigo-400 hover:text-indigo-300"
              >
                Tümünü Gör
              </button>
            </div>

            {nearbyDevices.length === 0 ? (
              <p className="text-sm text-slate-400 text-center py-4">
                Yakında cihaz bulunamadı. Bluetooth'un açık olduğundan emin olun.
              </p>
            ) : (
              <div className="space-y-2">
                {nearbyDevices.slice(0, 5).map((device) => (
                  <div key={device.device_id} className="flex items-center gap-3 p-2 bg-slate-800 rounded-lg">
                    <div className="w-8 h-8 rounded-full bg-slate-700 flex items-center justify-center">
                      <Radio className="w-4 h-4 text-emerald-400" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{device.username || 'Bilinmeyen'}</p>
                      <p className="text-xs text-slate-400">
                        {device.distance_km ? `${device.distance_km.toFixed(2)} km` : 'Yakında'}
                      </p>
                    </div>
                    <div className="flex items-center gap-1">
                      <Signal className="w-3 h-3 text-emerald-400" />
                      <span className="text-xs text-slate-400">{device.hop_distance || 0} atlamalık</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Tips */}
          <div className="card">
            <h3 className="font-medium mb-3">Pil Tasarrufu İpuçları</h3>
            <ul className="space-y-2 text-sm text-slate-400">
              <li className="flex items-start gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-400 mt-0.5" />
                Ekran parlaklığını düşürün
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-400 mt-0.5" />
                Mesajları kısa tutun
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-400 mt-0.5" />
                Gereksiz uygulamaları kapatın
              </li>
              <li className="flex items-start gap-2">
                <XCircle className="w-4 h-4 text-red-400 mt-0.5" />
                Videolu arama yapmayın
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DisasterMode;
