import React, { useState } from 'react';
import { useAuthStore } from '../../hooks/useAuthStore';
import { useMeshStore } from '../../hooks/useMeshStore';
import {
  User,
  Lock,
  Bell,
  Wifi,
  Bluetooth,
  Shield,
  Moon,
  Globe,
  ChevronRight,
  LogOut,
  Smartphone
} from 'lucide-react';
import toast from 'react-hot-toast';

const Settings = () => {
  const { user, logout, updateProfile } = useAuthStore();
  const { isMeshEnabled, isDisasterMode } = useMeshStore();
  const [settings, setSettings] = useState({
    theme: 'dark',
    language: 'tr',
    notifications: true,
    sound: true,
    vibration: true,
    mesh_enabled: true,
    bluetooth_enabled: true,
    wifi_direct_enabled: true,
    privacy_profile: 'public',
    privacy_last_seen: 'everyone',
    auto_download_mobile: false,
    auto_download_wifi: true
  });

  const handleSettingChange = (key, value) => {
    setSettings({ ...settings, [key]: value });
    toast.success('Ayar kaydedildi');
  };

  const settingSections = [
    {
      title: 'Hesap',
      icon: User,
      items: [
        { label: 'Profili Düzenle', icon: User, action: () => {} },
        { label: 'Gizlilik', icon: Lock, action: () => {} },
        { label: 'Güvenlik', icon: Shield, action: () => {} }
      ]
    },
    {
      title: 'Bildirimler',
      icon: Bell,
      items: [
        { 
          label: 'Bildirimler', 
          icon: Bell, 
          type: 'toggle',
          value: settings.notifications,
          onChange: (v) => handleSettingChange('notifications', v)
        },
        { 
          label: 'Ses', 
          icon: Bell, 
          type: 'toggle',
          value: settings.sound,
          onChange: (v) => handleSettingChange('sound', v)
        },
        { 
          label: 'Titreşim', 
          icon: Smartphone, 
          type: 'toggle',
          value: settings.vibration,
          onChange: (v) => handleSettingChange('vibration', v)
        }
      ]
    },
    {
      title: 'Bağlantı',
      icon: Wifi,
      items: [
        { 
          label: 'Mesh Ağı', 
          icon: Wifi, 
          type: 'toggle',
          value: settings.mesh_enabled,
          onChange: (v) => handleSettingChange('mesh_enabled', v)
        },
        { 
          label: 'Bluetooth', 
          icon: Bluetooth, 
          type: 'toggle',
          value: settings.bluetooth_enabled,
          onChange: (v) => handleSettingChange('bluetooth_enabled', v)
        },
        { 
          label: 'WiFi Direct', 
          icon: Wifi, 
          type: 'toggle',
          value: settings.wifi_direct_enabled,
          onChange: (v) => handleSettingChange('wifi_direct_enabled', v)
        }
      ]
    },
    {
      title: 'Görünüm',
      icon: Moon,
      items: [
        { 
          label: 'Tema', 
          icon: Moon, 
          type: 'select',
          value: settings.theme,
          options: [
            { label: 'Koyu', value: 'dark' },
            { label: 'Açık', value: 'light' },
            { label: 'Sistem', value: 'system' }
          ],
          onChange: (v) => handleSettingChange('theme', v)
        },
        { 
          label: 'Dil', 
          icon: Globe, 
          type: 'select',
          value: settings.language,
          options: [
            { label: 'Türkçe', value: 'tr' },
            { label: 'English', value: 'en' }
          ],
          onChange: (v) => handleSettingChange('language', v)
        }
      ]
    }
  ];

  return (
    <div className="h-full overflow-y-auto">
      <div className="p-4 border-b border-slate-700">
        <h2 className="text-xl font-bold">Ayarlar</h2>
      </div>

      <div className="p-4 space-y-6">
        {/* Profile Card */}
        <div className="card flex items-center gap-4">
          <img
            src={user?.avatar_url || `https://api.dicebear.com/7.x/avataaars/svg?seed=${user?.username}`}
            alt={user?.display_name}
            className="w-16 h-16 rounded-full bg-slate-700"
          />
          <div>
            <h3 className="font-medium">{user?.display_name}</h3>
            <p className="text-sm text-slate-400">@{user?.username}</p>
            <p className="text-xs text-slate-500 mt-1">{user?.email}</p>
          </div>
        </div>

        {/* Settings Sections */}
        {settingSections.map((section) => (
          <div key={section.title}>
            <h3 className="text-sm font-medium text-slate-400 mb-3 flex items-center gap-2">
              <section.icon className="w-4 h-4" />
              {section.title}
            </h3>
            <div className="card space-y-1">
              {section.items.map((item) => (
                <div 
                  key={item.label}
                  className="flex items-center justify-between py-3 px-2 hover:bg-slate-700/50 rounded-lg transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <item.icon className="w-4 h-4 text-slate-400" />
                    <span className="text-sm">{item.label}</span>
                  </div>

                  {item.type === 'toggle' && (
                    <button
                      onClick={() => item.onChange(!item.value)}
                      className={`
                        w-11 h-6 rounded-full transition-colors relative
                        ${item.value ? 'bg-indigo-600' : 'bg-slate-700'}
                      `}
                    >
                      <span className={`
                        absolute top-1 left-1 w-4 h-4 bg-white rounded-full transition-transform
                        ${item.value ? 'translate-x-5' : 'translate-x-0'}
                      `} />
                    </button>
                  )}

                  {item.type === 'select' && (
                    <select
                      value={item.value}
                      onChange={(e) => item.onChange(e.target.value)}
                      className="bg-slate-700 text-sm rounded-lg px-3 py-1.5 border-none outline-none"
                    >
                      {item.options.map((opt) => (
                        <option key={opt.value} value={opt.value}>{opt.label}</option>
                      ))}
                    </select>
                  )}

                  {!item.type && (
                    <ChevronRight className="w-4 h-4 text-slate-600" />
                  )}
                </div>
              ))}
            </div>
          </div>
        ))}

        {/* Danger Zone */}
        <div>
          <h3 className="text-sm font-medium text-red-400 mb-3">Tehlikeli Bölge</h3>
          <div className="card">
            <button
              onClick={() => {
                if (window.confirm('Hesabınızı silmek istediğinize emin misiniz? Bu işlem geri alınamaz.')) {
                  logout();
                }
              }}
              className="w-full py-3 text-red-400 hover:bg-red-500/10 rounded-lg transition-colors text-sm font-medium"
            >
              Hesabı Sil
            </button>
          </div>
        </div>

        {/* Logout */}
        <button
          onClick={logout}
          className="w-full btn-danger flex items-center justify-center gap-2"
        >
          <LogOut className="w-4 h-4" />
          Çıkış Yap
        </button>

        {/* Version */}
        <p className="text-center text-xs text-slate-600">
          Hayyam v1.0.0 - Build 2024
        </p>
      </div>
    </div>
  );
};

export default Settings;
