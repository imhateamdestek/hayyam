import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../../hooks/useAuthStore';
import {
  Bot,
  Code,
  Terminal,
  Save,
  ArrowLeft,
  Check,
  Globe,
  Lock
} from 'lucide-react';
import toast from 'react-hot-toast';

const BotBuilder = () => {
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  const [botData, setBotData] = useState({
    name: '',
    username: '',
    description: '',
    language: 'python',
    is_public: false,
    webhook_url: ''
  });
  const [commands, setCommands] = useState([
    { command: 'start', description: 'Botu başlat', response: 'Merhaba! Size nasıl yardımcı olabilirim?' },
    { command: 'help', description: 'Yardım menüsü', response: 'Mevcut komutlar: /start, /help' }
  ]);

  const handleCreate = async () => {
    setIsLoading(true);

    try {
      const response = await api.post('/api/bots/create', botData);
      const bot = response.data.data;

      // Komutları kaydet
      for (const cmd of commands) {
        await api.post('/api/bots/command', {
          bot_id: bot.bot_id,
          command: cmd.command,
          description: cmd.description,
          response_template: cmd.response
        });
      }

      toast.success('Bot başarıyla oluşturuldu!', {
        duration: 5000
      });

      navigate('/bots');
    } catch (error) {
      toast.error(error.response?.data?.message || 'Bot oluşturulamadı');
    } finally {
      setIsLoading(false);
    }
  };

  const addCommand = () => {
    setCommands([...commands, { command: '', description: '', response: '' }]);
  };

  const updateCommand = (index, field, value) => {
    const newCommands = [...commands];
    newCommands[index][field] = value;
    setCommands(newCommands);
  };

  const removeCommand = (index) => {
    setCommands(commands.filter((_, i) => i !== index));
  };

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="p-4 border-b border-slate-700">
        <div className="flex items-center gap-3">
          <button 
            onClick={() => navigate('/bots')}
            className="p-2 hover:bg-slate-700 rounded-lg transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h2 className="text-xl font-bold">Bot Oluştur</h2>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-4">
        <div className="max-w-2xl mx-auto">
          {/* Steps */}
          <div className="flex items-center gap-4 mb-8">
            {[1, 2, 3].map((s) => (
              <div key={s} className="flex items-center gap-2">
                <div className={`
                  w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium
                  ${step >= s ? 'bg-indigo-600 text-white' : 'bg-slate-800 text-slate-400'}
                `}>
                  {step > s ? <Check className="w-4 h-4" /> : s}
                </div>
                <span className={`text-sm ${step >= s ? 'text-white' : 'text-slate-500'}`}>
                  {s === 1 ? 'Temel Bilgiler' : s === 2 ? 'Komutlar' : 'Webhook'}
                </span>
              </div>
            ))}
          </div>

          {/* Step 1: Basic Info */}
          {step === 1 && (
            <div className="space-y-4 animate-fade-in">
              <div>
                <label className="block text-sm font-medium mb-2">Bot Adı</label>
                <input
                  type="text"
                  value={botData.name}
                  onChange={(e) => setBotData({...botData, name: e.target.value})}
                  placeholder="Örn: Hava Durumu Botu"
                  className="input"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Kullanıcı Adı</label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500">@</span>
                  <input
                    type="text"
                    value={botData.username}
                    onChange={(e) => setBotData({...botData, username: e.target.value})}
                    placeholder="havadurumu_bot"
                    className="input pl-8"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Açıklama</label>
                <textarea
                  value={botData.description}
                  onChange={(e) => setBotData({...botData, description: e.target.value})}
                  placeholder="Botunuz ne yapar?"
                  rows={3}
                  className="input"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Programlama Dili</label>
                <div className="grid grid-cols-3 gap-3">
                  {['python', 'javascript', 'php'].map((lang) => (
                    <button
                      key={lang}
                      onClick={() => setBotData({...botData, language: lang})}
                      className={`
                        p-3 rounded-xl border transition-all capitalize
                        ${botData.language === lang 
                          ? 'border-indigo-500 bg-indigo-500/10 text-indigo-400' 
                          : 'border-slate-700 bg-slate-800 text-slate-400 hover:border-slate-600'}
                      `}
                    >
                      <Code className="w-5 h-5 mx-auto mb-2" />
                      {lang}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Gizlilik</label>
                <div className="flex gap-3">
                  <button
                    onClick={() => setBotData({...botData, is_public: false})}
                    className={`
                      flex-1 p-3 rounded-xl border transition-all
                      ${!botData.is_public 
                        ? 'border-indigo-500 bg-indigo-500/10 text-indigo-400' 
                        : 'border-slate-700 bg-slate-800 text-slate-400'}
                    `}
                  >
                    <Lock className="w-5 h-5 mx-auto mb-2" />
                    <span className="text-sm">Özel</span>
                  </button>
                  <button
                    onClick={() => setBotData({...botData, is_public: true})}
                    className={`
                      flex-1 p-3 rounded-xl border transition-all
                      ${botData.is_public 
                        ? 'border-indigo-500 bg-indigo-500/10 text-indigo-400' 
                        : 'border-slate-700 bg-slate-800 text-slate-400'}
                    `}
                  >
                    <Globe className="w-5 h-5 mx-auto mb-2" />
                    <span className="text-sm">Herkese Açık</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Step 2: Commands */}
          {step === 2 && (
            <div className="space-y-4 animate-fade-in">
              <div className="flex items-center justify-between">
                <h3 className="font-medium">Bot Komutları</h3>
                <button 
                  onClick={addCommand}
                  className="text-sm text-indigo-400 hover:text-indigo-300"
                >
                  + Komut Ekle
                </button>
              </div>

              {commands.map((cmd, index) => (
                <div key={index} className="card space-y-3">
                  <div className="flex items-center gap-2">
                    <span className="text-slate-500">/</span>
                    <input
                      type="text"
                      value={cmd.command}
                      onChange={(e) => updateCommand(index, 'command', e.target.value)}
                      placeholder="komut"
                      className="input flex-1"
                    />
                    <button 
                      onClick={() => removeCommand(index)}
                      className="p-2 text-red-400 hover:bg-red-500/10 rounded-lg"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                  <input
                    type="text"
                    value={cmd.description}
                    onChange={(e) => updateCommand(index, 'description', e.target.value)}
                    placeholder="Komut açıklaması"
                    className="input"
                  />
                  <textarea
                    value={cmd.response}
                    onChange={(e) => updateCommand(index, 'response', e.target.value)}
                    placeholder="Bot yanıtı"
                    rows={2}
                    className="input"
                  />
                </div>
              ))}
            </div>
          )}

          {/* Step 3: Webhook */}
          {step === 3 && (
            <div className="space-y-4 animate-fade-in">
              <div>
                <label className="block text-sm font-medium mb-2">Webhook URL (İsteğe Bağlı)</label>
                <input
                  type="url"
                  value={botData.webhook_url}
                  onChange={(e) => setBotData({...botData, webhook_url: e.target.value})}
                  placeholder="https://your-server.com/webhook"
                  className="input"
                />
                <p className="text-xs text-slate-500 mt-2">
                  Webhook URL'i girmezseniz, botunuz sadece uygulama içi komutlarla çalışır.
                </p>
              </div>

              <div className="card bg-slate-800/50">
                <h4 className="font-medium mb-3 flex items-center gap-2">
                  <Terminal className="w-4 h-4 text-indigo-400" />
                  Python Örnek Kodu
                </h4>
                <pre className="text-xs text-slate-400 overflow-x-auto p-3 bg-slate-900 rounded-lg">
{`from flask import Flask, request
import requests

app = Flask(__name__)

@app.route('/webhook', methods=['POST'])
def webhook():
    data = request.json
    message = data['message']['text']
    chat_id = data['message']['chat']['id']

    if message == '/start':
        send_message(chat_id, 'Merhaba!')

    return 'OK'

def send_message(chat_id, text):
    # Hayyam API'ye mesaj gönder
    pass

if __name__ == '__main__':
    app.run(port=5000)`}
                </pre>
              </div>
            </div>
          )}

          {/* Navigation */}
          <div className="flex items-center justify-between mt-8">
            <button
              onClick={() => setStep(Math.max(1, step - 1))}
              disabled={step === 1}
              className="btn-secondary disabled:opacity-50"
            >
              Geri
            </button>

            {step < 3 ? (
              <button
                onClick={() => setStep(step + 1)}
                className="btn-primary"
              >
                İleri
              </button>
            ) : (
              <button
                onClick={handleCreate}
                disabled={isLoading}
                className="btn-primary flex items-center gap-2"
              >
                <Save className="w-4 h-4" />
                {isLoading ? 'Oluşturuluyor...' : 'Bot Oluştur'}
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default BotBuilder;
