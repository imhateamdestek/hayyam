import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../../hooks/useAuthStore';
import {
  Bot,
  Plus,
  Search,
  Star,
  Code,
  Globe,
  ChevronRight,
  MessageSquare,
  Terminal
} from 'lucide-react';

const BotStore = () => {
  const [myBots, setMyBots] = useState([]);
  const [publicBots, setPublicBots] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState('my');
  const navigate = useNavigate();

  useEffect(() => {
    fetchBots();
  }, []);

  const fetchBots = async () => {
    try {
      const [myResponse, publicResponse] = await Promise.all([
        api.get('/api/bots/list'),
        api.get('/api/bots/public')
      ]);

      setMyBots(myResponse.data.data?.bots || []);
      setPublicBots(publicResponse.data.data?.bots || []);
    } catch (error) {
      console.error('Failed to fetch bots:', error);
    } finally {
      setLoading(false);
    }
  };

  const filteredPublicBots = publicBots.filter(bot =>
    bot.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    bot.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
    bot.description?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="p-4 border-b border-slate-700">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold">Botlar</h2>
          <button 
            onClick={() => navigate('/bots/builder')}
            className="btn-primary flex items-center gap-2"
          >
            <Plus className="w-4 h-4" />
            <span className="hidden sm:inline">Bot Oluştur</span>
          </button>
        </div>

        {/* Search */}
        <div className="relative mb-4">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            placeholder="Bot ara..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="input pl-10"
          />
        </div>

        {/* Tabs */}
        <div className="flex gap-2">
          <button
            onClick={() => setActiveTab('my')}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors
              ${activeTab === 'my' ? 'bg-indigo-600 text-white' : 'bg-slate-800 text-slate-400 hover:text-white'}`}
          >
            Botlarım
          </button>
          <button
            onClick={() => setActiveTab('public')}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors
              ${activeTab === 'public' ? 'bg-indigo-600 text-white' : 'bg-slate-800 text-slate-400 hover:text-white'}`}
          >
            Bot Mağazası
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-4">
        {loading ? (
          <div className="flex items-center justify-center h-32">
            <div className="w-8 h-8 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin" />
          </div>
        ) : activeTab === 'my' ? (
          <div className="space-y-3">
            {myBots.length === 0 ? (
              <div className="text-center py-12">
                <Bot className="w-12 h-12 mx-auto mb-4 text-slate-600" />
                <p className="text-slate-400 mb-4">Henüz bot oluşturmadınız</p>
                <button 
                  onClick={() => navigate('/bots/builder')}
                  className="btn-primary"
                >
                  İlk Botunu Oluştur
                </button>
              </div>
            ) : (
              myBots.map((bot) => (
                <div key={bot.id} className="card hover:border-indigo-500/50 transition-colors cursor-pointer">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 
                                  flex items-center justify-center">
                      <Bot className="w-6 h-6 text-white" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <h3 className="font-medium">{bot.name}</h3>
                        <span className="text-xs text-slate-500">@{bot.username}</span>
                      </div>
                      <p className="text-sm text-slate-400 mt-1">{bot.description}</p>
                      <div className="flex items-center gap-4 mt-3 text-xs text-slate-500">
                        <span className="flex items-center gap-1">
                          <Code className="w-3 h-3" />
                          {bot.language}
                        </span>
                        <span className="flex items-center gap-1">
                          <MessageSquare className="w-3 h-3" />
                          {bot.conversation_count} konuşma
                        </span>
                        <span className="flex items-center gap-1">
                          <Terminal className="w-3 h-3" />
                          {bot.command_count} komut
                        </span>
                      </div>
                    </div>
                    <ChevronRight className="w-5 h-5 text-slate-600" />
                  </div>
                </div>
              ))
            )}
          </div>
        ) : (
          <div className="space-y-3">
            {filteredPublicBots.length === 0 ? (
              <div className="text-center py-12 text-slate-400">
                <Search className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p>Bot bulunamadı</p>
              </div>
            ) : (
              filteredPublicBots.map((bot) => (
                <div key={bot.id} className="card hover:border-indigo-500/50 transition-colors">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 rounded-xl bg-slate-700 flex items-center justify-center">
                      <Bot className="w-6 h-6 text-indigo-400" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <h3 className="font-medium">{bot.name}</h3>
                        <span className="text-xs text-slate-500">@{bot.username}</span>
                        {bot.is_public && (
                          <span className="px-2 py-0.5 bg-emerald-500/10 text-emerald-400 text-xs rounded-full">
                            Public
                          </span>
                        )}
                      </div>
                      <p className="text-sm text-slate-400 mt-1">{bot.description}</p>
                      <div className="flex items-center gap-4 mt-3 text-xs text-slate-500">
                        <span className="flex items-center gap-1">
                          <Globe className="w-3 h-3" />
                          {bot.owner_name}
                        </span>
                        <span className="flex items-center gap-1">
                          <Code className="w-3 h-3" />
                          {bot.language}
                        </span>
                      </div>
                    </div>
                    <button className="btn-primary text-sm py-2 px-4">
                      Ekle
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default BotStore;
