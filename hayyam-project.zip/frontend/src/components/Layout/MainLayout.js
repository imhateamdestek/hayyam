import React, { useState } from 'react';
import { Outlet, NavLink, useLocation } from 'react-router-dom';
import { useAuthStore } from '../../hooks/useAuthStore';
import { useMeshStore } from '../../hooks/useMeshStore';
import {
  MessageCircle,
  Users,
  Radio,
  Settings,
  Bot,
  ShieldAlert,
  Menu,
  X,
  Wifi,
  WifiOff,
  Bluetooth
} from 'lucide-react';

const MainLayout = () => {
  const { user, logout } = useAuthStore();
  const { isDisasterMode, isMeshEnabled } = useMeshStore();
  const [isSidebarOpen, setSidebarOpen] = useState(false);
  const location = useLocation();

  const navItems = [
    { path: '/', icon: MessageCircle, label: 'Mesajlar' },
    { path: '/wall', icon: Users, label: 'Duvar' },
    { path: '/bots', icon: Bot, label: 'Botlar' },
    { path: '/disaster', icon: ShieldAlert, label: 'Afet Modu' },
    { path: '/settings', icon: Settings, label: 'Ayarlar' }
  ];

  const isActive = (path) => location.pathname === path || location.pathname.startsWith(path + '/');

  return (
    <div className="flex h-screen bg-slate-900 text-white overflow-hidden">
      {/* Desktop Sidebar */}
      <aside className={`
        fixed inset-y-0 left-0 z-50 w-64 bg-slate-800 border-r border-slate-700
        transform transition-transform duration-300 ease-in-out
        lg:relative lg:translate-x-0
        ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'}
      `}>
        <div className="flex flex-col h-full">
          {/* Logo */}
          <div className="flex items-center justify-between p-4 border-b border-slate-700">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 
                            flex items-center justify-center shadow-lg shadow-indigo-500/30">
                <Radio className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gradient">Hayyam</h1>
                <p className="text-xs text-slate-400">Güvenli Mesajlaşma</p>
              </div>
            </div>
            <button onClick={() => setSidebarOpen(false)} className="lg:hidden p-2 hover:bg-slate-700 rounded-lg">
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Navigation */}
          <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
            {navItems.map((item) => (
              <NavLink
                key={item.path}
                to={item.path}
                onClick={() => setSidebarOpen(false)}
                className={`
                  flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200
                  ${isActive(item.path) 
                    ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/20' 
                    : 'text-slate-400 hover:bg-slate-700 hover:text-white'}
                `}
              >
                <item.icon className="w-5 h-5" />
                <span className="font-medium">{item.label}</span>
                {item.path === '/disaster' && isDisasterMode && (
                  <span className="ml-auto w-2 h-2 bg-red-500 rounded-full animate-pulse" />
                )}
              </NavLink>
            ))}
          </nav>

          {/* User Profile */}
          <div className="p-4 border-t border-slate-700">
            <div className="flex items-center gap-3">
              <img 
                src={user?.avatar_url || `https://api.dicebear.com/7.x/avataaars/svg?seed=${user?.username}`}
                alt={user?.display_name}
                className="w-10 h-10 rounded-full bg-slate-700"
              />
              <div className="flex-1 min-w-0">
                <p className="font-medium truncate">{user?.display_name}</p>
                <p className="text-sm text-slate-400 truncate">@{user?.username}</p>
              </div>
            </div>
            <button 
              onClick={logout}
              className="mt-3 w-full py-2 text-sm text-red-400 hover:bg-red-500/10 rounded-lg transition-colors"
            >
              Çıkış Yap
            </button>
          </div>
        </div>
      </aside>

      {/* Mobile Header */}
      <div className="lg:hidden fixed top-0 left-0 right-0 z-40 bg-slate-800/95 backdrop-blur-xl 
                      border-b border-slate-700 safe-area-top">
        <div className="flex items-center justify-between px-4 py-3">
          <button onClick={() => setSidebarOpen(true)} className="p-2 hover:bg-slate-700 rounded-lg">
            <Menu className="w-5 h-5" />
          </button>
          <h1 className="text-lg font-bold text-gradient">Hayyam</h1>
          <div className="flex items-center gap-2">
            {isMeshEnabled && <Bluetooth className="w-4 h-4 text-emerald-400" />}
            {isDisasterMode && <ShieldAlert className="w-5 h-5 text-red-500 animate-pulse" />}
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="flex-1 overflow-hidden lg:pt-0 pt-14">
        <div className="h-full overflow-y-auto">
          <Outlet />
        </div>
      </main>

      {/* Mobile Bottom Nav */}
      <nav className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-slate-800/95 backdrop-blur-xl 
                      border-t border-slate-700 safe-area-bottom">
        <div className="flex items-center justify-around px-2 py-2">
          {navItems.slice(0, 4).map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive }) => `
                flex flex-col items-center gap-1 p-2 rounded-lg transition-colors
                ${isActive ? 'text-indigo-400' : 'text-slate-400'}
              `}
            >
              <item.icon className="w-5 h-5" />
              <span className="text-[10px] font-medium">{item.label}</span>
            </NavLink>
          ))}
        </div>
      </nav>

      {/* Overlay */}
      {isSidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}
    </div>
  );
};

export default MainLayout;
