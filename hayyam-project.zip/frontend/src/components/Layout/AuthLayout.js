import React from 'react';
import { Outlet } from 'react-router-dom';
import { Radio } from 'lucide-react';

const AuthLayout = () => {
  return (
    <div className="min-h-screen bg-slate-900 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 mx-auto rounded-2xl bg-gradient-to-br from-indigo-500 to-purple-600 
                        flex items-center justify-center shadow-xl shadow-indigo-500/30 mb-4">
            <Radio className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-gradient">Hayyam</h1>
          <p className="text-slate-400 mt-2">Güvenli Mesajlaşma</p>
        </div>

        {/* Content */}
        <div className="card">
          <Outlet />
        </div>

        {/* Footer */}
        <p className="text-center text-sm text-slate-500 mt-6">
          Deprem ve afet anlarında bile çalışan mesajlaşma
        </p>
      </div>
    </div>
  );
};

export default AuthLayout;
