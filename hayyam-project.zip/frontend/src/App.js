import React, { useEffect } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { useAuthStore } from './hooks/useAuthStore';
import { useMeshStore } from './hooks/useMeshStore';

// Layouts
import MainLayout from './components/Layout/MainLayout';
import AuthLayout from './components/Layout/AuthLayout';

// Pages
import Login from './pages/Auth/Login';
import Register from './pages/Auth/Register';
import VerifyEmail from './pages/Auth/VerifyEmail';
import ChatList from './pages/Chat/ChatList';
import ChatRoom from './pages/Chat/ChatRoom';
import Wall from './pages/Wall/Wall';
import WallDetail from './pages/Wall/WallDetail';
import Profile from './pages/Profile/Profile';
import Settings from './pages/Settings/Settings';
import BotStore from './pages/Bots/BotStore';
import BotBuilder from './pages/Bots/BotBuilder';
import DisasterMode from './pages/Disaster/DisasterMode';
import NearbyUsers from './pages/Disaster/NearbyUsers';
import NotFound from './pages/NotFound';

function App() {
  const { user, checkAuth } = useAuthStore();
  const { initMesh } = useMeshStore();

  useEffect(() => {
    checkAuth();
  }, [checkAuth]);

  useEffect(() => {
    if (user) {
      initMesh();
    }
  }, [user, initMesh]);

  return (
    <>
      <Toaster 
        position="top-right"
        toastOptions={{
          duration: 4000,
          style: {
            background: '#1e293b',
            color: '#fff',
            border: '1px solid #334155'
          }
        }}
      />
      <Routes>
        {/* Auth Routes */}
        <Route element={<AuthLayout />}>
          <Route path="/login" element={!user ? <Login /> : <Navigate to="/" />} />
          <Route path="/register" element={!user ? <Register /> : <Navigate to="/" />} />
          <Route path="/verify-email" element={<VerifyEmail />} />
        </Route>

        {/* Main Routes */}
        <Route element={<MainLayout />}>
          <Route path="/" element={user ? <ChatList /> : <Navigate to="/login" />} />
          <Route path="/messages" element={user ? <ChatList /> : <Navigate to="/login" />} />
          <Route path="/messages/:conversationId" element={user ? <ChatRoom /> : <Navigate to="/login" />} />
          <Route path="/wall" element={user ? <Wall /> : <Navigate to="/login" />} />
          <Route path="/wall/:username" element={user ? <WallDetail /> : <Navigate to="/login" />} />
          <Route path="/profile" element={user ? <Profile /> : <Navigate to="/login" />} />
          <Route path="/profile/:username" element={user ? <Profile /> : <Navigate to="/login" />} />
          <Route path="/settings" element={user ? <Settings /> : <Navigate to="/login" />} />
          <Route path="/bots" element={user ? <BotStore /> : <Navigate to="/login" />} />
          <Route path="/bots/builder" element={user ? <BotBuilder /> : <Navigate to="/login" />} />
          <Route path="/disaster" element={user ? <DisasterMode /> : <Navigate to="/login" />} />
          <Route path="/disaster/nearby" element={user ? <NearbyUsers /> : <Navigate to="/login" />} />
        </Route>

        <Route path="*" element={<NotFound />} />
      </Routes>
    </>
  );
}

export default App;
