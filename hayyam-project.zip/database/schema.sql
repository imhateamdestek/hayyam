-- Hayyam Mesajlaşma Uygulaması - Veritabanı Şeması
-- Versiyon: 1.0.0
-- Karakter Seti: utf8mb4_unicode_ci

CREATE DATABASE IF NOT EXISTS hayyam CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE hayyam;

-- ==========================================
-- 1. KULLANICI YÖNETİMİ
-- ==========================================

CREATE TABLE users (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    uuid VARCHAR(36) NOT NULL UNIQUE COMMENT 'Evrensel benzersiz ID',
    username VARCHAR(32) NOT NULL UNIQUE COMMENT 'Kullanıcı adı (@kullanici)',
    email VARCHAR(255) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    display_name VARCHAR(100) NOT NULL,
    bio TEXT DEFAULT NULL COMMENT 'Biyografi',
    avatar_url VARCHAR(500) DEFAULT NULL,
    phone VARCHAR(20) DEFAULT NULL,
    public_key TEXT NOT NULL COMMENT 'RSA Public Key',
    private_key_encrypted TEXT NOT NULL COMMENT 'Şifrelenmiş Private Key',
    email_verified BOOLEAN DEFAULT FALSE,
    verification_token VARCHAR(255) DEFAULT NULL,
    reset_token VARCHAR(255) DEFAULT NULL,
    reset_expires DATETIME DEFAULT NULL,
    last_seen DATETIME DEFAULT NULL,
    status ENUM('online', 'offline', 'away') DEFAULT 'offline',
    is_bot BOOLEAN DEFAULT FALSE,
    bot_language VARCHAR(20) DEFAULT NULL COMMENT 'Python, JavaScript vb.',
    bot_webhook VARCHAR(500) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE,
    is_admin BOOLEAN DEFAULT FALSE,
    INDEX idx_username (username),
    INDEX idx_email (email),
    INDEX idx_uuid (uuid)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==========================================
-- 2. MESAJLAŞMA SİSTEMİ
-- ==========================================

CREATE TABLE conversations (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    uuid VARCHAR(36) NOT NULL UNIQUE,
    type ENUM('private', 'group', 'channel') DEFAULT 'private',
    title VARCHAR(255) DEFAULT NULL,
    avatar_url VARCHAR(500) DEFAULT NULL,
    creator_id BIGINT UNSIGNED,
    is_encrypted BOOLEAN DEFAULT TRUE,
    encryption_key_id VARCHAR(255) DEFAULT NULL,
    last_message_id BIGINT UNSIGNED DEFAULT NULL,
    last_message_at DATETIME DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (creator_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_type (type),
    INDEX idx_last_message_at (last_message_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE conversation_members (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    conversation_id BIGINT UNSIGNED NOT NULL,
    user_id BIGINT UNSIGNED NOT NULL,
    role ENUM('owner', 'admin', 'member') DEFAULT 'member',
    joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_read_message_id BIGINT UNSIGNED DEFAULT NULL,
    is_pinned BOOLEAN DEFAULT FALSE,
    notification_settings JSON DEFAULT NULL,
    UNIQUE KEY unique_member (conversation_id, user_id),
    FOREIGN KEY (conversation_id) REFERENCES conversations(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_conversations (user_id, joined_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE messages (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    uuid VARCHAR(36) NOT NULL UNIQUE,
    conversation_id BIGINT UNSIGNED NOT NULL,
    sender_id BIGINT UNSIGNED NOT NULL,
    reply_to_id BIGINT UNSIGNED DEFAULT NULL,
    type ENUM('text', 'image', 'video', 'audio', 'file', 'location', 'contact', 'system') DEFAULT 'text',
    content TEXT NOT NULL COMMENT 'Şifrelenmiş içerik veya metadata',
    content_encrypted BOOLEAN DEFAULT TRUE,
    file_url VARCHAR(500) DEFAULT NULL,
    file_name VARCHAR(255) DEFAULT NULL,
    file_size INT UNSIGNED DEFAULT NULL,
    mime_type VARCHAR(100) DEFAULT NULL,
    duration INT DEFAULT NULL COMMENT 'Ses/video süresi (saniye)',
    latitude DECIMAL(10,8) DEFAULT NULL,
    longitude DECIMAL(11,8) DEFAULT NULL,
    is_edited BOOLEAN DEFAULT FALSE,
    edited_at DATETIME DEFAULT NULL,
    is_deleted BOOLEAN DEFAULT FALSE,
    deleted_at DATETIME DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (conversation_id) REFERENCES conversations(id) ON DELETE CASCADE,
    FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (reply_to_id) REFERENCES messages(id) ON DELETE SET NULL,
    INDEX idx_conversation_created (conversation_id, created_at),
    INDEX idx_sender (sender_id),
    INDEX idx_uuid (uuid)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==========================================
-- 3. OFLİNE / MESH AĞ MESAJLARI
-- ==========================================

CREATE TABLE offline_messages (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    uuid VARCHAR(36) NOT NULL UNIQUE,
    original_message_uuid VARCHAR(36) NOT NULL,
    sender_id BIGINT UNSIGNED NOT NULL,
    recipient_id BIGINT UNSIGNED NOT NULL,
    content_encrypted TEXT NOT NULL COMMENT 'Şifrelenmiş mesaj',
    encryption_iv VARCHAR(255) NOT NULL,
    hop_count INT DEFAULT 0 COMMENT 'Kaç cihazdan geçti',
    max_hops INT DEFAULT 10,
    ttl INT DEFAULT 86400 COMMENT 'Time to live (saniye)',
    delivery_method ENUM('bluetooth', 'wifi_direct', 'mesh', 'pending') DEFAULT 'pending',
    status ENUM('pending', 'transit', 'delivered', 'expired') DEFAULT 'pending',
    device_fingerprint VARCHAR(255) DEFAULT NULL COMMENT 'Son ileten cihaz',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expires_at DATETIME NOT NULL,
    delivered_at DATETIME DEFAULT NULL,
    FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (recipient_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_recipient_status (recipient_id, status),
    INDEX idx_expires (expires_at),
    INDEX idx_original_uuid (original_message_uuid)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE mesh_routing (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    device_id VARCHAR(255) NOT NULL COMMENT 'Cihaz MAC/BT adresi',
    user_id BIGINT UNSIGNED DEFAULT NULL,
    last_seen DATETIME NOT NULL,
    signal_strength INT DEFAULT NULL COMMENT 'RSSI değeri',
    hop_distance INT DEFAULT 0 COMMENT 'Kaç atlamalık mesafe',
    is_online BOOLEAN DEFAULT FALSE,
    capabilities JSON DEFAULT NULL COMMENT 'WiFi, BT, Internet desteği',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_device (device_id),
    INDEX idx_last_seen (last_seen),
    INDEX idx_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==========================================
-- 4. SOSYAL DUVAR SİSTEMİ
-- ==========================================

CREATE TABLE walls (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL,
    uuid VARCHAR(36) NOT NULL UNIQUE,
    type ENUM('text', 'image', 'video', 'quote', 'link') DEFAULT 'text',
    content TEXT NOT NULL,
    media_urls JSON DEFAULT NULL,
    background_color VARCHAR(7) DEFAULT NULL,
    text_color VARCHAR(7) DEFAULT NULL,
    font_style VARCHAR(50) DEFAULT NULL,
    is_pinned BOOLEAN DEFAULT FALSE,
    pinned_until DATETIME DEFAULT NULL,
    view_count INT UNSIGNED DEFAULT 0,
    like_count INT UNSIGNED DEFAULT 0,
    comment_count INT UNSIGNED DEFAULT 0,
    share_count INT UNSIGNED DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_created (user_id, created_at),
    INDEX idx_type (type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE wall_likes (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    wall_id BIGINT UNSIGNED NOT NULL,
    user_id BIGINT UNSIGNED NOT NULL,
    reaction_type ENUM('like', 'love', 'laugh', 'sad', 'angry') DEFAULT 'like',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_like (wall_id, user_id),
    FOREIGN KEY (wall_id) REFERENCES walls(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE wall_comments (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    wall_id BIGINT UNSIGNED NOT NULL,
    user_id BIGINT UNSIGNED NOT NULL,
    parent_id BIGINT UNSIGNED DEFAULT NULL,
    content TEXT NOT NULL,
    like_count INT UNSIGNED DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (wall_id) REFERENCES walls(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (parent_id) REFERENCES wall_comments(id) ON DELETE CASCADE,
    INDEX idx_wall (wall_id, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE wall_tags (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    wall_id BIGINT UNSIGNED NOT NULL,
    tagged_user_id BIGINT UNSIGNED NOT NULL,
    tag_position_x DECIMAL(5,2) DEFAULT NULL,
    tag_position_y DECIMAL(5,2) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (wall_id) REFERENCES walls(id) ON DELETE CASCADE,
    FOREIGN KEY (tagged_user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_tag (wall_id, tagged_user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==========================================
-- 5. BOT SİSTEMİ
-- ==========================================

CREATE TABLE bots (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    uuid VARCHAR(36) NOT NULL UNIQUE,
    owner_id BIGINT UNSIGNED NOT NULL,
    name VARCHAR(100) NOT NULL,
    username VARCHAR(32) NOT NULL UNIQUE,
    description TEXT DEFAULT NULL,
    avatar_url VARCHAR(500) DEFAULT NULL,
    language ENUM('python', 'javascript', 'php', 'custom') DEFAULT 'python',
    source_code TEXT DEFAULT NULL COMMENT 'Bot kaynak kodu',
    webhook_url VARCHAR(500) DEFAULT NULL,
    api_token VARCHAR(255) NOT NULL UNIQUE,
    is_active BOOLEAN DEFAULT TRUE,
    is_public BOOLEAN DEFAULT FALSE COMMENT 'Başkaları kullanabilir mi?',
    allowed_commands JSON DEFAULT NULL,
    rate_limit INT DEFAULT 30 COMMENT 'Dakikada max istek',
    last_activity DATETIME DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (owner_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_owner (owner_id),
    INDEX idx_username (username)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE bot_commands (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    bot_id BIGINT UNSIGNED NOT NULL,
    command VARCHAR(50) NOT NULL COMMENT '/komut',
    description VARCHAR(255) NOT NULL,
    parameters JSON DEFAULT NULL,
    response_template TEXT DEFAULT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (bot_id) REFERENCES bots(id) ON DELETE CASCADE,
    UNIQUE KEY unique_command (bot_id, command)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE bot_conversations (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    bot_id BIGINT UNSIGNED NOT NULL,
    user_id BIGINT UNSIGNED NOT NULL,
    conversation_id BIGINT UNSIGNED NOT NULL,
    context_data JSON DEFAULT NULL COMMENT 'Sohbet bağlamı',
    last_interaction DATETIME DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (bot_id) REFERENCES bots(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (conversation_id) REFERENCES conversations(id) ON DELETE CASCADE,
    UNIQUE KEY unique_bot_user (bot_id, user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==========================================
-- 6. KONTAKT VE ARKADAŞLIK
-- ==========================================

CREATE TABLE contacts (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL,
    contact_id BIGINT UNSIGNED NOT NULL,
    display_name VARCHAR(100) DEFAULT NULL COMMENT 'Kişiye özel isim',
    phone VARCHAR(20) DEFAULT NULL,
    email VARCHAR(255) DEFAULT NULL,
    is_blocked BOOLEAN DEFAULT FALSE,
    is_favorite BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (contact_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_contact (user_id, contact_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE friend_requests (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    sender_id BIGINT UNSIGNED NOT NULL,
    receiver_id BIGINT UNSIGNED NOT NULL,
    status ENUM('pending', 'accepted', 'rejected', 'blocked') DEFAULT 'pending',
    message TEXT DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (receiver_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_request (sender_id, receiver_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==========================================
-- 7. MEDYA VE DOSYALAR
-- ==========================================

CREATE TABLE media_files (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    uuid VARCHAR(36) NOT NULL UNIQUE,
    user_id BIGINT UNSIGNED NOT NULL,
    file_name VARCHAR(255) NOT NULL,
    original_name VARCHAR(255) NOT NULL,
    file_path VARCHAR(500) NOT NULL,
    file_size BIGINT UNSIGNED NOT NULL,
    mime_type VARCHAR(100) NOT NULL,
    width INT UNSIGNED DEFAULT NULL,
    height INT UNSIGNED DEFAULT NULL,
    duration INT DEFAULT NULL,
    thumbnail_path VARCHAR(500) DEFAULT NULL,
    is_encrypted BOOLEAN DEFAULT TRUE,
    encryption_key VARCHAR(255) DEFAULT NULL,
    download_count INT UNSIGNED DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user (user_id),
    INDEX idx_mime (mime_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==========================================
-- 8. BİLDİRİMLER VE AKTİVİTE
-- ==========================================

CREATE TABLE notifications (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL,
    type ENUM('message', 'friend_request', 'wall_like', 'wall_comment', 'mention', 'system') NOT NULL,
    title VARCHAR(255) NOT NULL,
    body TEXT NOT NULL,
    data JSON DEFAULT NULL,
    is_read BOOLEAN DEFAULT FALSE,
    read_at DATETIME DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_unread (user_id, is_read),
    INDEX idx_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE user_sessions (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL,
    token VARCHAR(512) NOT NULL UNIQUE,
    device_info VARCHAR(255) DEFAULT NULL,
    ip_address VARCHAR(45) DEFAULT NULL,
    is_valid BOOLEAN DEFAULT TRUE,
    last_activity DATETIME DEFAULT CURRENT_TIMESTAMP,
    expires_at DATETIME NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_token (token),
    INDEX idx_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==========================================
-- 9. AYARLAR VE YAPILANDIRMA
-- ==========================================

CREATE TABLE user_settings (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL UNIQUE,
    theme ENUM('light', 'dark', 'system') DEFAULT 'system',
    language VARCHAR(10) DEFAULT 'tr',
    notifications_enabled BOOLEAN DEFAULT TRUE,
    sound_enabled BOOLEAN DEFAULT TRUE,
    vibration_enabled BOOLEAN DEFAULT TRUE,
    privacy_profile ENUM('public', 'friends', 'private') DEFAULT 'public',
    privacy_last_seen ENUM('everyone', 'friends', 'nobody') DEFAULT 'everyone',
    privacy_wall ENUM('public', 'friends', 'private') DEFAULT 'public',
    auto_download_mobile BOOLEAN DEFAULT FALSE,
    auto_download_wifi BOOLEAN DEFAULT TRUE,
    mesh_enabled BOOLEAN DEFAULT TRUE,
    bluetooth_enabled BOOLEAN DEFAULT TRUE,
    wifi_direct_enabled BOOLEAN DEFAULT TRUE,
    disaster_mode_enabled BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE app_settings (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    setting_key VARCHAR(100) NOT NULL UNIQUE,
    setting_value TEXT NOT NULL,
    setting_type ENUM('string', 'integer', 'boolean', 'json') DEFAULT 'string',
    description VARCHAR(255) DEFAULT NULL,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Varsayılan uygulama ayarları
INSERT INTO app_settings (setting_key, setting_value, setting_type, description) VALUES
('app_name', 'Hayyam', 'string', 'Uygulama adı'),
('app_version', '1.0.0', 'string', 'Uygulama versiyonu'),
('max_file_size', '104857600', 'integer', 'Max dosya boyutu (bytes) - 100MB'),
('message_ttl', '2592000', 'integer', 'Mesaj saklama süresi (saniye) - 30 gün'),
('mesh_max_hops', '10', 'integer', 'Mesh network max hop sayısı'),
('encryption_algorithm', 'AES-256-GCM', 'string', 'Şifreleme algoritması'),
('maintenance_mode', 'false', 'boolean', 'Bakım modu'),
('registration_enabled', 'true', 'boolean', 'Yeni kayıt aktif mi?');

-- ==========================================
-- 10. RAPORLAMA VE LOG
-- ==========================================

CREATE TABLE reports (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    reporter_id BIGINT UNSIGNED NOT NULL,
    reported_type ENUM('user', 'message', 'wall', 'bot') NOT NULL,
    reported_id BIGINT UNSIGNED NOT NULL,
    reason ENUM('spam', 'harassment', 'violence', 'illegal', 'other') NOT NULL,
    description TEXT DEFAULT NULL,
    status ENUM('pending', 'reviewing', 'resolved', 'dismissed') DEFAULT 'pending',
    moderator_id BIGINT UNSIGNED DEFAULT NULL,
    moderator_note TEXT DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    resolved_at DATETIME DEFAULT NULL,
    FOREIGN KEY (reporter_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (moderator_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==========================================
-- 11. DEPREM / AFET MODU LOG
-- ==========================================

CREATE TABLE disaster_logs (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL,
    event_type ENUM('enter_disaster_mode', 'exit_disaster_mode', 'mesh_message_sent', 'mesh_message_received', 'bluetooth_scan', 'wifi_direct_connect') NOT NULL,
    latitude DECIMAL(10,8) DEFAULT NULL,
    longitude DECIMAL(11,8) DEFAULT NULL,
    accuracy DECIMAL(10,2) DEFAULT NULL,
    device_info TEXT DEFAULT NULL,
    battery_level INT DEFAULT NULL,
    network_type VARCHAR(50) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_event (user_id, event_type),
    INDEX idx_location (latitude, longitude),
    INDEX idx_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==========================================
-- GÖRÜNÜMLER (VIEWS)
-- ==========================================

CREATE VIEW user_conversations AS
SELECT 
    cm.user_id,
    c.id as conversation_id,
    c.uuid,
    c.type,
    c.title,
    c.avatar_url,
    c.last_message_at,
    cm.role,
    cm.joined_at,
    cm.last_read_message_id,
    (SELECT COUNT(*) FROM messages m 
     WHERE m.conversation_id = c.id 
     AND m.id > COALESCE(cm.last_read_message_id, 0)
     AND m.sender_id != cm.user_id
     AND m.is_deleted = FALSE) as unread_count
FROM conversation_members cm
JOIN conversations c ON cm.conversation_id = c.id
WHERE cm.user_id IS NOT NULL;

-- ==========================================
-- TRIGGER'LAR
-- ==========================================

DELIMITER //

CREATE TRIGGER after_message_insert 
AFTER INSERT ON messages
FOR EACH ROW
BEGIN
    UPDATE conversations 
    SET last_message_id = NEW.id,
        last_message_at = NEW.created_at,
        updated_at = NOW()
    WHERE id = NEW.conversation_id;
END//

CREATE TRIGGER after_user_insert
AFTER INSERT ON users
FOR EACH ROW
BEGIN
    INSERT INTO user_settings (user_id) VALUES (NEW.id);
END//

DELIMITER ;

-- ==========================================
-- BAŞLANGIÇ VERİLERİ
-- ==========================================

INSERT INTO users (uuid, username, email, password_hash, display_name, public_key, private_key_encrypted, is_admin, email_verified) VALUES
('550e8400-e29b-41d4-a716-446655440000', 'hayyam_bot', 'bot@hayyam.app', 
 '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 
 'Hayyam Bot', 
 '-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA...
-----END PUBLIC KEY-----',
 '-----BEGIN ENCRYPTED PRIVATE KEY-----
MIIEpAIBAAKCAQEA...
-----END ENCRYPTED PRIVATE KEY-----',
 TRUE, TRUE);
