<?php
/**
 * Hayyam - Installation Wizard
 * İlk kurulum için web arayüzü
 */

header('Content-Type: text/html; charset=utf-8');

$step = $_GET['step'] ?? 1;
$errors = [];
$success = false;

// Requirements check
function checkRequirements() {
    $requirements = [
        'PHP >= 8.0' => version_compare(PHP_VERSION, '8.0.0', '>='),
        'PDO Extension' => extension_loaded('pdo'),
        'PDO MySQL' => extension_loaded('pdo_mysql'),
        'OpenSSL' => extension_loaded('openssl'),
        'JSON' => extension_loaded('json'),
        'MBString' => extension_loaded('mbstring'),
        'GD/ImageMagick' => extension_loaded('gd') || extension_loaded('imagick'),
        'Write Permissions' => is_writable(__DIR__ . '/../') && is_writable(__DIR__ . '/../../uploads/'),
        '.env Writable' => is_writable(__DIR__ . '/../') || !file_exists(__DIR__ . '/../.env')
    ];
    return $requirements;
}

// Database connection test
function testDatabase($host, $user, $pass, $name) {
    try {
        $dsn = "mysql:host=$host;charset=utf8mb4";
        $pdo = new PDO($dsn, $user, $pass);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Create database if not exists
        $pdo->exec("CREATE DATABASE IF NOT EXISTS `$name` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");

        return [true, null];
    } catch (PDOException $e) {
        return [false, $e->getMessage()];
    }
}

// Run SQL schema
function runSchema($host, $user, $pass, $name) {
    try {
        $dsn = "mysql:host=$host;dbname=$name;charset=utf8mb4";
        $pdo = new PDO($dsn, $user, $pass);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $sql = file_get_contents(__DIR__ . '/../../database/schema.sql');

        // Split by delimiter
        $statements = array_filter(array_map('trim', explode(';', $sql)));

        foreach ($statements as $statement) {
            if (!empty($statement)) {
                $pdo->exec($statement);
            }
        }

        return [true, null];
    } catch (PDOException $e) {
        return [false, $e->getMessage()];
    }
}

// Create .env file
function createEnvFile($data) {
    $envContent = "# Hayyam Configuration\n";
    $envContent .= "APP_NAME=Hayyam\n";
    $envContent .= "APP_ENV=production\n";
    $envContent .= "APP_URL={$data['app_url']}\n";
    $envContent .= "APP_DEBUG=false\n\n";

    $envContent .= "# Database\n";
    $envContent .= "DB_HOST={$data['db_host']}\n";
    $envContent .= "DB_NAME={$data['db_name']}\n";
    $envContent .= "DB_USER={$data['db_user']}\n";
    $envContent .= "DB_PASS={$data['db_pass']}\n";
    $envContent .= "DB_CHARSET=utf8mb4\n\n";

    $envContent .= "# Security\n";
    $envContent .= "JWT_SECRET=" . bin2hex(random_bytes(32)) . "\n";
    $envContent .= "AES_KEY=" . bin2hex(random_bytes(32)) . "\n\n";

    $envContent .= "# WebSocket\n";
    $envContent .= "WS_URL={$data['ws_url']}\n\n";

    $envContent .= "# Mail\n";
    $envContent .= "MAIL_HOST={$data['mail_host']}\n";
    $envContent .= "MAIL_PORT={$data['mail_port']}\n";
    $envContent .= "MAIL_USER={$data['mail_user']}\n";
    $envContent .= "MAIL_PASS={$data['mail_pass']}\n";
    $envContent .= "MAIL_FROM={$data['mail_from']}\n\n";

    $envContent .= "# Uploads\n";
    $envContent .= "MAX_FILE_SIZE=104857600\n";
    $envContent .= "UPLOAD_PATH=/uploads/\n";

    $envPath = __DIR__ . '/../.env';

    if (file_put_contents($envPath, $envContent)) {
        return [true, null];
    }

    return [false, 'Failed to write .env file'];
}

// Handle POST requests
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($step == 2) {
        // Database configuration
        $dbHost = $_POST['db_host'] ?? 'localhost';
        $dbUser = $_POST['db_user'] ?? '';
        $dbPass = $_POST['db_pass'] ?? '';
        $dbName = $_POST['db_name'] ?? 'hayyam';

        list($success, $error) = testDatabase($dbHost, $dbUser, $dbPass, $dbName);

        if ($success) {
            $_SESSION['db_config'] = compact('dbHost', 'dbUser', 'dbPass', 'dbName');
            header('Location: ?step=3');
            exit;
        } else {
            $errors[] = "Database connection failed: $error";
        }
    }

    if ($step == 3) {
        // Admin account
        $adminUser = $_POST['admin_username'] ?? '';
        $adminPass = $_POST['admin_password'] ?? '';
        $adminEmail = $_POST['admin_email'] ?? '';
        $adminName = $_POST['admin_name'] ?? '';

        if (strlen($adminPass) < 8) {
            $errors[] = "Admin password must be at least 8 characters";
        }

        if (empty($errors)) {
            $dbConfig = $_SESSION['db_config'] ?? [];

            // Run schema
            list($schemaSuccess, $schemaError) = runSchema(
                $dbConfig['dbHost'] ?? 'localhost',
                $dbConfig['dbUser'] ?? '',
                $dbConfig['dbPass'] ?? '',
                $dbConfig['dbName'] ?? 'hayyam'
            );

            if ($schemaSuccess) {
                // Create admin user
                $dsn = "mysql:host={$dbConfig['dbHost']};dbname={$dbConfig['dbName']};charset=utf8mb4";
                $pdo = new PDO($dsn, $dbConfig['dbUser'], $dbConfig['dbPass']);

                $passwordHash = password_hash($adminPass, PASSWORD_ARGON2ID);
                $uuid = bin2hex(random_bytes(18));

                $stmt = $pdo->prepare("
                    INSERT INTO users (uuid, username, email, password_hash, display_name, 
                                     public_key, private_key_encrypted, is_admin, email_verified)
                    VALUES (?, ?, ?, ?, ?, 'admin_key', 'admin_private', TRUE, TRUE)
                ");
                $stmt->execute([$uuid, $adminUser, $adminEmail, $passwordHash, $adminName]);

                // Create .env
                $envData = [
                    'app_url' => $_POST['app_url'] ?? 'https://' . $_SERVER['HTTP_HOST'],
                    'db_host' => $dbConfig['dbHost'] ?? 'localhost',
                    'db_name' => $dbConfig['dbName'] ?? 'hayyam',
                    'db_user' => $dbConfig['dbUser'] ?? '',
                    'db_pass' => $dbConfig['dbPass'] ?? '',
                    'ws_url' => $_POST['ws_url'] ?? 'wss://' . $_SERVER['HTTP_HOST'] . ':8080',
                    'mail_host' => $_POST['mail_host'] ?? 'smtp.gmail.com',
                    'mail_port' => $_POST['mail_port'] ?? '587',
                    'mail_user' => $_POST['mail_user'] ?? '',
                    'mail_pass' => $_POST['mail_pass'] ?? '',
                    'mail_from' => $_POST['mail_from'] ?? 'noreply@hayyam.app'
                ];

                list($envSuccess, $envError) = createEnvFile($envData);

                if ($envSuccess) {
                    $success = true;
                    // Remove install directory warning
                    $warning = "Please remove the /install directory for security reasons.";
                } else {
                    $errors[] = $envError;
                }
            } else {
                $errors[] = "Schema execution failed: $schemaError";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hayyam - Kurulum</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: #0f172a;
            color: #f1f5f9;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .container {
            width: 100%;
            max-width: 600px;
            background: #1e293b;
            border-radius: 16px;
            border: 1px solid #334155;
            padding: 40px;
        }
        .logo {
            text-align: center;
            margin-bottom: 40px;
        }
        .logo h1 {
            font-size: 2.5rem;
            background: linear-gradient(135deg, #6366f1, #8b5cf6);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 8px;
        }
        .logo p { color: #94a3b8; }

        .steps {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin-bottom: 40px;
        }
        .step {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            background: #334155;
            color: #94a3b8;
        }
        .step.active {
            background: linear-gradient(135deg, #6366f1, #8b5cf6);
            color: white;
        }
        .step.completed { background: #22c55e; color: white; }

        h2 { margin-bottom: 20px; font-size: 1.5rem; }

        .requirement {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 12px;
            background: #0f172a;
            border-radius: 8px;
            margin-bottom: 8px;
        }
        .requirement.pass { border-left: 3px solid #22c55e; }
        .requirement.fail { border-left: 3px solid #ef4444; }
        .status { font-weight: bold; }
        .status.pass { color: #22c55e; }
        .status.fail { color: #ef4444; }

        .form-group { margin-bottom: 20px; }
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: #cbd5e1;
        }
        input, select {
            width: 100%;
            padding: 12px;
            background: #0f172a;
            border: 1px solid #334155;
            border-radius: 8px;
            color: #f1f5f9;
            font-size: 1rem;
        }
        input:focus, select:focus {
            outline: none;
            border-color: #6366f1;
        }

        .btn {
            width: 100%;
            padding: 14px;
            background: linear-gradient(135deg, #6366f1, #8b5cf6);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: opacity 0.2s;
        }
        .btn:hover { opacity: 0.9; }
        .btn:disabled { opacity: 0.5; cursor: not-allowed; }

        .error {
            background: #ef4444/10;
            border: 1px solid #ef4444;
            color: #ef4444;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
        }

        .success {
            text-align: center;
            padding: 40px;
        }
        .success h2 { color: #22c55e; }
        .success-icon {
            width: 80px;
            height: 80px;
            background: #22c55e;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
            font-size: 40px;
        }

        .warning {
            background: #f59e0b/10;
            border: 1px solid #f59e0b;
            color: #f59e0b;
            padding: 12px;
            border-radius: 8px;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="logo">
            <h1>Hayyam</h1>
            <p>Kurulum Sihirbazı</p>
        </div>

        <div class="steps">
            <div class="step <?php echo $step >= 1 ? 'active' : ''; ?> <?php echo $step > 1 ? 'completed' : ''; ?>">1</div>
            <div class="step <?php echo $step >= 2 ? 'active' : ''; ?> <?php echo $step > 2 ? 'completed' : ''; ?>">2</div>
            <div class="step <?php echo $step >= 3 ? 'active' : ''; ?>">3</div>
        </div>

        <?php if (!empty($errors)): ?>
            <div class="error">
                <?php foreach ($errors as $error): ?>
                    <p><?php echo htmlspecialchars($error); ?></p>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="success">
                <div class="success-icon">✓</div>
                <h2>Kurulum Tamamlandı!</h2>
                <p style="margin: 20px 0; color: #94a3b8;">
                    Hayyam başarıyla kuruldu. Artık uygulamayı kullanmaya başlayabilirsiniz.
                </p>
                <a href="/" class="btn" style="display: inline-block; text-decoration: none;">
                    Uygulamaya Git
                </a>
                <?php if (isset($warning)): ?>
                    <div class="warning">
                        ⚠️ <?php echo htmlspecialchars($warning); ?>
                    </div>
                <?php endif; ?>
            </div>
        <?php elseif ($step == 1): ?>
            <h2>Sistem Gereksinimleri</h2>
            <?php $requirements = checkRequirements(); ?>
            <?php foreach ($requirements as $name => $pass): ?>
                <div class="requirement <?php echo $pass ? 'pass' : 'fail'; ?>">
                    <span><?php echo htmlspecialchars($name); ?></span>
                    <span class="status <?php echo $pass ? 'pass' : 'fail'; ?>">
                        <?php echo $pass ? '✓' : '✗'; ?>
                    </span>
                </div>
            <?php endforeach; ?>

            <?php if (!in_array(false, $requirements, true)): ?>
                <a href="?step=2" class="btn" style="display: block; text-align: center; text-decoration: none; margin-top: 20px;">
                    Devam Et →
                </a>
            <?php else: ?>
                <p style="color: #ef4444; margin-top: 20px; text-align: center;">
                    Lütfen eksik gereksinimleri tamamlayın.
                </p>
            <?php endif; ?>

        <?php elseif ($step == 2): ?>
            <h2>Veritabanı Ayarları</h2>
            <form method="POST" action="?step=2">
                <div class="form-group">
                    <label>Veritabanı Sunucusu</label>
                    <input type="text" name="db_host" value="localhost" required>
                </div>
                <div class="form-group">
                    <label>Veritabanı Adı</label>
                    <input type="text" name="db_name" value="hayyam" required>
                </div>
                <div class="form-group">
                    <label>Kullanıcı Adı</label>
                    <input type="text" name="db_user" required>
                </div>
                <div class="form-group">
                    <label>Şifre</label>
                    <input type="password" name="db_pass">
                </div>
                <button type="submit" class="btn">Bağlantıyı Test Et ve Devam Et</button>
            </form>

        <?php elseif ($step == 3): ?>
            <h2>Yönetici Hesabı ve Ayarlar</h2>
            <form method="POST" action="?step=3">
                <h3 style="margin-bottom: 15px; color: #94a3b8;">Yönetici Bilgileri</h3>
                <div class="form-group">
                    <label>Kullanıcı Adı</label>
                    <input type="text" name="admin_username" required placeholder="admin">
                </div>
                <div class="form-group">
                    <label>Görünen Ad</label>
                    <input type="text" name="admin_name" required placeholder="Yönetici">
                </div>
                <div class="form-group">
                    <label>Email</label>
                    <input type="email" name="admin_email" required>
                </div>
                <div class="form-group">
                    <label>Şifre (en az 8 karakter)</label>
                    <input type="password" name="admin_password" required minlength="8">
                </div>

                <h3 style="margin: 25px 0 15px; color: #94a3b8;">Uygulama Ayarları</h3>
                <div class="form-group">
                    <label>Uygulama URL</label>
                    <input type="url" name="app_url" value="https://<?php echo $_SERVER['HTTP_HOST']; ?>" required>
                </div>
                <div class="form-group">
                    <label>WebSocket URL</label>
                    <input type="url" name="ws_url" value="wss://<?php echo $_SERVER['HTTP_HOST']; ?>:8080">
                </div>

                <h3 style="margin: 25px 0 15px; color: #94a3b8;">Mail Ayarları (İsteğe Bağlı)</h3>
                <div class="form-group">
                    <label>SMTP Sunucusu</label>
                    <input type="text" name="mail_host" placeholder="smtp.gmail.com">
                </div>
                <div class="form-group">
                    <label>SMTP Port</label>
                    <input type="number" name="mail_port" value="587">
                </div>
                <div class="form-group">
                    <label>Mail Kullanıcısı</label>
                    <input type="email" name="mail_user" placeholder="ornek@gmail.com">
                </div>
                <div class="form-group">
                    <label>Mail Şifresi</label>
                    <input type="password" name="mail_pass">
                </div>
                <div class="form-group">
                    <label>Gönderen Adresi</label>
                    <input type="email" name="mail_from" value="noreply@hayyam.app">
                </div>

                <button type="submit" class="btn">Kurulumu Tamamla</button>
            </form>
        <?php endif; ?>
    </div>
</body>
</html>
