<?php
/**
 * Hayyam - WebSocket Server
 * Gerçek zamanlı mesajlaşma, typing indicator, presence
 * Çalıştır: php websocket/Server.php
 */

require_once __DIR__ . '/../vendor/autoload.php';

use Ratchet\MessageComponentInterface;
use Ratchet\ConnectionInterface;
use Ratchet\Server\IoServer;
use Ratchet\Http\HttpServer;
use Ratchet\WebSocket\WsServer;
use Hayyam\Config\Database;
use Hayyam\Config\Security;

class HayyamWebSocket implements MessageComponentInterface {
    protected $clients;
    protected $users;
    protected $db;

    public function __construct() {
        $this->clients = new \SplObjectStorage;
        $this->users = [];
        $this->db = Database::getInstance();
        echo "Hayyam WebSocket Server started\n";
    }

    public function onOpen(ConnectionInterface $conn) {
        $this->clients->attach($conn);
        echo "New connection: {$conn->resourceId}\n";
    }

    public function onMessage(ConnectionInterface $from, $msg) {
        $data = json_decode($msg, true);

        if (!$data || !isset($data['type'])) {
            return;
        }

        switch ($data['type']) {
            case 'auth':
                $this->authenticate($from, $data);
                break;

            case 'message':
                $this->handleMessage($from, $data);
                break;

            case 'typing':
                $this->handleTyping($from, $data);
                break;

            case 'presence':
                $this->handlePresence($from, $data);
                break;

            case 'read_receipt':
                $this->handleReadReceipt($from, $data);
                break;

            case 'call_signal':
                $this->handleCallSignal($from, $data);
                break;
        }
    }

    private function authenticate(ConnectionInterface $conn, array $data): void {
        $token = $data['token'] ?? '';
        $payload = Security::verifyJWT($token);

        if ($payload) {
            $this->users[$conn->resourceId] = [
                'user_id' => $payload['sub'],
                'username' => $payload['username'],
                'conn' => $conn
            ];

            // Online durumunu güncelle
            $this->db->prepare("UPDATE users SET status = 'online', last_seen = NOW() WHERE id = ?")
                     ->execute([$payload['sub']]);

            $conn->send(json_encode([
                'type' => 'auth_success',
                'user_id' => $payload['sub']
            ]));

            // Arkadaşlarına online olduğunu bildir
            $this->broadcastToFriends($payload['sub'], [
                'type' => 'user_online',
                'user_id' => $payload['sub'],
                'username' => $payload['username']
            ]);

        } else {
            $conn->send(json_encode(['type' => 'auth_failed']));
        }
    }

    private function handleMessage(ConnectionInterface $from, array $data): void {
        if (!isset($this->users[$from->resourceId])) {
            return;
        }

        $user = $this->users[$from->resourceId];
        $conversationId = $data['conversation_id'];
        $content = $data['content'];

        // Alıcıları bul
        $stmt = $this->db->prepare("
            SELECT user_id FROM conversation_members 
            WHERE conversation_id = ? AND user_id != ?
        ");
        $stmt->execute([$conversationId, $user['user_id']]);
        $recipients = $stmt->fetchAll(\PDO::FETCH_COLUMN);

        $messageData = [
            'type' => 'new_message',
            'conversation_id' => $conversationId,
            'sender_id' => $user['user_id'],
            'sender_username' => $user['username'],
            'content' => $content,
            'timestamp' => time()
        ];

        // Alıcılara gönder
        foreach ($this->users as $resourceId => $u) {
            if (in_array($u['user_id'], $recipients)) {
                $u['conn']->send(json_encode($messageData));
            }
        }
    }

    private function handleTyping(ConnectionInterface $from, array $data): void {
        if (!isset($this->users[$from->resourceId])) return;

        $user = $this->users[$from->resourceId];
        $conversationId = $data['conversation_id'];
        $isTyping = $data['typing'] ?? false;

        $stmt = $this->db->prepare("
            SELECT user_id FROM conversation_members 
            WHERE conversation_id = ? AND user_id != ?
        ");
        $stmt->execute([$conversationId, $user['user_id']]);
        $recipients = $stmt->fetchAll(\PDO::FETCH_COLUMN);

        $typingData = [
            'type' => 'typing',
            'conversation_id' => $conversationId,
            'user_id' => $user['user_id'],
            'username' => $user['username'],
            'typing' => $isTyping
        ];

        foreach ($this->users as $resourceId => $u) {
            if (in_array($u['user_id'], $recipients)) {
                $u['conn']->send(json_encode($typingData));
            }
        }
    }

    private function handlePresence(ConnectionInterface $from, array $data): void {
        if (!isset($this->users[$from->resourceId])) return;

        $user = $this->users[$from->resourceId];
        $status = $data['status'] ?? 'online'; // online, away, offline

        $this->db->prepare("UPDATE users SET status = ? WHERE id = ?")
                 ->execute([$status, $user['user_id']]);

        $this->broadcastToFriends($user['user_id'], [
            'type' => 'presence_update',
            'user_id' => $user['user_id'],
            'status' => $status
        ]);
    }

    private function handleReadReceipt(ConnectionInterface $from, array $data): void {
        if (!isset($this->users[$from->resourceId])) return;

        $user = $this->users[$from->resourceId];
        $conversationId = $data['conversation_id'];
        $messageId = $data['message_id'];

        // Okundu bilgisini güncelle
        $this->db->prepare("
            UPDATE conversation_members 
            SET last_read_message_id = ? 
            WHERE conversation_id = ? AND user_id = ?
        ")->execute([$messageId, $conversationId, $user['user_id']]);

        // Diğer kullanıcılara bildir
        $stmt = $this->db->prepare("
            SELECT user_id FROM conversation_members 
            WHERE conversation_id = ? AND user_id != ?
        ");
        $stmt->execute([$conversationId, $user['user_id']]);
        $recipients = $stmt->fetchAll(\PDO::FETCH_COLUMN);

        $readData = [
            'type' => 'read_receipt',
            'conversation_id' => $conversationId,
            'message_id' => $messageId,
            'user_id' => $user['user_id']
        ];

        foreach ($this->users as $resourceId => $u) {
            if (in_array($u['user_id'], $recipients)) {
                $u['conn']->send(json_encode($readData));
            }
        }
    }

    private function handleCallSignal(ConnectionInterface $from, array $data): void {
        if (!isset($this->users[$from->resourceId])) return;

        $user = $this->users[$from->resourceId];
        $targetUserId = $data['target_user_id'];
        $signal = $data['signal'];
        $callType = $data['call_type'] ?? 'voice'; // voice, video

        // Hedef kullanıcıyı bul
        foreach ($this->users as $resourceId => $u) {
            if ($u['user_id'] == $targetUserId) {
                $u['conn']->send(json_encode([
                    'type' => 'call_signal',
                    'from_user_id' => $user['user_id'],
                    'from_username' => $user['username'],
                    'call_type' => $callType,
                    'signal' => $signal
                ]));
                break;
            }
        }
    }

    private function broadcastToFriends(int $userId, array $data): void {
        $stmt = $this->db->prepare("
            SELECT CASE 
                WHEN sender_id = ? THEN receiver_id 
                ELSE sender_id 
            END as friend_id
            FROM friend_requests 
            WHERE (sender_id = ? OR receiver_id = ?) AND status = 'accepted'
        ");
        $stmt->execute([$userId, $userId, $userId]);
        $friends = $stmt->fetchAll(\PDO::FETCH_COLUMN);

        foreach ($this->users as $resourceId => $u) {
            if (in_array($u['user_id'], $friends)) {
                $u['conn']->send(json_encode($data));
            }
        }
    }

    public function onClose(ConnectionInterface $conn) {
        $this->clients->detach($conn);

        if (isset($this->users[$conn->resourceId])) {
            $user = $this->users[$conn->resourceId];

            // Offline durumunu güncelle
            $this->db->prepare("UPDATE users SET status = 'offline', last_seen = NOW() WHERE id = ?")
                     ->execute([$user['user_id']]);

            $this->broadcastToFriends($user['user_id'], [
                'type' => 'user_offline',
                'user_id' => $user['user_id'],
                'username' => $user['username']
            ]);

            unset($this->users[$conn->resourceId]);
        }

        echo "Connection {$conn->resourceId} closed\n";
    }

    public function onError(ConnectionInterface $conn, \Exception $e) {
        echo "Error: {$e->getMessage()}\n";
        $conn->close();
    }
}

// Server'ı başlat
$server = IoServer::factory(
    new HttpServer(
        new WsServer(
            new HayyamWebSocket()
        )
    ),
    8080
);

echo "Hayyam WebSocket Server running on port 8080\n";
$server->run();
