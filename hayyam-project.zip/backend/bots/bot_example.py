#!/usr/bin/env python3
"""
Hayyam Bot Example - Python
Bu örnek, Hayyam API'sini kullanarak basit bir bot oluşturmayı gösterir.

Gereksinimler:
    pip install flask requests

Çalıştırma:
    python bot_example.py

BotFather'dan aldığınız API token'ı .env dosyasına veya doğrudan kodda belirtin.
"""

from flask import Flask, request, jsonify
import requests
import os
from datetime import datetime

app = Flask(__name__)

# Konfigürasyon
HAYYAM_API_URL = os.getenv('HAYYAM_API_URL', 'https://api.hayyam.app')
BOT_TOKEN = os.getenv('HAYYAM_BOT_TOKEN', 'your_bot_token_here')

class HayyamBot:
    def __init__(self, token):
        self.token = token
        self.api_url = HAYYAM_API_URL
        self.commands = {
            'start': self.cmd_start,
            'help': self.cmd_help,
            'time': self.cmd_time,
            'echo': self.cmd_echo,
            'weather': self.cmd_weather,
            'joke': self.cmd_joke
        }

    def send_message(self, chat_id, text, reply_to=None):
        """Hayyam API üzerinden mesaj gönder"""
        try:
            response = requests.post(
                f"{self.api_url}/api/bots/interact",
                headers={
                    'Authorization': f'Bearer {self.token}',
                    'Content-Type': 'application/json'
                },
                json={
                    'conversation_id': chat_id,
                    'message': text,
                    'reply_to': reply_to
                }
            )
            return response.json()
        except Exception as e:
            print(f"Send message error: {e}")
            return None

    def cmd_start(self, message, args):
        """Bot başlatma komutu"""
        user = message.get('from', {})
        name = user.get('display_name', 'Kullanıcı')

        return f"""🤖 Merhaba {name}! Ben Hayyam Bot.

Size nasıl yardımcı olabilirim?

Komutları görmek için: /help"""

    def cmd_help(self, message, args):
        """Yardım komutu"""
        return """📋 Mevcut Komutlar:

/start - Botu başlat
/help - Bu mesajı göster
/time - Şu anki saati göster
/echo <mesaj> - Mesajı tekrar et
/weather <şehir> - Hava durumu bilgisi
/joke - Rastgele bir şaka

Botunuzu özelleştirmek için:
https://hayyam.app/bots/builder"""

    def cmd_time(self, message, args):
        """Saat komutu"""
        now = datetime.now()
        return f"🕐 Şu anki saat: {now.strftime('%H:%M:%S')}
📅 Tarih: {now.strftime('%d.%m.%Y')}"

    def cmd_echo(self, message, args):
        """Echo komutu"""
        if not args:
            return "❌ Kullanım: /echo <mesaj>"
        return f"📢 {args}"

    def cmd_weather(self, message, args):
        """Hava durumu komutu (örnek)"""
        city = args or "İstanbul"
        # Gerçek hava durumu API'si entegrasyonu burada yapılabilir
        return f"""🌤️ {city} Hava Durumu:

Sıcaklık: 22°C
Durum: Parçalı Bulutlu
Nem: %65
Rüzgar: 12 km/h

(Gerçek hava durumu için OpenWeatherMap API entegrasyonu yapılabilir)"""

    def cmd_joke(self, message, args):
        """Şaka komutu"""
        import random
        jokes = [
            "Programcılar neden kararı veremez? Çünkü 0'dan 1'e kararsızlar!",
            "Bir SQL sorgusu bir bara girer, iki masaya oturur ve sorar: 'Birleştirebilir miyiz?'",
            "Python olmayan bir yılan ne yapar? Hiçbir şey, çünkü Python olmadan çalışamaz!",
            "Neden programcılar doğayı sever? Çünkü çok fazla cache var!"
        ]
        return f"😄 {random.choice(jokes)}"

    def handle_update(self, update):
        """Gelen güncellemeyi işle"""
        message = update.get('message', {})
        text = message.get('text', '')
        chat_id = message.get('chat', {}).get('id')

        if not text or not text.startswith('/'):
            return None

        # Komutu ve argümanları ayır
        parts = text[1:].split(' ', 1)
        command = parts[0].lower()
        args = parts[1] if len(parts) > 1 else ''

        # Komutu çalıştır
        handler = self.commands.get(command)
        if handler:
            response = handler(message, args)
            if response and chat_id:
                self.send_message(chat_id, response)
            return response

        return None

# Bot instance
bot = HayyamBot(BOT_TOKEN)

@app.route('/webhook', methods=['POST'])
def webhook():
    """Hayyam'dan gelen webhook isteklerini işle"""
    try:
        update = request.get_json()

        # Token doğrulama
        if update.get('bot_token') != BOT_TOKEN:
            return jsonify({'error': 'Invalid token'}), 401

        # Güncellemeyi işle
        result = bot.handle_update(update)

        return jsonify({
            'success': True,
            'processed': result is not None
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/health', methods=['GET'])
def health():
    """Sağlık kontrolü"""
    return jsonify({
        'status': 'ok',
        'bot': 'Hayyam Bot',
        'timestamp': datetime.now().isoformat()
    })

if __name__ == '__main__':
    print("🤖 Hayyam Bot başlatılıyor...")
    print(f"API URL: {HAYYAM_API_URL}")
    print("Webhook endpoint: /webhook")
    print("Health check: /health")

    # Production'da debug=False kullanın
    app.run(host='0.0.0.0', port=5000, debug=True)
