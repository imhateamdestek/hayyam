<?php
/**
 * Hayyam - Security & Encryption
 * JWT, AES-256-GCM, RSA şifreleme yönetimi
 */

namespace Hayyam\Config;

class Security {
    private static string $jwtSecret;
    private static string $aesKey;

    public static function init(): void {
        self::$jwtSecret = $_ENV['JWT_SECRET'] ?? bin2hex(random_bytes(32));
        self::$aesKey = $_ENV['AES_KEY'] ?? bin2hex(random_bytes(32));
    }

    /**
     * JWT Token oluştur
     */
    public static function generateJWT(array $payload, int $expiry = 86400): string {
        $header = json_encode(['typ' => 'JWT', 'alg' => 'HS256']);
        $time = time();
        $payload['iat'] = $time;
        $payload['exp'] = $time + $expiry;

        $base64Header = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($header));
        $base64Payload = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode(json_encode($payload)));

        $signature = hash_hmac('sha256', "$base64Header.$base64Payload", self::$jwtSecret, true);
        $base64Signature = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($signature));

        return "$base64Header.$base64Payload.$base64Signature";
    }

    /**
     * JWT Token doğrula
     */
    public static function verifyJWT(string $token): ?array {
        $parts = explode('.', $token);
        if (count($parts) !== 3) return null;

        $signature = hash_hmac('sha256', "$parts[0].$parts[1]", self::$jwtSecret, true);
        $base64Signature = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($signature));

        if (!hash_equals($base64Signature, $parts[2])) return null;

        $payload = json_decode(base64_decode(str_replace(['-', '_'], ['+', '/'], $parts[1])), true);
        if (!$payload || ($payload['exp'] ?? 0) < time()) return null;

        return $payload;
    }

    /**
     * AES-256-GCM şifreleme
     */
    public static function encrypt(string $data, string $key = null): array {
        $key = $key ? hex2bin($key) : hex2bin(self::$aesKey);
        $iv = random_bytes(12);
        $tag = '';

        $encrypted = openssl_encrypt(
            $data, 
            'AES-256-GCM', 
            $key, 
            OPENSSL_RAW_DATA, 
            $iv, 
            $tag, 
            '', 
            16
        );

        return [
            'data' => base64_encode($encrypted),
            'iv' => base64_encode($iv),
            'tag' => base64_encode($tag)
        ];
    }

    /**
     * AES-256-GCM şifre çözme
     */
    public static function decrypt(string $encryptedData, string $iv, string $tag, string $key = null): ?string {
        $key = $key ? hex2bin($key) : hex2bin(self::$aesKey);

        $decrypted = openssl_decrypt(
            base64_decode($encryptedData),
            'AES-256-GCM',
            $key,
            OPENSSL_RAW_DATA,
            base64_decode($iv),
            base64_decode($tag)
        );

        return $decrypted !== false ? $decrypted : null;
    }

    /**
     * RSA Key Pair oluştur
     */
    public static function generateKeyPair(): array {
        $config = [
            "private_key_bits" => 2048,
            "private_key_type" => OPENSSL_KEYTYPE_RSA,
        ];

        $res = openssl_pkey_new($config);
        openssl_pkey_export($res, $privateKey);
        $publicKey = openssl_pkey_get_details($res)['key'];

        return [
            'public' => $publicKey,
            'private' => $privateKey
        ];
    }

    /**
     * Şifre hash'leme (Argon2id)
     */
    public static function hashPassword(string $password): string {
        return password_hash($password, PASSWORD_ARGON2ID, [
            'memory_cost' => 65536,
            'time_cost' => 4,
            'threads' => 3
        ]);
    }

    /**
     * Şifre doğrulama
     */
    public static function verifyPassword(string $password, string $hash): bool {
        return password_verify($password, $hash);
    }

    /**
     * Güvenli rastgele string
     */
    public static function randomString(int $length = 32): string {
        return bin2hex(random_bytes($length / 2));
    }

    /**
     * Rate limiting check
     */
    public static function checkRateLimit(string $identifier, int $maxAttempts = 60, int $window = 60): bool {
        $key = "rate_limit:$identifier";
        $now = time();

        // Redis veya dosya tabanlı implementasyon
        // Basit dosya tabanlı:
        $file = sys_get_temp_dir() . "/$key.json";
        $attempts = [];

        if (file_exists($file)) {
            $attempts = json_decode(file_get_contents($file), true) ?: [];
            $attempts = array_filter($attempts, fn($t) => $t > $now - $window);
        }

        if (count($attempts) >= $maxAttempts) {
            return false;
        }

        $attempts[] = $now;
        file_put_contents($file, json_encode($attempts));

        return true;
    }
}

Security::init();
