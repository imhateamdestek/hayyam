<?php
/**
 * Hayyam - User Controller
 * Kullanıcı profili, arama, kontakt yönetimi
 */

namespace Hayyam\Controllers;

use Hayyam\Config\Database;
use Hayyam\Config\Security;
use Hayyam\Config\Response;
use PDO;

class UserController {
    private PDO $db;

    public function __construct() {
        $this->db = Database::getInstance();
    }

    /**
     * GET /api/users/search
     * Kullanıcı ara
     */
    public function getSearch(array $data, ?array $user, array $params): void {
        $query = $_GET['q'] ?? '';
        $page = (int)($_GET['page'] ?? 1);
        $perPage = min((int)($_GET['per_page'] ?? 20), 50);
        $offset = ($page - 1) * $perPage;

        if (strlen($query) < 2) {
            Response::error('Search query must be at least 2 characters', 400);
        }

        $searchTerm = "%$query%";

        $stmt = $this->db->prepare("
            SELECT id, uuid, username, display_name, avatar_url, bio, status, last_seen
            FROM users
            WHERE (username LIKE ? OR display_name LIKE ? OR email LIKE ?)
            AND is_active = TRUE
            AND id != ?
            ORDER BY 
                CASE 
                    WHEN username = ? THEN 1
                    WHEN username LIKE ? THEN 2
                    ELSE 3
                END,
                display_name ASC
            LIMIT ? OFFSET ?
        ");

        $stmt->execute([
            $searchTerm, $searchTerm, $searchTerm,
            $user['sub'],
            $query, "$query%",
            $perPage, $offset
        ]);

        $users = $stmt->fetchAll();

        Response::success([
            'users' => $users,
            'query' => $query,
            'page' => $page
        ]);
    }

    /**
     * GET /api/users/profile
     * Kullanıcı profili getir
     */
    public function getProfile(array $data, ?array $user, array $params): void {
        $username = $_GET['username'] ?? null;

        if (!$username) {
            // Kendi profilini getir
            $stmt = $this->db->prepare("
                SELECT id, uuid, username, email, display_name, bio, avatar_url, 
                       phone, public_key, email_verified, last_seen, status, created_at
                FROM users WHERE id = ?
            ");
            $stmt->execute([$user['sub']]);
        } else {
            $stmt = $this->db->prepare("
                SELECT id, uuid, username, display_name, bio, avatar_url, 
                       public_key, last_seen, status, created_at
                FROM users WHERE username = ? AND is_active = TRUE
            ");
            $stmt->execute([$username]);
        }

        $profile = $stmt->fetch();

        if (!$profile) {
            Response::error('User not found', 404);
        }

        Response::success($profile);
    }

    /**
     * PUT /api/users/profile
     * Profili güncelle
     */
    public function putProfile(array $data, ?array $user, array $params): void {
        $allowedFields = ['display_name', 'bio', 'avatar_url', 'phone'];
        $updates = [];
        $values = [];

        foreach ($allowedFields as $field) {
            if (isset($data[$field])) {
                $updates[] = "$field = ?";
                $values[] = $data[$field];
            }
        }

        if (empty($updates)) {
            Response::error('No fields to update', 400);
        }

        $values[] = $user['sub'];

        try {
            $sql = "UPDATE users SET " . implode(', ', $updates) . ", updated_at = NOW() WHERE id = ?";
            $this->db->prepare($sql)->execute($values);

            Response::success(null, 'Profile updated');
        } catch (\Exception $e) {
            Response::error('Failed to update profile', 500);
        }
    }

    /**
     * POST /api/users/avatar
     * Avatar yükle
     */
    public function postAvatar(array $data, ?array $user, array $params): void {
        if (empty($data['avatar_base64'])) {
            Response::error('Avatar image is required', 400);
        }

        // Base64 decode ve kaydet
        $avatarData = base64_decode(preg_replace('#^data:image/\w+;base64,#i', '', $data['avatar_base64']));

        if (!$avatarData) {
            Response::error('Invalid image data', 400);
        }

        $filename = Security::randomString(16) . '.png';
        $uploadPath = __DIR__ . '/../../uploads/avatars/';

        if (!is_dir($uploadPath)) {
            mkdir($uploadPath, 0755, true);
        }

        $filepath = $uploadPath . $filename;

        if (file_put_contents($filepath, $avatarData)) {
            $avatarUrl = '/uploads/avatars/' . $filename;

            $this->db->prepare("UPDATE users SET avatar_url = ? WHERE id = ?")
                     ->execute([$avatarUrl, $user['sub']]);

            Response::success(['avatar_url' => $avatarUrl], 'Avatar updated');
        } else {
            Response::error('Failed to save avatar', 500);
        }
    }
}
