<?php
/**
 * Hayyam API Router
 * Tüm API isteklerinin giriş noktası
 */

require_once __DIR__ . '/../vendor/autoload.php';

use Hayyam\Config\Response;
use Hayyam\Config\Security;

// CORS Headers
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Access-Control-Max-Age: 86400");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Content-Type kontrolü
if ($_SERVER['REQUEST_METHOD'] !== 'GET' && strpos($_SERVER['CONTENT_TYPE'] ?? '', 'application/json') === false) {
    Response::error('Content-Type must be application/json', 415);
}

// Router
$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$uri = str_replace('/api/', '', $uri);
$parts = explode('/', trim($uri, '/'));
$endpoint = $parts[0] ?? '';
$action = $parts[1] ?? '';

// Auth gerektirmeyen endpointler
$publicEndpoints = ['auth', 'install', 'health'];
$authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
$token = str_replace('Bearer ', '', $authHeader);
$user = null;

if (!in_array($endpoint, $publicEndpoints)) {
    if (empty($token)) {
        Response::error('Authorization token required', 401);
    }

    $payload = Security::verifyJWT($token);
    if (!$payload) {
        Response::error('Invalid or expired token', 401);
    }

    $user = $payload;
}

// Route mapping
$routes = [
    'auth' => 'AuthController',
    'users' => 'UserController',
    'conversations' => 'ConversationController',
    'messages' => 'MessageController',
    'walls' => 'WallController',
    'bots' => 'BotController',
    'mesh' => 'MeshController',
    'media' => 'MediaController',
    'notifications' => 'NotificationController',
    'disaster' => 'DisasterController',
    'friends' => 'FriendController',
    'settings' => 'SettingsController'
];

if (!isset($routes[$endpoint])) {
    Response::error('Endpoint not found', 404);
}

$controllerName = "Hayyam\\Controllers\\" . $routes[$endpoint];
$method = strtolower($_SERVER['REQUEST_METHOD']) . ucfirst($action);

if (!class_exists($controllerName)) {
    Response::error('Controller not found', 500);
}

$controller = new $controllerName();

if (!method_exists($controller, $method)) {
    // Default method mapping
    $method = 'handle' . ucfirst(strtolower($_SERVER['REQUEST_METHOD']));
    if (!method_exists($controller, $method)) {
        Response::error('Method not allowed', 405);
    }
}

try {
    $input = json_decode(file_get_contents('php://input'), true) ?: [];
    $controller->$method($input, $user, $parts);
} catch (Exception $e) {
    error_log("API Error: " . $e->getMessage());
    Response::error('Internal server error', 500);
}
