<?php
/**
 * Hayyam - Wall (Sosyal Duvar) Controller
 * Kullanıcı duvarı, paylaşımlar, etiketleme
 */

namespace Hayyam\Controllers;

use Hayyam\Config\Database;
use Hayyam\Config\Security;
use Hayyam\Config\Response;
use PDO;

class WallController {
    private PDO $db;

    public function __construct() {
        $this->db = Database::getInstance();
    }

    /**
     * POST /api/walls/create
     * Duvara paylaşım ekle
     */
    public function postCreate(array $data, ?array $user, array $params): void {
        $required = ['type', 'content'];
        foreach ($required as $field) {
            if (empty($data[$field])) {
                Response::error("Field '$field' is required", 400);
            }
        }

        $type = $data['type'];
        $content = $data['content'];
        $mediaUrls = $data['media_urls'] ?? null;
        $backgroundColor = $data['background_color'] ?? null;
        $textColor = $data['text_color'] ?? null;
        $fontStyle = $data['font_style'] ?? null;
        $isPinned = $data['is_pinned'] ?? false;
        $tags = $data['tags'] ?? []; // ['username' => 'position_x,y']

        $uuid = Security::randomString(36);

        try {
            $this->db->beginTransaction();

            $stmt = $this->db->prepare("
                INSERT INTO walls 
                (user_id, uuid, type, content, media_urls, background_color, text_color, 
                 font_style, is_pinned, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
            ");

            $stmt->execute([
                $user['sub'],
                $uuid,
                $type,
                $content,
                $mediaUrls ? json_encode($mediaUrls) : null,
                $backgroundColor,
                $textColor,
                $fontStyle,
                $isPinned
            ]);

            $wallId = $this->db->lastInsertId();

            // Etiketlenen kullanıcıları işle
            foreach ($tags as $tagUsername => $position) {
                $stmt = $this->db->prepare("SELECT id FROM users WHERE username = ?");
                $stmt->execute([str_replace('@', '', $tagUsername)]);
                $taggedUser = $stmt->fetch();

                if ($taggedUser) {
                    $pos = explode(',', $position);
                    $this->db->prepare("
                        INSERT INTO wall_tags (wall_id, tagged_user_id, tag_position_x, tag_position_y)
                        VALUES (?, ?, ?, ?)
                    ")->execute([
                        $wallId,
                        $taggedUser['id'],
                        $pos[0] ?? null,
                        $pos[1] ?? null
                    ]);

                    // Bildirim gönder
                    $this->db->prepare("
                        INSERT INTO notifications (user_id, type, title, body, data, created_at)
                        VALUES (?, 'mention', 'You were tagged', ?, ?, NOW())
                    ")->execute([
                        $taggedUser['id'],
                        "@{$user['username']} tagged you in a post",
                        json_encode(['wall_id' => $wallId, 'tagged_by' => $user['sub']])
                    ]);
                }
            }

            $this->db->commit();

            Response::success([
                'wall_id' => $wallId,
                'uuid' => $uuid,
                'type' => $type,
                'created_at' => time()
            ], 'Wall post created successfully', 201);

        } catch (\Exception $e) {
            $this->db->rollBack();
            Response::error('Failed to create wall post: ' . $e->getMessage(), 500);
        }
    }

    /**
     * GET /api/walls/user
     * Kullanıcı duvarını getir
     */
    public function getUser(array $data, ?array $user, array $params): void {
        $username = $_GET['username'] ?? null;
        $page = (int)($_GET['page'] ?? 1);
        $perPage = min((int)($_GET['per_page'] ?? 20), 50);

        if (!$username) {
            Response::error('Username is required', 400);
        }

        $username = strtolower(trim($username));

        // Kullanıcıyı bul
        $stmt = $this->db->prepare("
            SELECT id, uuid, username, display_name, bio, avatar_url, created_at
            FROM users WHERE username = ? AND is_active = TRUE
        ");
        $stmt->execute([$username]);
        $profile = $stmt->fetch();

        if (!$profile) {
            Response::error('User not found', 404);
        }

        // Gizlilik kontrolü
        $stmt = $this->db->prepare("SELECT privacy_wall FROM user_settings WHERE user_id = ?");
        $stmt->execute([$profile['id']]);
        $privacy = $stmt->fetch();

        $privacySetting = $privacy['privacy_wall'] ?? 'public';

        if ($privacySetting === 'private' && $profile['id'] != ($user['sub'] ?? 0)) {
            Response::error('This wall is private', 403);
        }

        if ($privacySetting === 'friends') {
            // Arkadaşlık kontrolü
            $stmt = $this->db->prepare("
                SELECT 1 FROM friend_requests 
                WHERE ((sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?))
                AND status = 'accepted'
            ");
            $stmt->execute([$user['sub'], $profile['id'], $profile['id'], $user['sub']]);
            if (!$stmt->fetch() && $profile['id'] != $user['sub']) {
                Response::error('This wall is only visible to friends', 403);
            }
        }

        $offset = ($page - 1) * $perPage;

        // Toplam paylaşım sayısı
        $stmt = $this->db->prepare("SELECT COUNT(*) FROM walls WHERE user_id = ? AND is_pinned = FALSE");
        $stmt->execute([$profile['id']]);
        $total = (int)$stmt->fetchColumn();

        // Sabitlenmiş paylaşımlar
        $stmt = $this->db->prepare("
            SELECT w.*, 
                   (SELECT COUNT(*) FROM wall_likes WHERE wall_id = w.id) as likes,
                   (SELECT COUNT(*) FROM wall_comments WHERE wall_id = w.id) as comments
            FROM walls w
            WHERE w.user_id = ? AND w.is_pinned = TRUE
            ORDER BY w.created_at DESC
        ");
        $stmt->execute([$profile['id']]);
        $pinnedPosts = $stmt->fetchAll();

        // Normal paylaşımlar
        $stmt = $this->db->prepare("
            SELECT w.*, 
                   (SELECT COUNT(*) FROM wall_likes WHERE wall_id = w.id) as likes,
                   (SELECT COUNT(*) FROM wall_comments WHERE wall_id = w.id) as comments,
                   EXISTS(SELECT 1 FROM wall_likes WHERE wall_id = w.id AND user_id = ?) as is_liked
            FROM walls w
            WHERE w.user_id = ? AND w.is_pinned = FALSE
            ORDER BY w.created_at DESC
            LIMIT ? OFFSET ?
        ");
        $stmt->execute([$user['sub'] ?? 0, $profile['id'], $perPage, $offset]);
        $posts = $stmt->fetchAll();

        // Etiketlenen kullanıcıları getir
        foreach ($posts as &$post) {
            $stmt = $this->db->prepare("
                SELECT u.username, u.display_name, u.avatar_url, wt.tag_position_x, wt.tag_position_y
                FROM wall_tags wt
                JOIN users u ON wt.tagged_user_id = u.id
                WHERE wt.wall_id = ?
            ");
            $stmt->execute([$post['id']]);
            $post['tags'] = $stmt->fetchAll();
            $post['media_urls'] = json_decode($post['media_urls'] ?? '[]', true);
        }

        Response::success([
            'profile' => $profile,
            'pinned_posts' => $pinnedPosts,
            'posts' => $posts,
            'pagination' => [
                'current_page' => $page,
                'per_page' => $perPage,
                'total_items' => $total,
                'total_pages' => (int)ceil($total / $perPage)
            ]
        ]);
    }

    /**
     * POST /api/walls/like
     * Beğen
     */
    public function postLike(array $data, ?array $user, array $params): void {
        if (empty($data['wall_id'])) {
            Response::error('Wall ID is required', 400);
        }

        $reactionType = $data['reaction'] ?? 'like';

        try {
            $stmt = $this->db->prepare("
                INSERT INTO wall_likes (wall_id, user_id, reaction_type)
                VALUES (?, ?, ?)
                ON DUPLICATE KEY UPDATE reaction_type = ?
            ");
            $stmt->execute([$data['wall_id'], $user['sub'], $reactionType, $reactionType]);

            // Beğeni sayısını güncelle
            $this->db->prepare("
                UPDATE walls SET like_count = (SELECT COUNT(*) FROM wall_likes WHERE wall_id = ?)
                WHERE id = ?
            ")->execute([$data['wall_id'], $data['wall_id']]);

            Response::success(null, 'Liked successfully');
        } catch (\Exception $e) {
            Response::error('Failed to like: ' . $e->getMessage(), 500);
        }
    }

    /**
     * POST /api/walls/comment
     * Yorum yap
     */
    public function postComment(array $data, ?array $user, array $params): void {
        if (empty($data['wall_id']) || empty($data['content'])) {
            Response::error('Wall ID and content are required', 400);
        }

        $parentId = $data['parent_id'] ?? null;

        try {
            $stmt = $this->db->prepare("
                INSERT INTO wall_comments (wall_id, user_id, parent_id, content, created_at)
                VALUES (?, ?, ?, ?, NOW())
            ");
            $stmt->execute([$data['wall_id'], $user['sub'], $parentId, $data['content']]);

            // Yorum sayısını güncelle
            $this->db->prepare("
                UPDATE walls SET comment_count = (SELECT COUNT(*) FROM wall_comments WHERE wall_id = ?)
                WHERE id = ?
            ")->execute([$data['wall_id'], $data['wall_id']]);

            Response::success(['comment_id' => $this->db->lastInsertId()], 'Comment added');
        } catch (\Exception $e) {
            Response::error('Failed to add comment: ' . $e->getMessage(), 500);
        }
    }

    /**
     * GET /api/walls/feed
     * Ana sayfa akışı
     */
    public function getFeed(array $data, ?array $user, array $params): void {
        $page = (int)($_GET['page'] ?? 1);
        $perPage = min((int)($_GET['per_page'] ?? 20), 50);
        $offset = ($page - 1) * $perPage;

        // Arkadaşların ve kendi paylaşımları
        $stmt = $this->db->prepare("
            SELECT w.*, 
                   u.username, u.display_name, u.avatar_url,
                   (SELECT COUNT(*) FROM wall_likes WHERE wall_id = w.id) as likes,
                   (SELECT COUNT(*) FROM wall_comments WHERE wall_id = w.id) as comments,
                   EXISTS(SELECT 1 FROM wall_likes WHERE wall_id = w.id AND user_id = ?) as is_liked
            FROM walls w
            JOIN users u ON w.user_id = u.id
            WHERE w.user_id = ? OR w.user_id IN (
                SELECT CASE 
                    WHEN sender_id = ? THEN receiver_id 
                    ELSE sender_id 
                END 
                FROM friend_requests 
                WHERE (sender_id = ? OR receiver_id = ?) AND status = 'accepted'
            )
            ORDER BY w.created_at DESC
            LIMIT ? OFFSET ?
        ");

        $stmt->execute([
            $user['sub'], $user['sub'], $user['sub'], 
            $user['sub'], $user['sub'], $perPage, $offset
        ]);

        $posts = $stmt->fetchAll();

        Response::success([
            'posts' => $posts,
            'page' => $page,
            'has_more' => count($posts) === $perPage
        ]);
    }
}
