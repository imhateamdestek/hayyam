<?php
/**
 * Hayyam - Friend Controller
 * Arkadaşlık istekleri ve kontakt yönetimi
 */

namespace Hayyam\Controllers;

use Hayyam\Config\Database;
use Hayyam\Config\Response;
use PDO;

class FriendController {
    private PDO $db;

    public function __construct() {
        $this->db = Database::getInstance();
    }

    /**
     * POST /api/friends/request
     * Arkadaşlık isteği gönder
     */
    public function postRequest(array $data, ?array $user, array $params): void {
        $username = $data['username'] ?? null;

        if (!$username) {
            Response::error('Username is required', 400);
        }

        // Kullanıcıyı bul
        $stmt = $this->db->prepare("SELECT id FROM users WHERE username = ? AND is_active = TRUE");
        $stmt->execute([$username]);
        $targetUser = $stmt->fetch();

        if (!$targetUser) {
            Response::error('User not found', 404);
        }

        if ($targetUser['id'] == $user['sub']) {
            Response::error('Cannot send request to yourself', 400);
        }

        // Mevcut isteği kontrol et
        $stmt = $this->db->prepare("
            SELECT status FROM friend_requests 
            WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?)
        ");
        $stmt->execute([$user['sub'], $targetUser['id'], $targetUser['id'], $user['sub']]);
        $existing = $stmt->fetch();

        if ($existing) {
            if ($existing['status'] === 'accepted') {
                Response::error('Already friends', 409);
            }
            if ($existing['status'] === 'pending') {
                Response::error('Friend request already pending', 409);
            }
        }

        try {
            $stmt = $this->db->prepare("
                INSERT INTO friend_requests (sender_id, receiver_id, status, message, created_at)
                VALUES (?, ?, 'pending', ?, NOW())
            ");
            $stmt->execute([$user['sub'], $targetUser['id'], $data['message'] ?? null]);

            // Bildirim oluştur
            $this->db->prepare("
                INSERT INTO notifications (user_id, type, title, body, data, created_at)
                VALUES (?, 'friend_request', 'New Friend Request', ?, ?, NOW())
            ")->execute([
                $targetUser['id'],
                "You have a new friend request",
                json_encode(['sender_id' => $user['sub']])
            ]);

            Response::success(null, 'Friend request sent', 201);
        } catch (\Exception $e) {
            Response::error('Failed to send request', 500);
        }
    }

    /**
     * POST /api/friends/accept
     * Arkadaşlık isteğini kabul et
     */
    public function postAccept(array $data, ?array $user, array $params): void {
        $requestId = $data['request_id'] ?? null;

        if (!$requestId) {
            Response::error('Request ID is required', 400);
        }

        $stmt = $this->db->prepare("
            UPDATE friend_requests 
            SET status = 'accepted', updated_at = NOW()
            WHERE id = ? AND receiver_id = ? AND status = 'pending'
        ");
        $stmt->execute([$requestId, $user['sub']]);

        if ($stmt->rowCount() === 0) {
            Response::error('Request not found or already processed', 404);
        }

        Response::success(null, 'Friend request accepted');
    }

    /**
     * POST /api/friends/reject
     * Arkadaşlık isteğini reddet
     */
    public function postReject(array $data, ?array $user, array $params): void {
        $requestId = $data['request_id'] ?? null;

        if (!$requestId) {
            Response::error('Request ID is required', 400);
        }

        $this->db->prepare("
            UPDATE friend_requests 
            SET status = 'rejected', updated_at = NOW()
            WHERE id = ? AND receiver_id = ?
        ")->execute([$requestId, $user['sub']]);

        Response::success(null, 'Friend request rejected');
    }

    /**
     * GET /api/friends/list
     * Arkadaş listesi
     */
    public function getList(array $data, ?array $user, array $params): void {
        $stmt = $this->db->prepare("
            SELECT 
                u.id, u.uuid, u.username, u.display_name, u.avatar_url, u.status, u.last_seen,
                fr.created_at as friendship_date
            FROM friend_requests fr
            JOIN users u ON 
                (fr.sender_id = ? AND fr.receiver_id = u.id) OR
                (fr.receiver_id = ? AND fr.sender_id = u.id)
            WHERE fr.status = 'accepted'
            ORDER BY fr.created_at DESC
        ");
        $stmt->execute([$user['sub'], $user['sub']]);
        $friends = $stmt->fetchAll();

        Response::success(['friends' => $friends]);
    }

    /**
     * GET /api/friends/pending
     * Bekleyen istekler
     */
    public function getPending(array $data, ?array $user, array $params): void {
        $stmt = $this->db->prepare("
            SELECT 
                fr.id as request_id,
                fr.message,
                fr.created_at,
                u.id, u.username, u.display_name, u.avatar_url
            FROM friend_requests fr
            JOIN users u ON fr.sender_id = u.id
            WHERE fr.receiver_id = ? AND fr.status = 'pending'
            ORDER BY fr.created_at DESC
        ");
        $stmt->execute([$user['sub']]);
        $requests = $stmt->fetchAll();

        Response::success(['requests' => $requests]);
    }

    /**
     * DELETE /api/friends/remove
     * Arkadaşı sil
     */
    public function deleteRemove(array $data, ?array $user, array $params): void {
        $friendId = $data['friend_id'] ?? null;

        if (!$friendId) {
            Response::error('Friend ID is required', 400);
        }

        $this->db->prepare("
            DELETE FROM friend_requests 
            WHERE ((sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?))
            AND status = 'accepted'
        ")->execute([$user['sub'], $friendId, $friendId, $user['sub']]);

        Response::success(null, 'Friend removed');
    }
}
