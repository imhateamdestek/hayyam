<?php
/**
 * Hayyam - Settings Controller
 * Kullanıcı ayarları yönetimi
 */

namespace Hayyam\Controllers;

use Hayyam\Config\Database;
use Hayyam\Config\Response;
use PDO;

class SettingsController {
    private PDO $db;

    public function __construct() {
        $this->db = Database::getInstance();
    }

    /**
     * GET /api/settings/get
     * Kullanıcı ayarlarını getir
     */
    public function getGet(array $data, ?array $user, array $params): void {
        $stmt = $this->db->prepare("SELECT * FROM user_settings WHERE user_id = ?");
        $stmt->execute([$user['sub']]);
        $settings = $stmt->fetch();

        if (!$settings) {
            // Varsayılan ayarları oluştur
            $this->db->prepare("INSERT INTO user_settings (user_id) VALUES (?)")
                     ->execute([$user['sub']]);

            $stmt = $this->db->prepare("SELECT * FROM user_settings WHERE user_id = ?");
            $stmt->execute([$user['sub']]);
            $settings = $stmt->fetch();
        }

        Response::success($settings);
    }

    /**
     * PUT /api/settings/update
     * Ayarları güncelle
     */
    public function putUpdate(array $data, ?array $user, array $params): void {
        $allowedFields = [
            'theme', 'language', 'notifications_enabled', 'sound_enabled', 
            'vibration_enabled', 'privacy_profile', 'privacy_last_seen', 
            'privacy_wall', 'auto_download_mobile', 'auto_download_wifi',
            'mesh_enabled', 'bluetooth_enabled', 'wifi_direct_enabled'
        ];

        $updates = [];
        $values = [];

        foreach ($allowedFields as $field) {
            if (isset($data[$field])) {
                $updates[] = "$field = ?";
                $values[] = is_bool($data[$field]) ? ($data[$field] ? 1 : 0) : $data[$field];
            }
        }

        if (empty($updates)) {
            Response::error('No settings to update', 400);
        }

        $values[] = $user['sub'];

        try {
            $sql = "UPDATE user_settings SET " . implode(', ', $updates) . ", updated_at = NOW() WHERE user_id = ?";
            $this->db->prepare($sql)->execute($values);

            Response::success(null, 'Settings updated');
        } catch (\Exception $e) {
            Response::error('Failed to update settings', 500);
        }
    }

    /**
     * GET /api/settings/app
     * Uygulama ayarlarını getir
     */
    public function getApp(array $data, ?array $user, array $params): void {
        $stmt = $this->db->query("SELECT * FROM app_settings");
        $settings = $stmt->fetchAll();

        $result = [];
        foreach ($settings as $setting) {
            $value = $setting['setting_value'];
            if ($setting['setting_type'] === 'integer') {
                $value = (int)$value;
            } elseif ($setting['setting_type'] === 'boolean') {
                $value = $value === 'true' || $value === '1';
            } elseif ($setting['setting_type'] === 'json') {
                $value = json_decode($value, true);
            }
            $result[$setting['setting_key']] = $value;
        }

        Response::success($result);
    }
}
