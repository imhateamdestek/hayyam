<?php
/**
 * Hayyam - Media Controller
 * Dosya yükleme ve yönetimi
 */

namespace Hayyam\Controllers;

use Hayyam\Config\Database;
use Hayyam\Config\Security;
use Hayyam\Config\Response;
use PDO;

class MediaController {
    private PDO $db;
    private string $uploadPath;
    private int $maxFileSize;

    public function __construct() {
        $this->db = Database::getInstance();
        $this->uploadPath = __DIR__ . '/../../uploads/';
        $this->maxFileSize = (int)($_ENV['MAX_FILE_SIZE'] ?? 104857600); // 100MB
    }

    /**
     * POST /api/media/upload
     * Dosya yükle
     */
    public function postUpload(array $data, ?array $user, array $params): void {
        if (empty($data['file_base64']) || empty($data['filename'])) {
            Response::error('File data and filename are required', 400);
        }

        $fileData = base64_decode($data['file_base64']);
        $originalName = $data['filename'];
        $fileSize = strlen($fileData);

        if ($fileSize > $this->maxFileSize) {
            Response::error('File too large. Max size: ' . ($this->maxFileSize / 1048576) . 'MB', 413);
        }

        // Dosya tipini kontrol et
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mimeType = finfo_buffer($finfo, $fileData);
        finfo_close($finfo);

        $allowedTypes = [
            'image/jpeg', 'image/png', 'image/gif', 'image/webp',
            'video/mp4', 'video/webm', 'video/ogg',
            'audio/mpeg', 'audio/ogg', 'audio/wav',
            'application/pdf', 'text/plain'
        ];

        if (!in_array($mimeType, $allowedTypes)) {
            Response::error('File type not allowed: ' . $mimeType, 415);
        }

        // Dosyayı şifrele
        $encrypted = Security::encrypt($fileData);

        $uuid = Security::randomString(36);
        $extension = pathinfo($originalName, PATHINFO_EXTENSION);
        $filename = Security::randomString(16) . '.' . $extension;

        $typeDir = explode('/', $mimeType)[0] . 's/';
        $uploadDir = $this->uploadPath . $typeDir;

        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }

        $filepath = $uploadDir . $filename;

        if (file_put_contents($filepath, base64_decode($encrypted['data']))) {
            // Thumbnail oluştur (görsel için)
            $thumbnailPath = null;
            if (strpos($mimeType, 'image/') === 0) {
                $thumbnailPath = $this->createThumbnail($filepath, $uploadDir . 'thumb_' . $filename);
            }

            // Veritabanına kaydet
            $stmt = $this->db->prepare("
                INSERT INTO media_files 
                (uuid, user_id, file_name, original_name, file_path, file_size, 
                 mime_type, thumbnail_path, is_encrypted, encryption_key, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, TRUE, ?, NOW())
            ");

            $stmt->execute([
                $uuid,
                $user['sub'],
                $filename,
                $originalName,
                $typeDir . $filename,
                $fileSize,
                $mimeType,
                $thumbnailPath ? $typeDir . 'thumb_' . $filename : null,
                $encrypted['key'] ?? null
            ]);

            $mediaId = $this->db->lastInsertId();

            Response::success([
                'media_id' => $mediaId,
                'uuid' => $uuid,
                'url' => '/uploads/' . $typeDir . $filename,
                'thumbnail_url' => $thumbnailPath ? '/uploads/' . $typeDir . 'thumb_' . $filename : null,
                'mime_type' => $mimeType,
                'size' => $fileSize
            ], 'File uploaded', 201);
        } else {
            Response::error('Failed to save file', 500);
        }
    }

    /**
     * GET /api/media/download
     * Dosya indir
     */
    public function getDownload(array $data, ?array $user, array $params): void {
        $uuid = $_GET['uuid'] ?? null;

        if (!$uuid) {
            Response::error('UUID is required', 400);
        }

        $stmt = $this->db->prepare("
            SELECT * FROM media_files WHERE uuid = ? AND user_id = ?
        ");
        $stmt->execute([$uuid, $user['sub']]);
        $file = $stmt->fetch();

        if (!$file) {
            Response::error('File not found', 404);
        }

        $filepath = $this->uploadPath . $file['file_path'];

        if (!file_exists($filepath)) {
            Response::error('File not found on disk', 404);
        }

        header('Content-Type: ' . $file['mime_type']);
        header('Content-Disposition: attachment; filename="' . $file['original_name'] . '"');
        header('Content-Length: ' . filesize($filepath));

        readfile($filepath);
        exit;
    }

    private function createThumbnail(string $source, string $dest, int $maxWidth = 300): ?string {
        if (!extension_loaded('gd')) {
            return null;
        }

        $info = getimagesize($source);
        if (!$info) return null;

        list($width, $height) = $info;

        if ($width <= $maxWidth) {
            copy($source, $dest);
            return $dest;
        }

        $ratio = $maxWidth / $width;
        $newWidth = $maxWidth;
        $newHeight = $height * $ratio;

        switch ($info['mime']) {
            case 'image/jpeg': $src = imagecreatefromjpeg($source); break;
            case 'image/png': $src = imagecreatefrompng($source); break;
            case 'image/gif': $src = imagecreatefromgif($source); break;
            default: return null;
        }

        $thumb = imagecreatetruecolor($newWidth, $newHeight);
        imagecopyresampled($thumb, $src, 0, 0, 0, 0, $newWidth, $newHeight, $width, $height);

        imagejpeg($thumb, $dest, 85);
        imagedestroy($src);
        imagedestroy($thumb);

        return $dest;
    }
}
