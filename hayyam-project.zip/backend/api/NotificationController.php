<?php
/**
 * Hayyam - Notification Controller
 * Bildirim yönetimi
 */

namespace Hayyam\Controllers;

use Hayyam\Config\Database;
use Hayyam\Config\Response;
use PDO;

class NotificationController {
    private PDO $db;

    public function __construct() {
        $this->db = Database::getInstance();
    }

    /**
     * GET /api/notifications/list
     * Bildirimleri listele
     */
    public function getList(array $data, ?array $user, array $params): void {
        $page = (int)($_GET['page'] ?? 1);
        $perPage = min((int)($_GET['per_page'] ?? 20), 50);
        $offset = ($page - 1) * $perPage;

        $stmt = $this->db->prepare("
            SELECT * FROM notifications
            WHERE user_id = ?
            ORDER BY created_at DESC
            LIMIT ? OFFSET ?
        ");
        $stmt->execute([$user['sub'], $perPage, $offset]);
        $notifications = $stmt->fetchAll();

        // Okunmamış sayısı
        $stmt = $this->db->prepare("
            SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = FALSE
        ");
        $stmt->execute([$user['sub']]);
        $unreadCount = (int)$stmt->fetchColumn();

        Response::success([
            'notifications' => $notifications,
            'unread_count' => $unreadCount
        ]);
    }

    /**
     * POST /api/notifications/read
     * Bildirimi okundu olarak işaretle
     */
    public function postRead(array $data, ?array $user, array $params): void {
        $notificationId = $data['notification_id'] ?? null;

        if ($notificationId) {
            $this->db->prepare("
                UPDATE notifications SET is_read = TRUE, read_at = NOW() 
                WHERE id = ? AND user_id = ?
            ")->execute([$notificationId, $user['sub']]);
        } else {
            // Tümünü okundu işaretle
            $this->db->prepare("
                UPDATE notifications SET is_read = TRUE, read_at = NOW() 
                WHERE user_id = ? AND is_read = FALSE
            ")->execute([$user['sub']]);
        }

        Response::success(null, 'Marked as read');
    }

    /**
     * DELETE /api/notifications/delete
     * Bildirimi sil
     */
    public function deleteDelete(array $data, ?array $user, array $params): void {
        $notificationId = $data['notification_id'] ?? null;

        if (!$notificationId) {
            Response::error('Notification ID is required', 400);
        }

        $this->db->prepare("DELETE FROM notifications WHERE id = ? AND user_id = ?")
                 ->execute([$notificationId, $user['sub']]);

        Response::success(null, 'Notification deleted');
    }
}
