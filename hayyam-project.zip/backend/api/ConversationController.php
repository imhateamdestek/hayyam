<?php
/**
 * Hayyam - Conversation Controller
 * Konuşma yönetimi, grup oluşturma, üye ekleme
 */

namespace Hayyam\Controllers;

use Hayyam\Config\Database;
use Hayyam\Config\Security;
use Hayyam\Config\Response;
use PDO;

class ConversationController {
    private PDO $db;

    public function __construct() {
        $this->db = Database::getInstance();
    }

    /**
     * GET /api/conversations/list
     * Kullanıcının konuşmalarını listele
     */
    public function getList(array $data, ?array $user, array $params): void {
        $page = (int)($_GET['page'] ?? 1);
        $perPage = min((int)($_GET['per_page'] ?? 50), 100);
        $offset = ($page - 1) * $perPage;

        try {
            // Toplam konuşma sayısı
            $stmt = $this->db->prepare("
                SELECT COUNT(*) FROM conversation_members WHERE user_id = ?
            ");
            $stmt->execute([$user['sub']]);
            $total = (int)$stmt->fetchColumn();

            // Konuşmaları getir
            $stmt = $this->db->prepare("
                SELECT 
                    c.id as conversation_id,
                    c.uuid,
                    c.type,
                    c.title,
                    c.avatar_url,
                    c.last_message_at,
                    c.created_at,
                    cm.role,
                    cm.joined_at,
                    cm.last_read_message_id,
                    (SELECT COUNT(*) FROM messages m 
                     WHERE m.conversation_id = c.id 
                     AND m.id > COALESCE(cm.last_read_message_id, 0)
                     AND m.sender_id != ?
                     AND m.is_deleted = FALSE) as unread_count,
                    (SELECT content FROM messages 
                     WHERE conversation_id = c.id AND is_deleted = FALSE
                     ORDER BY created_at DESC LIMIT 1) as last_message,
                    (SELECT u.display_name FROM messages m2
                     JOIN users u ON m2.sender_id = u.id
                     WHERE m2.conversation_id = c.id AND m2.is_deleted = FALSE
                     ORDER BY m2.created_at DESC LIMIT 1) as last_sender_name
                FROM conversations c
                JOIN conversation_members cm ON c.id = cm.conversation_id
                WHERE cm.user_id = ?
                ORDER BY c.last_message_at DESC NULLS LAST
                LIMIT ? OFFSET ?
            ");
            $stmt->execute([$user['sub'], $user['sub'], $perPage, $offset]);
            $conversations = $stmt->fetchAll();

            // Özel konuşmalarda karşı tarafın bilgilerini ekle
            foreach ($conversations as &$conv) {
                if ($conv['type'] === 'private') {
                    $stmt = $this->db->prepare("
                        SELECT u.id, u.username, u.display_name, u.avatar_url, u.status, u.last_seen
                        FROM conversation_members cm
                        JOIN users u ON cm.user_id = u.id
                        WHERE cm.conversation_id = ? AND cm.user_id != ?
                    ");
                    $stmt->execute([$conv['conversation_id'], $user['sub']]);
                    $otherUser = $stmt->fetch();

                    if ($otherUser) {
                        $conv['title'] = $otherUser['display_name'];
                        $conv['username'] = $otherUser['username'];
                        $conv['avatar_url'] = $otherUser['avatar_url'];
                        $conv['status'] = $otherUser['status'];
                        $conv['last_seen'] = $otherUser['last_seen'];
                    }
                }
            }

            Response::success([
                'conversations' => $conversations,
                'pagination' => [
                    'current_page' => $page,
                    'per_page' => $perPage,
                    'total_items' => $total,
                    'total_pages' => (int)ceil($total / $perPage)
                ]
            ]);

        } catch (\Exception $e) {
            Response::error('Failed to fetch conversations: ' . $e->getMessage(), 500);
        }
    }

    /**
     * POST /api/conversations/create
     * Yeni konuşma oluştur
     */
    public function postCreate(array $data, ?array $user, array $params): void {
        $type = $data['type'] ?? 'private';
        $participants = $data['participants'] ?? [];
        $title = $data['title'] ?? null;

        if (empty($participants) && $type !== 'channel') {
            Response::error('At least one participant is required', 400);
        }

        try {
            $this->db->beginTransaction();

            $uuid = Security::randomString(36);

            // Konuşmayı oluştur
            $stmt = $this->db->prepare("
                INSERT INTO conversations (uuid, type, title, creator_id, created_at)
                VALUES (?, ?, ?, ?, NOW())
            ");
            $stmt->execute([$uuid, $type, $title, $user['sub']]);
            $conversationId = $this->db->lastInsertId();

            // Oluşturucuyu ekle
            $this->db->prepare("
                INSERT INTO conversation_members (conversation_id, user_id, role, joined_at)
                VALUES (?, ?, 'owner', NOW())
            ")->execute([$conversationId, $user['sub']]);

            // Katılımcıları ekle
            foreach ($participants as $participantId) {
                $this->db->prepare("
                    INSERT INTO conversation_members (conversation_id, user_id, role, joined_at)
                    VALUES (?, ?, 'member', NOW())
                ")->execute([$conversationId, $participantId]);
            }

            $this->db->commit();

            Response::success([
                'conversation_id' => $conversationId,
                'uuid' => $uuid,
                'type' => $type
            ], 'Conversation created', 201);

        } catch (\Exception $e) {
            $this->db->rollBack();
            Response::error('Failed to create conversation: ' . $e->getMessage(), 500);
        }
    }

    /**
     * GET /api/conversations/info
     * Konuşma bilgisi
     */
    public function getInfo(array $data, ?array $user, array $params): void {
        $conversationId = $_GET['id'] ?? null;

        if (!$conversationId) {
            Response::error('Conversation ID is required', 400);
        }

        $stmt = $this->db->prepare("
            SELECT c.*, cm.role, cm.joined_at
            FROM conversations c
            JOIN conversation_members cm ON c.id = cm.conversation_id
            WHERE c.id = ? AND cm.user_id = ?
        ");
        $stmt->execute([$conversationId, $user['sub']]);
        $conversation = $stmt->fetch();

        if (!$conversation) {
            Response::error('Conversation not found', 404);
        }

        // Üyeleri getir
        $stmt = $this->db->prepare("
            SELECT u.id, u.username, u.display_name, u.avatar_url, u.status, cm.role, cm.joined_at
            FROM conversation_members cm
            JOIN users u ON cm.user_id = u.id
            WHERE cm.conversation_id = ?
        ");
        $stmt->execute([$conversationId]);
        $members = $stmt->fetchAll();

        $conversation['members'] = $members;

        Response::success($conversation);
    }

    /**
     * POST /api/conversations/join
     * Konuşmaya katıl
     */
    public function postJoin(array $data, ?array $user, array $params): void {
        $conversationId = $data['conversation_id'] ?? null;

        if (!$conversationId) {
            Response::error('Conversation ID is required', 400);
        }

        try {
            $this->db->prepare("
                INSERT INTO conversation_members (conversation_id, user_id, role, joined_at)
                VALUES (?, ?, 'member', NOW())
            ")->execute([$conversationId, $user['sub']]);

            Response::success(null, 'Joined conversation');
        } catch (\Exception $e) {
            Response::error('Failed to join conversation', 500);
        }
    }

    /**
     * DELETE /api/conversations/leave
     * Konuşmadan ayrıl
     */
    public function deleteLeave(array $data, ?array $user, array $params): void {
        $conversationId = $data['conversation_id'] ?? null;

        if (!$conversationId) {
            Response::error('Conversation ID is required', 400);
        }

        try {
            $this->db->prepare("
                DELETE FROM conversation_members 
                WHERE conversation_id = ? AND user_id = ?
            ")->execute([$conversationId, $user['sub']]);

            Response::success(null, 'Left conversation');
        } catch (\Exception $e) {
            Response::error('Failed to leave conversation', 500);
        }
    }
}
