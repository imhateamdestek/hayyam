<?php
/**
 * Hayyam - Bot Controller
 * Bot oluşturma, yönetim, webhook, BotFather benzeri sistem
 */

namespace Hayyam\Controllers;

use Hayyam\Config\Database;
use Hayyam\Config\Security;
use Hayyam\Config\Response;
use PDO;

class BotController {
    private PDO $db;

    public function __construct() {
        $this->db = Database::getInstance();
    }

    /**
     * POST /api/bots/create
     * Yeni bot oluştur (BotFather benzeri)
     */
    public function postCreate(array $data, ?array $user, array $params): void {
        $required = ['name', 'username'];
        foreach ($required as $field) {
            if (empty($data[$field])) {
                Response::error("Field '$field' is required", 400);
            }
        }

        $name = trim($data['name']);
        $username = strtolower(trim($data['username']));
        $description = $data['description'] ?? '';
        $language = $data['language'] ?? 'python';
        $isPublic = $data['is_public'] ?? false;

        // Username validasyonu
        if (!preg_match('/^[a-z0-9_]{3,32}$/', $username)) {
            Response::error('Bot username must be 3-32 chars, alphanumeric and underscore', 400);
        }

        // Benzersizlik kontrolü
        $stmt = $this->db->prepare("SELECT id FROM bots WHERE username = ?");
        $stmt->execute([$username]);
        if ($stmt->fetch()) {
            Response::error('Bot username already taken', 409);
        }

        $uuid = Security::randomString(36);
        $apiToken = 'hayyam_' . Security::randomString(48);

        // Varsayılan webhook URL'i oluştur
        $webhookUrl = ($_ENV['APP_URL'] ?? 'https://api.hayyam.app') . "/webhooks/bots/$username";

        try {
            $stmt = $this->db->prepare("
                INSERT INTO bots 
                (uuid, owner_id, name, username, description, language, api_token, 
                 webhook_url, is_public, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
            ");

            $stmt->execute([
                $uuid,
                $user['sub'],
                $name,
                $username,
                $description,
                $language,
                $apiToken,
                $webhookUrl,
                $isPublic ? 1 : 0
            ]);

            $botId = $this->db->lastInsertId();

            // Varsayılan komutları ekle
            $defaultCommands = [
                ['start', 'Botu başlat', null, "Merhaba! Ben $name. Size nasıl yardımcı olabilirim?"],
                ['help', 'Yardım menüsü', null, 'Mevcut komutlar: /start, /help, /about'],
                ['about', 'Bot hakkında', null, "Bot: $name\nDil: $language\nSahip: @" . $user['username']]
            ];

            foreach ($defaultCommands as $cmd) {
                $this->db->prepare("
                    INSERT INTO bot_commands (bot_id, command, description, parameters, response_template)
                    VALUES (?, ?, ?, ?, ?)
                ")->execute([$botId, $cmd[0], $cmd[1], $cmd[2] ? json_encode($cmd[2]) : null, $cmd[3]]);
            }

            Response::success([
                'bot_id' => $botId,
                'uuid' => $uuid,
                'name' => $name,
                'username' => $username,
                'api_token' => $apiToken,
                'webhook_url' => $webhookUrl,
                'language' => $language,
                'message' => 'Bot created successfully. Use the API token to connect your bot.'
            ], 'Bot created', 201);

        } catch (\Exception $e) {
            Response::error('Failed to create bot: ' . $e->getMessage(), 500);
        }
    }

    /**
     * GET /api/bots/list
     * Kullanıcının botlarını listele
     */
    public function getList(array $data, ?array $user, array $params): void {
        $stmt = $this->db->prepare("
            SELECT b.*, 
                   (SELECT COUNT(*) FROM bot_conversations WHERE bot_id = b.id) as conversation_count,
                   (SELECT COUNT(*) FROM bot_commands WHERE bot_id = b.id) as command_count
            FROM bots b
            WHERE b.owner_id = ? AND b.is_active = TRUE
            ORDER BY b.created_at DESC
        ");
        $stmt->execute([$user['sub']]);
        $bots = $stmt->fetchAll();

        Response::success(['bots' => $bots]);
    }

    /**
     * POST /api/bots/command
     * Bot komutu ekle/güncelle
     */
    public function postCommand(array $data, ?array $user, array $params): void {
        if (empty($data['bot_id']) || empty($data['command']) || empty($data['description'])) {
            Response::error('Bot ID, command and description are required', 400);
        }

        $botId = $data['bot_id'];
        $command = strtolower(trim($data['command']));
        $description = $data['description'];
        $parameters = $data['parameters'] ?? null;
        $responseTemplate = $data['response_template'] ?? null;

        // Bot sahibi mi kontrol et
        $stmt = $this->db->prepare("SELECT owner_id FROM bots WHERE id = ? AND is_active = TRUE");
        $stmt->execute([$botId]);
        $bot = $stmt->fetch();

        if (!$bot || $bot['owner_id'] != $user['sub']) {
            Response::error('Bot not found or access denied', 403);
        }

        try {
            $stmt = $this->db->prepare("
                INSERT INTO bot_commands (bot_id, command, description, parameters, response_template)
                VALUES (?, ?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE 
                description = VALUES(description),
                parameters = VALUES(parameters),
                response_template = VALUES(response_template)
            ");

            $stmt->execute([
                $botId,
                $command,
                $description,
                $parameters ? json_encode($parameters) : null,
                $responseTemplate
            ]);

            Response::success([
                'command' => $command,
                'bot_id' => $botId
            ], 'Command saved');

        } catch (\Exception $e) {
            Response::error('Failed to save command: ' . $e->getMessage(), 500);
        }
    }

    /**
     * POST /api/bots/webhook
     * Webhook URL güncelle
     */
    public function postWebhook(array $data, ?array $user, array $params): void {
        if (empty($data['bot_id']) || empty($data['webhook_url'])) {
            Response::error('Bot ID and webhook URL are required', 400);
        }

        $botId = $data['bot_id'];
        $webhookUrl = $data['webhook_url'];

        // URL validasyonu
        if (!filter_var($webhookUrl, FILTER_VALIDATE_URL)) {
            Response::error('Invalid webhook URL', 400);
        }

        $stmt = $this->db->prepare("SELECT owner_id FROM bots WHERE id = ?");
        $stmt->execute([$botId]);
        $bot = $stmt->fetch();

        if (!$bot || $bot['owner_id'] != $user['sub']) {
            Response::error('Access denied', 403);
        }

        $this->db->prepare("UPDATE bots SET webhook_url = ? WHERE id = ?")
                 ->execute([$webhookUrl, $botId]);

        Response::success(['webhook_url' => $webhookUrl], 'Webhook updated');
    }

    /**
     * POST /api/bots/interact
     * Bot ile etkileşim (kullanıcıdan bot'a mesaj)
     */
    public function postInteract(array $data, ?array $user, array $params): void {
        if (empty($data['bot_username']) || empty($data['message'])) {
            Response::error('Bot username and message are required', 400);
        }

        $botUsername = strtolower(trim($data['bot_username']));
        $message = $data['message'];
        $conversationId = $data['conversation_id'] ?? null;

        // Bot'u bul
        $stmt = $this->db->prepare("
            SELECT b.*, u.username as owner_username
            FROM bots b
            JOIN users u ON b.owner_id = u.id
            WHERE b.username = ? AND b.is_active = TRUE
        ");
        $stmt->execute([$botUsername]);
        $bot = $stmt->fetch();

        if (!$bot) {
            Response::error('Bot not found', 404);
        }

        // Bot konuşmasını bul/oluştur
        if (!$conversationId) {
            // Özel konuşma oluştur
            $uuid = Security::randomString(36);
            $this->db->prepare("INSERT INTO conversations (uuid, type, title, created_at) VALUES (?, 'private', ?, NOW())")
                     ->execute([$uuid, "Bot: {$bot['name']}"]);
            $conversationId = $this->db->lastInsertId();

            // Üyeleri ekle
            $this->db->prepare("INSERT INTO conversation_members (conversation_id, user_id) VALUES (?, ?)")
                     ->execute([$conversationId, $user['sub']]);
            $this->db->prepare("INSERT INTO conversation_members (conversation_id, user_id) VALUES (?, ?)")
                     ->execute([$conversationId, $bot['owner_id']]);

            // Bot konuşmasını kaydet
            $this->db->prepare("
                INSERT INTO bot_conversations (bot_id, user_id, conversation_id, last_interaction)
                VALUES (?, ?, ?, NOW())
                ON DUPLICATE KEY UPDATE last_interaction = NOW()
            ")->execute([$bot['id'], $user['sub'], $conversationId]);
        }

        // Mesajı kaydet
        $msgUuid = Security::randomString(36);
        $this->db->prepare("
            INSERT INTO messages (uuid, conversation_id, sender_id, type, content, created_at)
            VALUES (?, ?, ?, 'text', ?, NOW())
        ")->execute([$msgUuid, $conversationId, $user['sub'], $message]);

        // Webhook'a gönder (asenkron)
        $this->sendWebhook($bot['webhook_url'], [
            'update_id' => time(),
            'message' => [
                'message_id' => $this->db->lastInsertId(),
                'from' => [
                    'id' => $user['sub'],
                    'username' => $user['username'],
                    'display_name' => $user['display_name'] ?? $user['username']
                ],
                'chat' => [
                    'id' => $conversationId,
                    'type' => 'private'
                ],
                'date' => time(),
                'text' => $message
            ],
            'bot_token' => $bot['api_token']
        ]);

        Response::success([
            'conversation_id' => $conversationId,
            'message_sent' => true,
            'bot_response' => 'Webhook triggered'
        ]);
    }

    /**
     * GET /api/bots/public
     * Halka açık botları listele
     */
    public function getPublic(array $data, ?array $user, array $params): void {
        $search = $_GET['search'] ?? '';
        $page = (int)($_GET['page'] ?? 1);
        $perPage = min((int)($_GET['per_page'] ?? 20), 50);
        $offset = ($page - 1) * $perPage;

        $sql = "
            SELECT b.id, b.uuid, b.name, b.username, b.description, b.language,
                   b.avatar_url, b.is_public, b.created_at,
                   u.username as owner_username, u.display_name as owner_name
            FROM bots b
            JOIN users u ON b.owner_id = u.id
            WHERE b.is_public = TRUE AND b.is_active = TRUE
        ";
        $params = [];

        if ($search) {
            $sql .= " AND (b.name LIKE ? OR b.username LIKE ? OR b.description LIKE ?)";
            $searchTerm = "%$search%";
            $params = [$searchTerm, $searchTerm, $searchTerm];
        }

        $sql .= " ORDER BY b.created_at DESC LIMIT ? OFFSET ?";
        $params[] = $perPage;
        $params[] = $offset;

        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        $bots = $stmt->fetchAll();

        Response::success([
            'bots' => $bots,
            'page' => $page,
            'has_more' => count($bots) === $perPage
        ]);
    }

    private function sendWebhook(string $url, array $data): void {
        // cURL ile asenkron webhook gönderimi
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 5);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

        // Asenkron gönderim
        curl_setopt($ch, CURLOPT_NOSIGNAL, 1);
        curl_setopt($ch, CURLOPT_TIMEOUT_MS, 500);

        curl_exec($ch);
        curl_close($ch);
    }
}
