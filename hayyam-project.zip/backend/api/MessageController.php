<?php
/**
 * Hayyam - Message Controller
 * Mesaj gönderme, alma, şifreleme, mesh routing
 */

namespace Hayyam\Controllers;

use Hayyam\Config\Database;
use Hayyam\Config\Security;
use Hayyam\Config\Response;
use PDO;

class MessageController {
    private PDO $db;

    public function __construct() {
        $this->db = Database::getInstance();
    }

    /**
     * POST /api/messages/send
     * Mesaj gönder (Internet / WiFi / Bluetooth)
     */
    public function postSend(array $data, ?array $user, array $params): void {
        if (empty($data['conversation_id']) || empty($data['content'])) {
            Response::error('Conversation ID and content are required', 400);
        }

        $conversationId = $data['conversation_id'];
        $content = $data['content'];
        $type = $data['type'] ?? 'text';
        $replyToId = $data['reply_to_id'] ?? null;

        // Kullanıcının konuşmaya erişimi var mı?
        $stmt = $this->db->prepare("
            SELECT cm.conversation_id, c.is_encrypted 
            FROM conversation_members cm
            JOIN conversations c ON cm.conversation_id = c.id
            WHERE cm.conversation_id = ? AND cm.user_id = ?
        ");
        $stmt->execute([$conversationId, $user['sub']]);
        $membership = $stmt->fetch();

        if (!$membership) {
            Response::error('You are not a member of this conversation', 403);
        }

        $uuid = Security::randomString(36);
        $encrypted = Security::encrypt($content);

        try {
            $this->db->beginTransaction();

            // Mesajı kaydet
            $stmt = $this->db->prepare("
                INSERT INTO messages (uuid, conversation_id, sender_id, reply_to_id, type, 
                                    content, content_encrypted, created_at)
                VALUES (?, ?, ?, ?, ?, ?, TRUE, NOW())
            ");
            $stmt->execute([
                $uuid,
                $conversationId,
                $user['sub'],
                $replyToId,
                $type,
                json_encode($encrypted)
            ]);

            $messageId = $this->db->lastInsertId();

            // Alıcıları bul
            $stmt = $this->db->prepare("
                SELECT user_id FROM conversation_members 
                WHERE conversation_id = ? AND user_id != ?
            ");
            $stmt->execute([$conversationId, $user['sub']]);
            $recipients = $stmt->fetchAll(PDO::FETCH_COLUMN);

            // Bildirim oluştur
            foreach ($recipients as $recipientId) {
                $stmt = $this->db->prepare("
                    INSERT INTO notifications (user_id, type, title, body, data, created_at)
                    VALUES (?, 'message', 'New Message', ?, ?, NOW())
                ");
                $stmt->execute([
                    $recipientId,
                    substr($content, 0, 100),
                    json_encode(['conversation_id' => $conversationId, 'message_id' => $messageId])
                ]);
            }

            $this->db->commit();

            Response::success([
                'message_id' => $messageId,
                'uuid' => $uuid,
                'conversation_id' => $conversationId,
                'status' => 'sent',
                'timestamp' => time()
            ], 'Message sent successfully');

        } catch (\Exception $e) {
            $this->db->rollBack();
            Response::error('Failed to send message: ' . $e->getMessage(), 500);
        }
    }

    /**
     * GET /api/messages/history
     * Mesaj geçmişi
     */
    public function getHistory(array $data, ?array $user, array $params): void {
        $conversationId = $_GET['conversation_id'] ?? null;
        $page = (int)($_GET['page'] ?? 1);
        $perPage = min((int)($_GET['per_page'] ?? 50), 100);

        if (!$conversationId) {
            Response::error('Conversation ID is required', 400);
        }

        // Erişim kontrolü
        $stmt = $this->db->prepare("
            SELECT 1 FROM conversation_members 
            WHERE conversation_id = ? AND user_id = ?
        ");
        $stmt->execute([$conversationId, $user['sub']]);
        if (!$stmt->fetch()) {
            Response::error('Access denied', 403);
        }

        $offset = ($page - 1) * $perPage;

        // Toplam mesaj sayısı
        $stmt = $this->db->prepare("
            SELECT COUNT(*) FROM messages 
            WHERE conversation_id = ? AND is_deleted = FALSE
        ");
        $stmt->execute([$conversationId]);
        $total = (int)$stmt->fetchColumn();

        // Mesajları getir
        $stmt = $this->db->prepare("
            SELECT m.id, m.uuid, m.sender_id, m.type, m.content, m.content_encrypted,
                   m.file_url, m.file_name, m.file_size, m.mime_type,
                   m.latitude, m.longitude, m.is_edited, m.created_at,
                   u.username, u.display_name, u.avatar_url,
                   CASE WHEN m.sender_id = ? THEN TRUE ELSE FALSE END as is_mine
            FROM messages m
            JOIN users u ON m.sender_id = u.id
            WHERE m.conversation_id = ? AND m.is_deleted = FALSE
            ORDER BY m.created_at DESC
            LIMIT ? OFFSET ?
        ");
        $stmt->execute([$user['sub'], $conversationId, $perPage, $offset]);
        $messages = $stmt->fetchAll();

        // Şifrelenmiş içerikleri çöz
        foreach ($messages as &$msg) {
            if ($msg['content_encrypted']) {
                $encrypted = json_decode($msg['content'], true);
                if ($encrypted) {
                    $msg['content'] = Security::decrypt(
                        $encrypted['data'], 
                        $encrypted['iv'], 
                        $encrypted['tag']
                    ) ?: '[Encrypted]';
                }
            }
            unset($msg['content_encrypted']);
        }

        // Okundu bilgisini güncelle
        $lastMessageId = $messages[0]['id'] ?? 0;
        if ($lastMessageId) {
            $this->db->prepare("
                UPDATE conversation_members 
                SET last_read_message_id = ? 
                WHERE conversation_id = ? AND user_id = ?
            ")->execute([$lastMessageId, $conversationId, $user['sub']]);
        }

        Response::paginate(array_reverse($messages), $page, $perPage, $total);
    }

    /**
     * POST /api/messages/mesh-send
     * Mesh/Offline mesaj gönder (Deprem modu)
     */
    public function postMeshSend(array $data, ?array $user, array $params): void {
        if (empty($data['recipient_username']) || empty($data['content'])) {
            Response::error('Recipient and content are required', 400);
        }

        $recipientUsername = strtolower(trim($data['recipient_username']));
        $content = $data['content'];
        $deliveryMethod = $data['delivery_method'] ?? 'pending';
        $deviceFingerprint = $data['device_fingerprint'] ?? null;

        // Alıcıyı bul
        $stmt = $this->db->prepare("SELECT id, public_key FROM users WHERE username = ?");
        $stmt->execute([$recipientUsername]);
        $recipient = $stmt->fetch();

        if (!$recipient) {
            Response::error('Recipient not found', 404);
        }

        $uuid = Security::randomString(36);
        $originalUuid = Security::randomString(36);

        // Alıcının public key'i ile şifrele
        $encrypted = Security::encrypt($content);

        $expiresAt = date('Y-m-d H:i:s', time() + 86400); // 24 saat

        try {
            $stmt = $this->db->prepare("
                INSERT INTO offline_messages 
                (uuid, original_message_uuid, sender_id, recipient_id, content_encrypted, 
                 encryption_iv, delivery_method, device_fingerprint, expires_at, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
            ");

            $stmt->execute([
                $uuid,
                $originalUuid,
                $user['sub'],
                $recipient['id'],
                $encrypted['data'],
                $encrypted['iv'],
                $deliveryMethod,
                $deviceFingerprint,
                $expiresAt
            ]);

            Response::success([
                'message_uuid' => $uuid,
                'original_uuid' => $originalUuid,
                'status' => 'pending',
                'delivery_method' => $deliveryMethod,
                'expires_at' => $expiresAt
            ], 'Offline message queued for mesh delivery');

        } catch (\Exception $e) {
            Response::error('Failed to queue message: ' . $e->getMessage(), 500);
        }
    }

    /**
     * GET /api/messages/mesh-pending
     * Bekleyen mesh mesajlarını al
     */
    public function getMeshPending(array $data, ?array $user, array $params): void {
        $deviceFingerprint = $_GET['device_fingerprint'] ?? null;

        $sql = "
            SELECT om.uuid, om.original_message_uuid, om.content_encrypted, 
                   om.encryption_iv, om.hop_count, om.max_hops, om.created_at,
                   s.username as sender_username, s.display_name as sender_name
            FROM offline_messages om
            JOIN users s ON om.sender_id = s.id
            WHERE om.recipient_id = ? AND om.status = 'pending'
            AND om.expires_at > NOW()
        ";

        $params = [$user['sub']];

        if ($deviceFingerprint) {
            $sql .= " AND (om.device_fingerprint IS NULL OR om.device_fingerprint != ?)";
            $params[] = $deviceFingerprint;
        }

        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        $messages = $stmt->fetchAll();

        Response::success([
            'count' => count($messages),
            'messages' => $messages
        ]);
    }

    /**
     * POST /api/messages/mesh-confirm
     * Mesh mesaj teslimatını onayla
     */
    public function postMeshConfirm(array $data, ?array $user, array $params): void {
        if (empty($data['message_uuid'])) {
            Response::error('Message UUID is required', 400);
        }

        $stmt = $this->db->prepare("
            UPDATE offline_messages 
            SET status = 'delivered', delivered_at = NOW() 
            WHERE uuid = ? AND recipient_id = ?
        ");
        $stmt->execute([$data['message_uuid'], $user['sub']]);

        Response::success(null, 'Delivery confirmed');
    }

    /**
     * POST /api/messages/typing
     * Yazıyor... bildirimi
     */
    public function postTyping(array $data, ?array $user, array $params): void {
        $conversationId = $data['conversation_id'] ?? null;
        $isTyping = $data['typing'] ?? false;

        if (!$conversationId) {
            Response::error('Conversation ID is required', 400);
        }

        // WebSocket üzerinden broadcast yapılacak
        // Şimdilik sadece kaydet
        Response::success(['typing' => $isTyping]);
    }

    /**
     * DELETE /api/messages/delete
     * Mesaj sil (herkesten veya kendinden)
     */
    public function deleteDelete(array $data, ?array $user, array $params): void {
        if (empty($data['message_id'])) {
            Response::error('Message ID is required', 400);
        }

        $messageId = $data['message_id'];
        $deleteForEveryone = $data['for_everyone'] ?? false;

        // Mesajı kontrol et
        $stmt = $this->db->prepare("SELECT sender_id FROM messages WHERE id = ?");
        $stmt->execute([$messageId]);
        $message = $stmt->fetch();

        if (!$message) {
            Response::error('Message not found', 404);
        }

        if ($deleteForEveryone && $message['sender_id'] != $user['sub']) {
            Response::error('You can only delete your own messages for everyone', 403);
        }

        if ($deleteForEveryone) {
            $this->db->prepare("
                UPDATE messages 
                SET is_deleted = TRUE, deleted_at = NOW(), content = '[Deleted]' 
                WHERE id = ?
            ")->execute([$messageId]);
        } else {
            // Sadece kendinden sil (implementasyon detayı)
            Response::success(null, 'Message deleted for you');
            return;
        }

        Response::success(null, 'Message deleted for everyone');
    }
}
