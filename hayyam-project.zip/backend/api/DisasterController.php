<?php
/**
 * Hayyam - Disaster Mode Controller
 * Deprem/afet anında özel mod, acil durum iletişimi
 */

namespace Hayyam\Controllers;

use Hayyam\Config\Database;
use Hayyam\Config\Security;
use Hayyam\Config\Response;
use PDO;

class DisasterController {
    private PDO $db;

    public function __construct() {
        $this->db = Database::getInstance();
    }

    /**
     * POST /api/disaster/activate
     * Afet modunu aktifleştir
     */
    public function postActivate(array $data, ?array $user, array $params): void {
        $latitude = $data['latitude'] ?? null;
        $longitude = $data['longitude'] ?? null;
        $accuracy = $data['accuracy'] ?? null;
        $deviceInfo = $data['device_info'] ?? null;
        $batteryLevel = $data['battery_level'] ?? null;
        $networkType = $data['network_type'] ?? null;

        // Kullanıcı ayarlarını güncelle
        $this->db->prepare("
            UPDATE user_settings 
            SET disaster_mode_enabled = TRUE, mesh_enabled = TRUE, 
                bluetooth_enabled = TRUE, wifi_direct_enabled = TRUE
            WHERE user_id = ?
        ")->execute([$user['sub']]);

        // Afet log kaydı
        $stmt = $this->db->prepare("
            INSERT INTO disaster_logs 
            (user_id, event_type, latitude, longitude, accuracy, device_info, battery_level, network_type)
            VALUES (?, 'enter_disaster_mode', ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $user['sub'], $latitude, $longitude, $accuracy, 
            $deviceInfo, $batteryLevel, $networkType
        ]);

        // Yakındaki kullanıcıları bul (son 1 saat içinde aktif olanlar)
        $stmt = $this->db->prepare("
            SELECT u.id, u.username, u.display_name, u.avatar_url, u.status,
                   dl.latitude, dl.longitude, dl.device_info, dl.battery_level,
                   (6371 * acos(cos(radians(?)) * cos(radians(dl.latitude)) * 
                    cos(radians(dl.longitude) - radians(?)) + 
                    sin(radians(?)) * sin(radians(dl.latitude)))) AS distance_km
            FROM disaster_logs dl
            JOIN users u ON dl.user_id = u.id
            WHERE dl.event_type = 'enter_disaster_mode'
            AND dl.created_at > DATE_SUB(NOW(), INTERVAL 1 HOUR)
            AND dl.user_id != ?
            HAVING distance_km < 5
            ORDER BY distance_km ASC
            LIMIT 50
        ");
        $stmt->execute([$latitude, $longitude, $latitude, $user['sub']]);
        $nearbyUsers = $stmt->fetchAll();

        Response::success([
            'disaster_mode' => true,
            'activated_at' => time(),
            'nearby_users' => $nearbyUsers,
            'total_nearby' => count($nearbyUsers),
            'tips' => [
                'WiFi Direct ve Bluetooth otomatik olarak aktifleştirildi',
                'Mesajlarınız şifrelenerek yakındaki cihazlara iletilecek',
                'Pil tasarrufu için ekran parlaklığını düşürün',
                'Acil durum mesajlarınızı kısa tutun'
            ]
        ], 'Disaster mode activated');
    }

    /**
     * POST /api/disaster/deactivate
     * Afet modunu kapat
     */
    public function postDeactivate(array $data, ?array $user, array $params): void {
        $this->db->prepare("
            UPDATE user_settings 
            SET disaster_mode_enabled = FALSE 
            WHERE user_id = ?
        ")->execute([$user['sub']]);

        $stmt = $this->db->prepare("
            INSERT INTO disaster_logs (user_id, event_type, created_at)
            VALUES (?, 'exit_disaster_mode', NOW())
        ");
        $stmt->execute([$user['sub']]);

        Response::success(['disaster_mode' => false], 'Disaster mode deactivated');
    }

    /**
     * POST /api/disaster/sos
     * SOS sinyali gönder
     */
    public function postSos(array $data, ?array $user, array $params): void {
        $latitude = $data['latitude'] ?? null;
        $longitude = $data['longitude'] ?? null;
        $message = $data['message'] ?? 'ACİL YARDIM! Konumum paylaşıldı.';
        $injuryStatus = $data['injury_status'] ?? 'unknown'; // unknown, safe, injured, critical
        $peopleCount = $data['people_count'] ?? 1;

        // SOS mesajını oluştur
        $sosContent = json_encode([
            'type' => 'sos',
            'message' => $message,
            'injury_status' => $injuryStatus,
            'people_count' => $peopleCount,
            'timestamp' => time(),
            'sender_id' => $user['sub'],
            'sender_username' => $user['username']
        ]);

        // Tüm yakındaki cihazlara broadcast (mesh üzerinden)
        $encrypted = Security::encrypt($sosContent);

        $uuid = Security::randomString(36);
        $stmt = $this->db->prepare("
            INSERT INTO offline_messages 
            (uuid, original_message_uuid, sender_id, recipient_id, content_encrypted,
             encryption_iv, delivery_method, max_hops, ttl, expires_at, created_at)
            VALUES (?, ?, ?, NULL, ?, ?, 'mesh', 20, 86400, DATE_ADD(NOW(), INTERVAL 24 HOUR), NOW())
        ");
        $stmt->execute([
            $uuid,
            $uuid,
            $user['sub'],
            $encrypted['data'],
            $encrypted['iv']
        ]);

        // Log kaydı
        $stmt = $this->db->prepare("
            INSERT INTO disaster_logs 
            (user_id, event_type, latitude, longitude, device_info, created_at)
            VALUES (?, 'mesh_message_sent', ?, ?, 'SOS Broadcast', NOW())
        ");
        $stmt->execute([$user['sub'], $latitude, $longitude]);

        Response::success([
            'sos_sent' => true,
            'message_uuid' => $uuid,
            'broadcast_range' => 'All nearby devices (max 20 hops)',
            'injury_status' => $injuryStatus,
            'estimated_reach' => 'Approximately 200-500 meters depending on device density'
        ], 'SOS signal broadcasted to all nearby devices');
    }

    /**
     * GET /api/disaster/nearby
     * Yakındaki afet modundaki kullanıcıları gör
     */
    public function getNearby(array $data, ?array $user, array $params): void {
        $latitude = $_GET['latitude'] ?? null;
        $longitude = $_GET['longitude'] ?? null;
        $radius = min((float)($_GET['radius'] ?? 5), 50); // Max 50km

        if (!$latitude || !$longitude) {
            Response::error('Latitude and longitude are required', 400);
        }

        $stmt = $this->db->prepare("
            SELECT 
                u.id, u.username, u.display_name, u.avatar_url, u.status,
                dl.latitude, dl.longitude, dl.battery_level, dl.network_type,
                dl.created_at as last_seen,
                (6371 * acos(cos(radians(?)) * cos(radians(dl.latitude)) * 
                 cos(radians(dl.longitude) - radians(?)) + 
                 sin(radians(?)) * sin(radians(dl.latitude)))) AS distance_km
            FROM disaster_logs dl
            JOIN users u ON dl.user_id = u.id
            JOIN user_settings us ON u.id = us.user_id
            WHERE dl.event_type = 'enter_disaster_mode'
            AND dl.created_at > DATE_SUB(NOW(), INTERVAL 6 HOUR)
            AND us.disaster_mode_enabled = TRUE
            AND dl.user_id != ?
            HAVING distance_km < ?
            ORDER BY distance_km ASC
        ");
        $stmt->execute([$latitude, $longitude, $latitude, $user['sub'], $radius]);
        $users = $stmt->fetchAll();

        // İstatistikler
        $stats = [
            'total_nearby' => count($users),
            'avg_battery' => count($users) > 0 ? array_sum(array_column($users, 'battery_level')) / count($users) : 0,
            'network_types' => array_count_values(array_column($users, 'network_type'))
        ];

        Response::success([
            'users' => $users,
            'stats' => $stats,
            'search_radius_km' => $radius
        ]);
    }

    /**
     * POST /api/disaster/status-update
     * Durum güncellemesi gönder
     */
    public function postStatusUpdate(array $data, ?array $user, array $params): void {
        $status = $data['status'] ?? 'ok'; // ok, help, injured, trapped, safe
        $latitude = $data['latitude'] ?? null;
        $longitude = $data['longitude'] ?? null;
        $details = $data['details'] ?? '';

        $content = json_encode([
            'type' => 'status_update',
            'status' => $status,
            'details' => $details,
            'timestamp' => time(),
            'sender' => $user['username']
        ]);

        $encrypted = Security::encrypt($content);
        $uuid = Security::randomString(36);

        $stmt = $this->db->prepare("
            INSERT INTO offline_messages 
            (uuid, original_message_uuid, sender_id, recipient_id, content_encrypted,
             encryption_iv, delivery_method, max_hops, ttl, expires_at, created_at)
            VALUES (?, ?, ?, NULL, ?, ?, 'mesh', 10, 43200, DATE_ADD(NOW(), INTERVAL 12 HOUR), NOW())
        ");
        $stmt->execute([
            $uuid, $uuid, $user['sub'],
            $encrypted['data'], $encrypted['iv']
        ]);

        Response::success([
            'status' => $status,
            'broadcasted' => true,
            'message_uuid' => $uuid
        ], 'Status update broadcasted');
    }
}
