<?php
/**
 * Hayyam - Mesh Network Controller
 * Cihazdan cihaza iletişim, WiFi Direct, Bluetooth routing
 */

namespace Hayyam\Controllers;

use Hayyam\Config\Database;
use Hayyam\Config\Security;
use Hayyam\Config\Response;
use PDO;

class MeshController {
    private PDO $db;

    public function __construct() {
        $this->db = Database::getInstance();
    }

    /**
     * POST /api/mesh/discover
     * Yakındaki cihazları keşfet
     */
    public function postDiscover(array $data, ?array $user, array $params): void {
        $deviceId = $data['device_id'] ?? null;
        $signalStrength = $data['signal_strength'] ?? null;
        $capabilities = $data['capabilities'] ?? [];
        $latitude = $data['latitude'] ?? null;
        $longitude = $data['longitude'] ?? null;

        if (!$deviceId) {
            Response::error('Device ID is required', 400);
        }

        // Kendi cihazını kaydet/güncelle
        $stmt = $this->db->prepare("
            INSERT INTO mesh_routing (device_id, user_id, last_seen, signal_strength, 
                                    capabilities, is_online, hop_distance)
            VALUES (?, ?, NOW(), ?, ?, TRUE, 0)
            ON DUPLICATE KEY UPDATE 
            last_seen = NOW(),
            signal_strength = VALUES(signal_strength),
            capabilities = VALUES(capabilities),
            is_online = TRUE,
            hop_distance = 0
        ");

        $stmt->execute([
            $deviceId,
            $user['sub'],
            $signalStrength,
            json_encode($capabilities)
        ]);

        // Yakındaki aktif cihazları getir
        $stmt = $this->db->prepare("
            SELECT mr.device_id, mr.user_id, mr.signal_strength, mr.hop_distance,
                   mr.capabilities, mr.last_seen,
                   u.username, u.display_name, u.avatar_url, u.status
            FROM mesh_routing mr
            LEFT JOIN users u ON mr.user_id = u.id
            WHERE mr.last_seen > DATE_SUB(NOW(), INTERVAL 5 MINUTE)
            AND mr.is_online = TRUE
            AND mr.device_id != ?
            AND (mr.hop_distance <= 3 OR mr.user_id IS NOT NULL)
            ORDER BY mr.hop_distance ASC, mr.signal_strength DESC
            LIMIT 50
        ");
        $stmt->execute([$deviceId]);
        $devices = $stmt->fetchAll();

        Response::success([
            'nearby_devices' => $devices,
            'total_nearby' => count($devices),
            'your_device_id' => $deviceId
        ]);
    }

    /**
     * POST /api/mesh/relay
     * Mesaj relay et (başka cihaza ilet)
     */
    public function postRelay(array $data, ?array $user, array $params): void {
        if (empty($data['messages']) || !is_array($data['messages'])) {
            Response::error('Messages array is required', 400);
        }

        $deviceId = $data['device_id'] ?? null;
        $relayedCount = 0;
        $failedCount = 0;

        try {
            $this->db->beginTransaction();

            foreach ($data['messages'] as $msg) {
                if (empty($msg['uuid']) || empty($msg['recipient_id'])) {
                    $failedCount++;
                    continue;
                }

                // Mesaj zaten var mı kontrol et (duplicate önleme)
                $stmt = $this->db->prepare("SELECT id FROM offline_messages WHERE uuid = ?");
                $stmt->execute([$msg['uuid']]);
                if ($stmt->fetch()) {
                    continue; // Zaten var, atla
                }

                // TTL ve hop kontrolü
                $hopCount = ($msg['hop_count'] ?? 0) + 1;
                $maxHops = $msg['max_hops'] ?? 10;

                if ($hopCount >= $maxHops) {
                    $failedCount++;
                    continue;
                }

                $expiresAt = date('Y-m-d H:i:s', time() + ($msg['ttl'] ?? 86400));

                $stmt = $this->db->prepare("
                    INSERT INTO offline_messages 
                    (uuid, original_message_uuid, sender_id, recipient_id, content_encrypted,
                     encryption_iv, hop_count, max_hops, ttl, delivery_method, 
                     device_fingerprint, expires_at, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'mesh', ?, ?, NOW())
                ");

                $stmt->execute([
                    $msg['uuid'],
                    $msg['original_message_uuid'] ?? $msg['uuid'],
                    $msg['sender_id'],
                    $msg['recipient_id'],
                    $msg['content_encrypted'],
                    $msg['encryption_iv'] ?? '',
                    $hopCount,
                    $maxHops,
                    $msg['ttl'] ?? 86400,
                    $deviceId,
                    $expiresAt
                ]);

                $relayedCount++;
            }

            $this->db->commit();

            Response::success([
                'relayed' => $relayedCount,
                'failed' => $failedCount,
                'device_id' => $deviceId
            ], "Relayed $relayedCount messages");

        } catch (\Exception $e) {
            $this->db->rollBack();
            Response::error('Relay failed: ' . $e->getMessage(), 500);
        }
    }

    /**
     * POST /api/mesh/status
     * Mesh ağı durumunu güncelle
     */
    public function postStatus(array $data, ?array $user, array $params): void {
        $deviceId = $data['device_id'] ?? null;
        $isOnline = $data['is_online'] ?? true;
        $internetAvailable = $data['internet_available'] ?? false;
        $batteryLevel = $data['battery_level'] ?? null;

        if (!$deviceId) {
            Response::error('Device ID is required', 400);
        }

        // Cihaz durumunu güncelle
        $this->db->prepare("
            UPDATE mesh_routing 
            SET is_online = ?, last_seen = NOW() 
            WHERE device_id = ? AND user_id = ?
        ")->execute([$isOnline, $deviceId, $user['sub']]);

        // İnternet varsa bekleyen mesajları gönder
        if ($internetAvailable) {
            $this->flushPendingMessages($user['sub'], $deviceId);
        }

        Response::success([
            'status' => 'updated',
            'internet_available' => $internetAvailable,
            'pending_messages_flushed' => $internetAvailable
        ]);
    }

    /**
     * GET /api/mesh/route
     * En iyi rotayı hesapla
     */
    public function getRoute(array $data, ?array $user, array $params): void {
        $targetUserId = $_GET['target_user_id'] ?? null;

        if (!$targetUserId) {
            Response::error('Target user ID is required', 400);
        }

        // Hedef kullanıcının son bilinen cihazını bul
        $stmt = $this->db->prepare("
            SELECT device_id, hop_distance, signal_strength, last_seen
            FROM mesh_routing
            WHERE user_id = ? AND is_online = TRUE
            AND last_seen > DATE_SUB(NOW(), INTERVAL 10 MINUTE)
            ORDER BY hop_distance ASC, signal_strength DESC
            LIMIT 1
        ");
        $stmt->execute([$targetUserId]);
        $target = $stmt->fetch();

        if (!$target) {
            // Hedef çevrimdışı, en yakın komşuyu bul
            $stmt = $this->db->prepare("
                SELECT device_id, user_id, hop_distance, signal_strength
                FROM mesh_routing
                WHERE is_online = TRUE 
                AND last_seen > DATE_SUB(NOW(), INTERVAL 5 MINUTE)
                AND user_id != ?
                ORDER BY signal_strength DESC
                LIMIT 5
            ");
            $stmt->execute([$user['sub']]);
            $hops = $stmt->fetchAll();

            Response::success([
                'target_reachable' => false,
                'suggested_hops' => $hops,
                'strategy' => 'flood_and_prune'
            ]);
        }

        Response::success([
            'target_reachable' => true,
            'target_device' => $target['device_id'],
            'estimated_hops' => $target['hop_distance'],
            'signal_strength' => $target['signal_strength'],
            'last_seen' => $target['last_seen']
        ]);
    }

    /**
     * POST /api/mesh/sync
     * Cihazlar arası senkronizasyon
     */
    public function postSync(array $data, ?array $user, array $params): void {
        $deviceId = $data['device_id'] ?? null;
        $lastSync = $data['last_sync'] ?? '1970-01-01';
        $messageIds = $data['known_message_ids'] ?? [];

        if (!$deviceId) {
            Response::error('Device ID is required', 400);
        }

        // Yeni mesajları getir
        $placeholders = implode(',', array_fill(0, count($messageIds), '?'));
        $sql = "
            SELECT om.uuid, om.original_message_uuid, om.sender_id, om.recipient_id,
                   om.content_encrypted, om.encryption_iv, om.hop_count, om.max_hops,
                   om.ttl, om.created_at, om.expires_at
            FROM offline_messages om
            WHERE om.created_at > ?
            AND (om.recipient_id = ? OR om.recipient_id IS NULL)
            AND om.status = 'pending'
            AND om.expires_at > NOW()
        ";

        $params = [$lastSync, $user['sub']];

        if (!empty($messageIds)) {
            $sql .= " AND om.uuid NOT IN ($placeholders)";
            $params = array_merge($params, $messageIds);
        }

        $sql .= " ORDER BY om.created_at ASC LIMIT 100";

        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        $messages = $stmt->fetchAll();

        // Gönderilmeyi bekleyen mesajları getir (başkaları için)
        $stmt = $this->db->prepare("
            SELECT om.*, u.username as recipient_username
            FROM offline_messages om
            JOIN users u ON om.recipient_id = u.id
            WHERE om.sender_id = ? 
            AND om.status = 'pending'
            AND om.created_at > ?
            ORDER BY om.created_at ASC
            LIMIT 50
        ");
        $stmt->execute([$user['sub'], $lastSync]);
        $outbound = $stmt->fetchAll();

        Response::success([
            'inbound_messages' => $messages,
            'outbound_messages' => $outbound,
            'sync_time' => date('Y-m-d H:i:s'),
            'device_id' => $deviceId
        ]);
    }

    /**
     * Bekleyen mesajları internet üzerinden gönder
     */
    private function flushPendingMessages(int $userId, string $deviceId): void {
        $stmt = $this->db->prepare("
            SELECT om.*, u.email as recipient_email
            FROM offline_messages om
            JOIN users u ON om.recipient_id = u.id
            WHERE om.sender_id = ? 
            AND om.status = 'pending'
            AND om.delivery_method IN ('pending', 'mesh')
            AND om.expires_at > NOW()
            LIMIT 100
        ");
        $stmt->execute([$userId]);
        $messages = $stmt->fetchAll();

        foreach ($messages as $msg) {
            // Burada push notification veya websocket ile gönderim yapılacak
            // Şimdilik durumu güncelle
            $this->db->prepare("
                UPDATE offline_messages 
                SET status = 'delivered', delivered_at = NOW(), delivery_method = 'internet'
                WHERE id = ?
            ")->execute([$msg['id']]);
        }
    }
}
