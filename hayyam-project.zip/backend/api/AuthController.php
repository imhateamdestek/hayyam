<?php
/**
 * Hayyam - Authentication Controller
 * Kayıt, giriş, şifre sıfırlama, email doğrulama
 */

namespace Hayyam\Controllers;

use Hayyam\Config\Database;
use Hayyam\Config\Security;
use Hayyam\Config\Response;
use PDO;

class AuthController {
    private PDO $db;

    public function __construct() {
        $this->db = Database::getInstance();
    }

    /**
     * POST /api/auth/register
     * Yeni kullanıcı kaydı
     */
    public function postRegister(array $data, ?array $user, array $params): void {
        $required = ['username', 'email', 'password', 'display_name'];
        foreach ($required as $field) {
            if (empty($data[$field])) {
                Response::error("Field '$field' is required", 400);
            }
        }

        $username = strtolower(trim($data['username']));
        $email = strtolower(trim($data['email']));
        $password = $data['password'];
        $displayName = trim($data['display_name']);

        // Validasyon
        if (!preg_match('/^[a-z0-9_]{3,32}$/', $username)) {
            Response::error('Username must be 3-32 chars, alphanumeric and underscore only', 400);
        }

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            Response::error('Invalid email format', 400);
        }

        if (strlen($password) < 8) {
            Response::error('Password must be at least 8 characters', 400);
        }

        // Benzersizlik kontrolü
        $stmt = $this->db->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
        $stmt->execute([$username, $email]);
        if ($stmt->fetch()) {
            Response::error('Username or email already exists', 409);
        }

        // RSA Key Pair oluştur
        $keyPair = Security::generateKeyPair();
        $passwordHash = Security::hashPassword($password);
        $uuid = Security::randomString(36);
        $verificationToken = Security::randomString(64);

        // Private key'i şifrele (kullanıcı şifresi ile)
        $encryptedPrivateKey = Security::encrypt($keyPair['private'], Security::hashPassword($password));

        try {
            $stmt = $this->db->prepare("
                INSERT INTO users (uuid, username, email, password_hash, display_name, 
                                 public_key, private_key_encrypted, verification_token)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ");

            $stmt->execute([
                $uuid,
                $username,
                $email,
                $passwordHash,
                $displayName,
                $keyPair['public'],
                json_encode($encryptedPrivateKey),
                $verificationToken
            ]);

            $userId = $this->db->lastInsertId();

            // Email gönder (simülasyon)
            $this->sendVerificationEmail($email, $verificationToken);

            Response::success([
                'user_id' => $userId,
                'uuid' => $uuid,
                'username' => $username,
                'email' => $email,
                'display_name' => $displayName,
                'email_verified' => false,
                'message' => 'Registration successful. Please verify your email.'
            ], 'User registered successfully', 201);

        } catch (\Exception $e) {
            Response::error('Registration failed: ' . $e->getMessage(), 500);
        }
    }

    /**
     * POST /api/auth/login
     * Kullanıcı girişi
     */
    public function postLogin(array $data, ?array $user, array $params): void {
        if (empty($data['username']) || empty($data['password'])) {
            Response::error('Username and password are required', 400);
        }

        $username = strtolower(trim($data['username']));
        $password = $data['password'];
        $deviceInfo = $data['device_info'] ?? $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';

        $stmt = $this->db->prepare("
            SELECT id, uuid, username, email, display_name, password_hash, 
                   avatar_url, public_key, email_verified, is_active, is_admin
            FROM users 
            WHERE username = ? OR email = ?
        ");
        $stmt->execute([$username, $username]);
        $user = $stmt->fetch();

        if (!$user || !Security::verifyPassword($password, $user['password_hash'])) {
            Response::error('Invalid credentials', 401);
        }

        if (!$user['is_active']) {
            Response::error('Account is deactivated', 403);
        }

        // Session oluştur
        $token = Security::generateJWT([
            'sub' => $user['id'],
            'uuid' => $user['uuid'],
            'username' => $user['username'],
            'email' => $user['email'],
            'is_admin' => $user['is_admin']
        ], 86400 * 30); // 30 gün

        $refreshToken = Security::randomString(64);
        $expiresAt = date('Y-m-d H:i:s', time() + 86400 * 30);

        $stmt = $this->db->prepare("
            INSERT INTO user_sessions (user_id, token, device_info, ip_address, expires_at)
            VALUES (?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $user['id'],
            $refreshToken,
            $deviceInfo,
            $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0',
            $expiresAt
        ]);

        // Son görülme güncelle
        $this->db->prepare("UPDATE users SET last_seen = NOW(), status = 'online' WHERE id = ?")
                 ->execute([$user['id']]);

        Response::success([
            'token' => $token,
            'refresh_token' => $refreshToken,
            'expires_in' => 86400 * 30,
            'user' => [
                'id' => $user['id'],
                'uuid' => $user['uuid'],
                'username' => $user['username'],
                'email' => $user['email'],
                'display_name' => $user['display_name'],
                'avatar_url' => $user['avatar_url'],
                'public_key' => $user['public_key'],
                'email_verified' => (bool)$user['email_verified'],
                'is_admin' => (bool)$user['is_admin']
            ]
        ]);
    }

    /**
     * POST /api/auth/verify-email
     * Email doğrulama
     */
    public function postVerifyEmail(array $data, ?array $user, array $params): void {
        if (empty($data['token'])) {
            Response::error('Verification token is required', 400);
        }

        $stmt = $this->db->prepare("SELECT id FROM users WHERE verification_token = ? AND email_verified = FALSE");
        $stmt->execute([$data['token']]);
        $user = $stmt->fetch();

        if (!$user) {
            Response::error('Invalid or expired verification token', 400);
        }

        $this->db->prepare("UPDATE users SET email_verified = TRUE, verification_token = NULL WHERE id = ?")
                 ->execute([$user['id']]);

        Response::success(null, 'Email verified successfully');
    }

    /**
     * POST /api/auth/forgot-password
     * Şifre sıfırlama talebi
     */
    public function postForgotPassword(array $data, ?array $user, array $params): void {
        if (empty($data['email'])) {
            Response::error('Email is required', 400);
        }

        $stmt = $this->db->prepare("SELECT id, email FROM users WHERE email = ?");
        $stmt->execute([$data['email']]);
        $user = $stmt->fetch();

        if ($user) {
            $token = Security::randomString(64);
            $expires = date('Y-m-d H:i:s', time() + 3600); // 1 saat

            $this->db->prepare("UPDATE users SET reset_token = ?, reset_expires = ? WHERE id = ?")
                     ->execute([$token, $expires, $user['id']]);

            // Email gönder (simülasyon)
            $this->sendResetEmail($user['email'], $token);
        }

        // Güvenlik için her durumda başarılı mesajı
        Response::success(null, 'If the email exists, a reset link has been sent');
    }

    /**
     * POST /api/auth/reset-password
     * Şifre sıfırlama
     */
    public function postResetPassword(array $data, ?array $user, array $params): void {
        if (empty($data['token']) || empty($data['password'])) {
            Response::error('Token and new password are required', 400);
        }

        if (strlen($data['password']) < 8) {
            Response::error('Password must be at least 8 characters', 400);
        }

        $stmt = $this->db->prepare("SELECT id FROM users WHERE reset_token = ? AND reset_expires > NOW()");
        $stmt->execute([$data['token']]);
        $user = $stmt->fetch();

        if (!$user) {
            Response::error('Invalid or expired reset token', 400);
        }

        $hash = Security::hashPassword($data['password']);
        $this->db->prepare("UPDATE users SET password_hash = ?, reset_token = NULL, reset_expires = NULL WHERE id = ?")
                 ->execute([$hash, $user['id']]);

        Response::success(null, 'Password reset successfully');
    }

    /**
     * POST /api/auth/refresh
     * Token yenileme
     */
    public function postRefresh(array $data, ?array $user, array $params): void {
        if (empty($data['refresh_token'])) {
            Response::error('Refresh token is required', 400);
        }

        $stmt = $this->db->prepare("
            SELECT us.user_id, u.uuid, u.username, u.email, u.is_admin
            FROM user_sessions us
            JOIN users u ON us.user_id = u.id
            WHERE us.token = ? AND us.expires_at > NOW() AND us.is_valid = TRUE
        ");
        $stmt->execute([$data['refresh_token']]);
        $session = $stmt->fetch();

        if (!$session) {
            Response::error('Invalid refresh token', 401);
        }

        $token = Security::generateJWT([
            'sub' => $session['user_id'],
            'uuid' => $session['uuid'],
            'username' => $session['username'],
            'email' => $session['email'],
            'is_admin' => $session['is_admin']
        ], 86400 * 30);

        Response::success(['token' => $token]);
    }

    /**
     * POST /api/auth/logout
     * Çıkış yap
     */
    public function postLogout(array $data, ?array $user, array $params): void {
        if ($user) {
            $authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
            $token = str_replace('Bearer ', '', $authHeader);

            $this->db->prepare("UPDATE user_sessions SET is_valid = FALSE WHERE token = ?")
                     ->execute([$token]);

            $this->db->prepare("UPDATE users SET status = 'offline' WHERE id = ?")
                     ->execute([$user['sub']]);
        }

        Response::success(null, 'Logged out successfully');
    }

    /**
     * GET /api/auth/me
     * Mevcut kullanıcı bilgisi
     */
    public function getMe(array $data, ?array $user, array $params): void {
        if (!$user) {
            Response::error('Unauthorized', 401);
        }

        $stmt = $this->db->prepare("
            SELECT id, uuid, username, email, display_name, bio, avatar_url, 
                   phone, public_key, email_verified, last_seen, status, created_at
            FROM users WHERE id = ?
        ");
        $stmt->execute([$user['sub']]);
        $userData = $stmt->fetch();

        if (!$userData) {
            Response::error('User not found', 404);
        }

        Response::success($userData);
    }

    // Private methods
    private function sendVerificationEmail(string $email, string $token): void {
        // SMTP entegrasyonu burada yapılacak
        // Şimdilik log'a yaz
        error_log("Verification email to $email: token=$token");
    }

    private function sendResetEmail(string $email, string $token): void {
        error_log("Reset email to $email: token=$token");
    }
}
