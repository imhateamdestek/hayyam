# Hayyam - Güvenli Mesajlaşma Uygulaması

![Hayyam Logo](https://img.shields.io/badge/Hayyam-v1.0.0-6366f1?style=for-the-badge)
![License](https://img.shields.io/badge/License-MIT-green?style=for-the-badge)
![PHP](https://img.shields.io/badge/PHP-8.2+-777BB4?style=for-the-badge&logo=php)
![React](https://img.shields.io/badge/React-18-61DAFB?style=for-the-badge&logo=react)

**Deprem ve afet anlarında bile çalışan, internet olmadan mesajlaşma uygulaması.**

Hayyam, merkeziyetsiz, şifreli ve çoklu bağlantı protokolleri (Mobil Veri, WiFi Direct, Bluetooth) kullanan modern bir mesajlaşma platformudur. Telegram benzeri bot sistemi, sosyal duvar özelliği ve afet modu ile günlük kullanım ve acil durumlar için tasarlanmıştır.

## 🚀 Özellikler

### 💬 Mesajlaşma
- **Uçtan Uca Şifreleme**: AES-256-GCM ile güvenli mesajlaşma
- **Çoklu Medya**: Metin, görsel, video, ses ve dosya paylaşımı
- **Grup Sohbetleri**: Sınırsız katılımcı ile grup konuşmaları
- **Sesli/Görüntülü Arama**: WebRTC tabanlı şifreli aramalar
- **Yazıyor... Bildirimi**: Gerçek zamanlı yazma durumu
- **Okundu Bilgisi**: Çift tik ile okundu onayı

### 🌐 Mesh Ağı (Afet Modu)
- **İnternet Bağımsız**: Mobil veri, WiFi Direct ve Bluetooth ile çalışma
- **Cihazdan Cihaza**: Mesajlar cihazlar arasında sıçrayarak iletilir
- **Otomatik Rota**: En hızlı ve güvenli iletim rotasını seçer
- **SOS Sinyali**: Tek tuşla acil durum yayını
- **Yakındaki Kullanıcılar**: Bluetooth ile yakındaki cihazları keşfetme
- **Pil Tasarrufu**: Afet modunda optimize edilmiş pil kullanımı

### 🤖 Bot Sistemi
- **BotFather Benzeri**: Kolay bot oluşturma arayüzü
- **Python/JS/PHP**: Desteklenen programlama dilleri
- **Webhook Desteği**: Kendi sunucunuzda bot çalıştırma
- **Özel Komutlar**: /komut yapısı ile özelleştirilebilir botlar
- **Bot Mağazası**: Topluluk botlarını keşfetme

### 🏠 Sosyal Duvar
- **Paylaşım Duvarı**: Kullanıcı profillerinde paylaşım duvarı
- **Etiketleme**: Fotoğraflarda ve paylaşımlarda arkadaş etiketleme
- **Beğeni ve Yorum**: Sosyal medya benzeri etkileşimler
- **Özel İçerik**: Arkadaşlara özel veya herkese açık paylaşımlar

### 🔒 Güvenlik
- **RSA-2048 Key Pair**: Her kullanıcı için benzersiz anahtar çifti
- **Argon2id Şifreleme**: Güvenli parola hash'leme
- **JWT Token**: Güvenli oturum yönetimi
- **Rate Limiting**: DDoS ve brute-force koruması

## 📋 Gereksinimler

### Sunucu
- **PHP**: 8.2 veya üzeri
- **MySQL**: 8.0 veya üzeri (MariaDB 10.6+ desteklenir)
- **Web Sunucu**: Apache/Nginx
- **SSL Sertifikası**: Let's Encrypt önerilir
- **RAM**: Minimum 2GB (4GB önerilir)
- **Disk**: Minimum 10GB

### İstemci
- **Modern Tarayıcı**: Chrome 90+, Firefox 88+, Safari 14+, Edge 90+
- **Mobil**: iOS 14+ veya Android 8+
- **Bluetooth**: Web Bluetooth API desteği (Chrome Android)

## 🛠️ Kurulum

### 1. Dosyaları Yükleyin

```bash
# Git ile klonlayın
git clone https://github.com/yourusername/hayyam.git
cd hayyam

# Veya ZIP dosyasını sunucunuza yükleyin ve çıkarın
unzip hayyam-project.zip -d /var/www/hayyam/
```

### 2. Web Kurulum Sihirbazı

Tarayıcınızda şu adresi açın:
```
https://your-domain.com/install/
```

Kurulum sihirbazı şu adımları içerir:
1. **Sistem Kontrolü**: PHP uzantıları ve yazma izinleri
2. **Veritabanı**: MySQL bağlantı bilgileri
3. **Yönetici Hesabı**: İlk admin kullanıcısı
4. **Uygulama Ayarları**: URL, WebSocket, Mail yapılandırması

### 3. Manuel Kurulum (Alternatif)

```bash
# 1. Veritabanını oluşturun
mysql -u root -p
CREATE DATABASE hayyam CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
EXIT;

# 2. SQL şemasını içe aktarın
mysql -u root -p hayyam < database/schema.sql

# 3. .env dosyasını oluşturun
cp backend/.env.example backend/.env
nano backend/.env

# 4. Yazma izinlerini ayarlayın
chmod -R 755 uploads/
chmod -R 644 backend/.env
```

### 4. WebSocket Sunucusu

```bash
# Composer bağımlılıklarını yükleyin
cd backend
composer install

# WebSocket sunucusunu başlatın (screen veya systemd ile)
php websocket/Server.php

# Veya arka planda çalıştırın
nohup php websocket/Server.php > /var/log/hayyam-websocket.log 2>&1 &
```

### 5. Nginx Yapılandırması

```nginx
server {
    listen 80;
    server_name your-domain.com;
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name your-domain.com;

    ssl_certificate /path/to/cert.pem;
    ssl_certificate_key /path/to/key.pem;

    root /var/www/hayyam/frontend/build;
    index index.html;

    # Frontend
    location / {
        try_files $uri $uri/ /index.html;
    }

    # API
    location /api/ {
        root /var/www/hayyam/backend;
        try_files $uri /api/index.php$is_args$args;

        location ~ \.php$ {
            fastcgi_pass unix:/var/run/php/php8.2-fpm.sock;
            fastcgi_index index.php;
            fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
            include fastcgi_params;
        }
    }

    # WebSocket proxy
    location /ws/ {
        proxy_pass http://localhost:8080;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }

    # Uploads
    location /uploads/ {
        alias /var/www/hayyam/uploads/;
    }
}
```

### 6. Apache Yapılandırması (.htaccess)

```apache
<IfModule mod_rewrite.c>
    RewriteEngine On
    RewriteBase /

    # API requests
    RewriteRule ^api/(.*)$ backend/api/index.php [L,QSA]

    # Frontend routing
    RewriteCond %{REQUEST_FILENAME} !-f
    RewriteCond %{REQUEST_FILENAME} !-d
    RewriteRule ^ index.html [L]
</IfModule>

# PHP settings
php_value upload_max_filesize 100M
php_value post_max_size 100M
php_value max_execution_time 300
```

## 📱 Mobil Uygulama (PWA)

### Progressive Web App
Hayyam, modern tarayıcılar üzerinden doğrudan kullanılabilir. "Ana Ekrana Ekle" özelliği ile native uygulama deneyimi sunar.

### Android (Capacitor)

```bash
cd frontend

# Capacitor bağımlılıklarını yükleyin
npm install @capacitor/android @capacitor/core

# Android projesini oluşturun
npx cap add android

# Uygulamayı derleyin
npm run build
npx cap sync android

# Android Studio ile açın
npx cap open android
```

### iOS (Capacitor)

```bash
# iOS projesini oluşturun (Mac gereklidir)
npx cap add ios
npx cap sync ios
npx cap open ios
```

## 🤖 Bot Geliştirme

### Python Bot Örneği

```python
from flask import Flask, request
import requests

app = Flask(__name__)
BOT_TOKEN = "your_bot_token"
API_URL = "https://api.hayyam.app"

@app.route('/webhook', methods=['POST'])
def webhook():
    data = request.json
    message = data['message']['text']
    chat_id = data['message']['chat']['id']

    if message == '/start':
        send_message(chat_id, "Merhaba! Ben Hayyam botuyum.")

    return 'OK'

def send_message(chat_id, text):
    requests.post(f"{API_URL}/api/bots/interact", json={
        'conversation_id': chat_id,
        'message': text
    }, headers={'Authorization': f'Bearer {BOT_TOKEN}'})

if __name__ == '__main__':
    app.run(port=5000)
```

### Bot Komutları

| Komut | Açıklama |
|-------|----------|
| `/start` | Botu başlat |
| `/help` | Yardım menüsü |
| `/weather <şehir>` | Hava durumu |
| `/joke` | Rastgele şaka |
| `/echo <mesaj>` | Mesajı tekrarla |

## 🌐 API Dokümantasyonu

### Kimlik Doğrulama

```http
POST /api/auth/register
Content-Type: application/json

{
  "username": "kullanici",
  "email": "ornek@email.com",
  "password": "gucluSifre123",
  "display_name": "Ad Soyad"
}
```

```http
POST /api/auth/login
Content-Type: application/json

{
  "username": "kullanici",
  "password": "gucluSifre123"
}
```

### Mesaj Gönderme

```http
POST /api/messages/send
Authorization: Bearer <token>
Content-Type: application/json

{
  "conversation_id": 123,
  "content": "Merhaba!",
  "type": "text"
}
```

### Mesh Mesaj (Afet Modu)

```http
POST /api/messages/mesh-send
Authorization: Bearer <token>
Content-Type: application/json

{
  "recipient_username": "hedef_kullanici",
  "content": "Yardım! Konumum...",
  "delivery_method": "mesh"
}
```

## 🔧 Yapılandırma

### .env Dosyası

```env
# Uygulama
APP_NAME=Hayyam
APP_ENV=production
APP_URL=https://your-domain.com
APP_DEBUG=false

# Veritabanı
DB_HOST=localhost
DB_NAME=hayyam
DB_USER=root
DB_PASS=your_password
DB_CHARSET=utf8mb4

# Güvenlik
JWT_SECRET=random_secret_key_here
AES_KEY=random_encryption_key_here

# WebSocket
WS_URL=wss://your-domain.com:8080

# Mail
MAIL_HOST=smtp.gmail.com
MAIL_PORT=587
MAIL_USER=your-email@gmail.com
MAIL_PASS=your-app-password
MAIL_FROM=noreply@hayyam.app

# Dosya Yükleme
MAX_FILE_SIZE=104857600
UPLOAD_PATH=/uploads/
```

## 🧪 Test

```bash
# PHP Unit testleri çalıştır
cd backend
./vendor/bin/phpunit

# Frontend testleri
npm test

# Load test (k6 ile)
k6 run tests/load-test.js
```

## 📊 Monitoring

```bash
# WebSocket sunucusu logları
tail -f /var/log/hayyam-websocket.log

# PHP error logları
tail -f /var/log/php_errors.log

# MySQL yavaş sorgular
mysql -e "SHOW FULL PROCESSLIST;"
```

## 🚨 Afet Modu Kullanımı

1. **Aktifleştirme**: Uygulama içinden "Afet Modu" butonuna basın
2. **İzinler**: Bluetooth ve konum izinlerini verin
3. **Mesaj Gönderme**: Normal mesajlaşma gibi, otomatik olarak mesh ağına iletilir
4. **SOS**: Acil durumda "SOS Sinyali" gönderin
5. **Yakındakiler**: Bluetooth ile yakındaki cihazları görün

## 🔐 Güvenlik Önerileri

1. **SSL Sertifikası**: Her zaman HTTPS kullanın
2. **Güçlü Parola**: Admin hesabı için en az 12 karakterli parola
3. **Firewall**: Sadece gerekli portları açın (80, 443, 8080)
4. **Güncellemeler**: Düzenli olarak bağımlılıkları güncelleyin
5. **Backup**: Veritabanını günlük yedekleyin

## 📝 Lisans

Bu proje MIT lisansı altında lisanslanmıştır. Detaylar için [LICENSE](LICENSE) dosyasına bakın.

## 🤝 Katkıda Bulunma

1. Fork yapın
2. Feature branch oluşturun (`git checkout -b feature/amazing-feature`)
3. Commit yapın (`git commit -m 'Add amazing feature'`)
4. Push yapın (`git push origin feature/amazing-feature`)
5. Pull Request açın

## 📞 Destek

- **Discord**: [Hayyam Community](https://discord.gg/hayyam)
- **Email**: support@hayyam.app
- **GitHub Issues**: [Issues](https://github.com/yourusername/hayyam/issues)

## 🙏 Teşekkürler

- [React](https://reactjs.org/)
- [Tailwind CSS](https://tailwindcss.com/)
- [Ratchet](http://socketo.me/)
- [Capacitor](https://capacitorjs.com/)

---

**Hayyam** - *Her zaman, her yerde, güvenli iletişim.*

Made with ❤️ in Turkey
